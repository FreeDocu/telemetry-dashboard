# Telemetry Dashboard - Architecture & Development Guide

## Project Structure

```
telemetry-dashboard/
├── backend/                      # FastAPI server
│   ├── app/
│   │   ├── models/              # SQLAlchemy ORM models
│   │   │   ├── admin.py         # AdminUser model
│   │   │   ├── token.py         # Token model (for .exe apps)
│   │   │   ├── launch.py        # Launch record model
│   │   │   ├── banned_hwid.py   # Ban management
│   │   │   └── dashboard.py     # Dashboard layout persistence
│   │   ├── routes/              # API endpoints
│   │   │   ├── auth.py          # JWT + TOTP endpoints
│   │   │   ├── telemetry.py     # /telemetry/ping endpoint
│   │   │   ├── admin.py         # Token & ban management
│   │   │   ├── analytics.py     # Analytics/stats endpoints
│   │   │   └── dashboard.py     # Layout endpoints
│   │   ├── schemas/             # Pydantic request/response models
│   │   ├── security.py          # JWT, password hashing, TOTP
│   │   ├── geoip.py            # GeoIP lookup
│   │   ├── config.py           # Settings management
│   │   ├── database.py         # SQLAlchemy setup
│   │   └── __init__.py
│   ├── scripts/
│   │   └── init_admin.py       # Admin initialization script
│   ├── main.py                 # FastAPI app entry point
│   ├── requirements.txt
│   ├── .env                    # Environment variables
│   ├── .env.example
│   └── Dockerfile
│
├── frontend/                    # React + Vite
│   ├── src/
│   │   ├── components/         # React components
│   │   │   ├── KPICard.tsx            # KPI display card
│   │   │   ├── FilterPanel.tsx        # Global filters
│   │   │   ├── RetentionChart.tsx     # Retention curves
│   │   │   ├── ActivityHeatmap.tsx    # 24h×7d heatmap
│   │   │   ├── TopHWIDsTable.tsx      # Top devices
│   │   │   ├── GeographyChart.tsx     # Country stats
│   │   │   ├── VersionChart.tsx       # Version distribution
│   │   │   ├── DashboardGrid.tsx      # react-grid-layout wrapper
│   │   │   ├── Navbar.tsx             # Top navigation
│   │   │   └── Sidebar.tsx            # Left sidebar navigation
│   │   ├── pages/              # Page components
│   │   │   ├── LoginPage.tsx
│   │   │   ├── DashboardPage.tsx
│   │   │   ├── TokenManagementPage.tsx
│   │   │   ├── SettingsPage.tsx
│   │   │   └── BanManagementPage.tsx
│   │   ├── api/                # API client
│   │   │   ├── client.ts       # Axios instance
│   │   │   └── index.ts        # API functions
│   │   ├── store/              # Zustand stores
│   │   │   ├── auth.ts         # Auth state
│   │   │   └── filters.ts      # Dashboard filters state
│   │   ├── styles/
│   │   │   └── index.css       # Tailwind + custom styles
│   │   ├── App.tsx             # Root component
│   │   └── main.tsx            # React entry point
│   ├── index.html
│   ├── package.json
│   ├── vite.config.ts
│   ├── tsconfig.json
│   ├── tailwind.config.js
│   └── Dockerfile
│
├── docker-compose.yml           # Docker orchestration
├── README.md                    # Main documentation
├── EXAMPLES.md                  # API examples
├── ARCHITECTURE.md              # This file
└── setup.sh                     # Installation script
```

## Technology Stack Rationale

### Backend: FastAPI
- **Async-first**: Non-blocking I/O for high concurrency
- **Type hints**: Full request/response validation with Pydantic
- **Performance**: ~10x faster than Flask for async operations
- **Auto-docs**: Automatic OpenAPI/Swagger documentation

### ORM: SQLAlchemy 2.0 Async
- **Async driver**: asyncpg for PostgreSQL (excellent performance)
- **Flexibility**: Raw SQL + ORM seamlessly combined
- **Migrations**: Alembic for schema versioning (can be added)

### Database: PostgreSQL + TimescaleDB (optional)
- **JSONB**: Store arbitrary data (extra fields, layout configs)
- **Indexes**: Fast queries on ip, country, version
- **TimescaleDB**: Time-series optimized tables for massive launches data
- **Retention**: Can prune old data efficiently

### Frontend: React + Vite
- **Speed**: ~10x faster HMR than Create React App
- **Modern**: ESM modules, tree-shaking, minimal bundle
- **Dev experience**: Instant file-based routing potential

### State Management: Zustand
- **Simplicity**: No Redux boilerplate
- **Size**: ~1KB vs Redux 50KB
- **Hooks-based**: Works with React patterns

### Data Fetching: TanStack Query
- **Caching**: Automatic request deduplication
- **Sync**: Real-time dashboard updates
- **DevTools**: Browser extension for debugging

### Charts: Recharts + Tremor
- **Recharts**: Low-level composable charts (Retention, Heatmap)
- **Tremor**: High-level dashboard components (KPI cards)

### Drag-and-drop: react-grid-layout
- **Customization**: Full control over grid behavior
- **Persistence**: Layout saved to database (JSONB)
- **Responsive**: Mobile-friendly with breakpoints

## Security Architecture

### Authentication Flow
```
1. User submits username + password
2. Backend verifies password hash
3. If TOTP enabled: requires 6-digit code from authenticator
4. Backend issues JWT token valid for 1 hour
5. Frontend stores token in localStorage
6. All API requests include: Authorization: Bearer <token>
```

### TOTP 2FA (Permanent Lock)
```
Setup (one-time only):
1. Admin requests TOTP setup
2. Backend generates secret, returns QR code
3. Admin scans QR with authenticator app
4. Admin confirms with code from app
5. Secret stored in DB, totp_locked = true forever

Login:
1. Username + password verified
2. If totp_enabled: requires current TOTP code
3. Ensures even password breach doesn't grant access
```

### HWID Ban System
```
Three detection methods:
1. Manual blacklist: Ban specific HWID (permanent/temporary)
2. Anomaly detection: Unusual spike = flag as suspicious
3. Concurrent bans: Same HWID multiple tokens in short time

Ban effects:
- All telemetry from banned HWID rejected with 403
- Ban can expire (until date) or be permanent (until = NULL)
- Bans can be per-token or global
```

### Token Security
```
Token lifecycle:
1. Admin creates token for app
2. App stores token securely
3. App submits token with every ping
4. Server validates: active + not expired
5. Banned HWID = immediate 403
6. Old versions detectable from exe_version field
```

## Database Schema Details

### admin_user (single record)
```sql
{
  id: "admin",                    -- Fixed, only one admin
  username: string UNIQUE,
  password_hash: bcrypt hash,
  totp_secret: string NULL,       -- Null until enabled
  totp_enabled: boolean,
  totp_locked: boolean,           -- True after first setup, irreversible
  created_at: timestamp,
  updated_at: timestamp
}
```

### tokens
```sql
{
  id: string UUID,
  token: string UNIQUE,           -- Secure random token
  name: string,                   -- "App v1.0"
  note: string NULL,
  active: boolean,                -- Can deactivate without deleting
  current_version: string NULL,   -- Latest version
  expires_at: timestamp NULL,     -- NULL = no expiration
  created_at: timestamp,
  updated_at: timestamp
}
```

### launches
```sql
{
  id: string UUID,
  token_id: string FK,
  hwid: string INDEXED,           -- Hardware ID
  ip: string,                     -- Client IP
  country: string (ISO code),     -- From GeoIP
  os: string,                     -- Client OS
  exe_version: string,
  launched_at: timestamp INDEXED, -- For time-series queries
  extra: jsonb                    -- Custom data
}
```

### banned_hwids
```sql
{
  hwid: string PK,
  token_id: string FK NULL,       -- NULL = global ban
  reason: string,
  banned_at: timestamp,
  banned_by: string,              -- "admin"
  until: timestamp NULL           -- NULL = permanent
}
```

### dashboard_layout
```sql
{
  user_id: string PK,             -- "admin"
  layout_json: jsonb,             -- react-grid-layout format
  created_at: timestamp,
  updated_at: timestamp
}
```

## API Design Principles

### REST Conventions
```
GET    /api/v1/admin/tokens              -- List all
POST   /api/v1/admin/tokens              -- Create
GET    /api/v1/admin/tokens/{id}         -- Get one
PATCH  /api/v1/admin/tokens/{id}         -- Partial update
DELETE /api/v1/admin/tokens/{id}         -- Delete

GET    /api/v1/analytics/summary         -- Stats summary
GET    /api/v1/analytics/launches/timeline
GET    /api/v1/dashboard/layout
POST   /api/v1/dashboard/layout
```

### Query Parameters for Filtering
```
GET /api/v1/analytics/summary?period_hours=24&token_ids=[]

All analytics endpoints support:
- period_hours: 1, 2, 6, 12, 24, 48, 168, 720
- token_ids: list of token UUIDs
- countries: list of ISO country codes
- versions: list of exe versions
```

### Error Handling
```
HTTP 400: Bad request (validation error)
HTTP 401: Unauthorized (invalid credentials, expired token)
HTTP 403: Forbidden (HWID banned)
HTTP 404: Not found
HTTP 500: Server error

All responses include:
{
  "detail": "Human-readable error message"
}
```

## Frontend State Management

### Auth Store (Zustand)
```typescript
{
  token: string | null,
  username: string | null,
  totpSetup: boolean,
  login(token, username),
  logout(),
  setTotpSetup(boolean)
}
```

### Dashboard Filters (Zustand)
```typescript
{
  filters: {
    periodHours: 24,
    tokenIds: [],
    countries: [],
    versions: [],
    suspiciousOnly: false,
    bannedOnly: false,
  },
  setFilters(partial)
}
```

### Query Keys
```
['tokens']                              -- Token list
['bans']                                -- Ban list
['summary', filters]                    -- Analytics summary
['timeline', filters]                   -- Launches timeline
['countries', filters]                  -- Top countries
['hwids', filters]                      -- Top HWIDs
['versions', filters]                   -- Version stats
```

## Performance Optimization

### Backend
1. **Database indexes**: token, hwid, launch.launched_at, country
2. **Connection pooling**: 20 connections, 10 overflow
3. **Query optimization**: Group by with HAVING clauses
4. **Async everything**: Never block on I/O
5. **Caching**: Optional Redis for frequently accessed data

### Frontend
1. **Code splitting**: Each page is separate chunk
2. **Image optimization**: SVG/CSS instead of PNG where possible
3. **Debouncing**: Filter changes debounced 300ms
4. **Virtual scrolling**: Large tables use windowing (if tables > 1000 rows)
5. **React.memo**: Chart components memoized

### Database
1. **Partitioning by date**: Launches table (monthly)
2. **TTL policies**: Auto-delete data older than 90 days (configurable)
3. **Materialized views**: Pre-aggregated daily stats
4. **Explain ANALYZE**: Review slow queries in production

## Development Workflow

### Adding a New Chart/Widget
1. Create component in `frontend/src/components/NEW_CHART.tsx`
2. Add API endpoint in backend if needed
3. Create corresponding Zustand store if needs state
4. Add to default layout in `DashboardGrid.tsx`
5. Test responsiveness on mobile

### Adding New Admin Feature
1. Create page in `frontend/src/pages/NEW_PAGE.tsx`
2. Add routes in `App.tsx`
3. Add sidebar navigation in `Sidebar.tsx`
4. Create backend endpoints in `routes/admin.py`
5. Create Zustand store if needed

### Debugging
```bash
# Backend
export SQLALCHEMY_ECHO=true  # Log all SQL queries
python -m pdb main.py        # Python debugger

# Frontend
F12 > Console              # Browser console
F12 > React DevTools       # Component inspector
npm run type-check         # TypeScript errors
```

## Deployment Checklist

- [ ] Change default admin password
- [ ] Set strong SECRET_KEY (min 32 chars, random)
- [ ] Configure PostgreSQL with backups
- [ ] Download GeoIP MaxMind database
- [ ] Set ALLOWED_ORIGINS for production domain
- [ ] Enable HTTPS/SSL certificate
- [ ] Set up monitoring/logging
- [ ] Configure database auto-backups
- [ ] Test TOTP 2FA flow
- [ ] Load test with k6 or similar
- [ ] Security audit (OWASP Top 10)

---

**Made for serious monitoring** 🎯
