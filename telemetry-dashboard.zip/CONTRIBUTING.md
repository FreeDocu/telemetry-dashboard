# Contributing to Telemetry Dashboard

## Code Style

### Backend (Python)
- Follow PEP 8
- Type hints on all functions
- Docstrings for complex logic
- Use `black` for formatting (not included yet)

### Frontend (React/TypeScript)
- Use TypeScript strict mode
- Functional components with hooks
- Props interfaces for all components
- Clear component responsibility

## New Feature Checklist

1. Create feature branch: `git checkout -b feature/description`
2. Implement backend endpoints
3. Implement frontend components
4. Ensure types match between frontend/backend
5. Test all auth levels (unauthenticated, authenticated, 2FA)
6. Test on mobile/tablet screen sizes
7. Document changes in comments
8. Create pull request

## Testing

### Backend Tests
```bash
# Unit tests
pytest tests/

# Coverage report
pytest --cov=app tests/
```

### Frontend Tests
```bash
# Unit/component tests
npm test

# E2E tests (Cypress)
npm run test:e2e
```

## Performance Considerations

- Keep components small and focused
- Memoize expensive calculations
- Use React.memo for chart components
- Debounce rapid filter changes
- Implement virtual scrolling for large tables (1000+ rows)
- Profile with Chrome DevTools Performance tab

## Security Guidelines

- Never commit `.env` files with real secrets
- Use environment variables for all sensitive data
- Validate all inputs server-side
- Sanitize user data before displaying
- Use Content Security Policy headers
- Keep dependencies updated regularly

## Documentation

- Update README.md for user-facing changes
- Update ARCHITECTURE.md for technical changes
- Add code comments for non-obvious logic
- Include examples in EXAMPLES.md for new APIs

---

Questions? Open an issue or contact the maintainers.
