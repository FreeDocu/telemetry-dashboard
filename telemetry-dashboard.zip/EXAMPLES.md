"""
Telemetry Dashboard - Comprehensive example usage guide
"""

from app.models import Token, Launch, BannedHwid
from app.security import hash_password
import asyncio

# Example 1: Creating an app token
example_token_creation = {
    "name": "Mobile App v1",
    "note": "Production mobile application",
    "expires_at": "2026-12-31T23:59:59Z"
}

# Example 2: Telemetry ping from .exe app
example_telemetry_ping = {
    "token": "secure_token_value_from_above",
    "hwid": "AC3FB78A-2F3C-11EE-BE56-0242AC120002",
    "exe_version": "1.2.5",
    "os": "Windows 10",
    "launch_id": "launch_uuid_optional",
    "extra": {
        "cpu_cores": 8,
        "ram_gb": 16,
        "gpu": "RTX 3060"
    }
}

# Example 3: Banning suspicious HWID
example_hwid_ban = {
    "hwid": "AC3FB78A-2F3C-11EE-BE56-0242AC120002",
    "reason": "Excessive launches detected - potential botnet",
    "token_id": "token_uuid_optional",
    "until": "2026-03-01T00:00:00Z"  # NULL for permanent ban
}

# Example 4: Retention calculation
"""
Retention is calculated as:
- D1: Users who launched on day 0 AND day 1 / Total users day 0
- D7: Users who launched in first week AND launched on day 7 / Total users day 0
- D30: Users who launched in first month AND launched on day 30 / Total users day 0

This is calculated server-side in analytics endpoints
"""

# Example 5: Filter usage
filters_example = {
    "period_hours": 24,
    "token_ids": ["token-uuid-1", "token-uuid-2"],  # Empty = all tokens
    "countries": ["US", "RU", "DE"],  # Empty = all countries
    "versions": ["1.0.0", "1.0.1"],  # Empty = all versions
    "suspiciousOnly": False,  # Server detects via heuristics
    "bannedOnly": False  # Only show banned HWIDs
}

# Example 6: Dashboard preset layouts
preset_layouts = {
    "daily_check": {
        "period_hours": 24,
        "visible_widgets": [
            "kpi-unique-hwid",
            "kpi-launches-today",
            "filters",
            "heatmap-activity",
            "top-hwids",
            "geography"
        ]
    },
    "retention_deep_dive": {
        "period_hours": 720,  # 30 days
        "visible_widgets": [
            "retention-curves",
            "filters",
            "geography",
            "versions"
        ]
    },
    "suspicious_only": {
        "period_hours": 24,
        "filters": {
            "suspiciousOnly": True,
            "bannedOnly": False
        }
    }
}

# Example 7: API authentication flow
"""
1. Login with credentials:
   POST /api/v1/auth/login
   { "username": "admin", "password": "...", "totp_code": "123456" }

2. Receive JWT token:
   { "access_token": "eyJ0...", "token_type": "bearer", "expires_in": 3600 }

3. Use in all subsequent requests:
   Authorization: Bearer eyJ0...

4. Token expires after 1 hour - must re-login
"""

# Example 8: 2FA Setup (one-time only)
"""
1. Request TOTP setup:
   POST /api/v1/auth/totp/setup
   Content: { "current_password": "..." }

2. Receive QR code + secret:
   {
     "secret": "JBSWY3DPEBLW64TMMQ======",
     "qr_code": "data:image/png;base64,..."
   }

3. Admin scans QR with authenticator app (e.g., Google Authenticator)

4. Confirm TOTP with code from authenticator:
   POST /api/v1/auth/totp/confirm
   { "secret": "JBSWY3DPEBLW64TMMQ======", "totp_code": "123456" }

5. 2FA is now ENABLED and LOCKED:
   - totp_enabled = true
   - totp_locked = true  # Can never be disabled!
   
6. All logins now require TOTP code
"""
