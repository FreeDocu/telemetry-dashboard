# Integration Guide - Advanced Features

## Overview

This guide explains how to use the advanced features added to the Telemetry Dashboard v1.1:

- **WebSocket Real-time Updates** - Live dashboard refresh
- **Prometheus Monitoring** - Metrics collection and visualization
- **Redis Caching** - Performance optimization
- **Background Jobs** - Automated analytics and cleanup
- **Advanced Analytics** - Cohort analysis, churn prediction, segmentation, LTV, geo insights
- **Security Hardening** - Rate limiting, request signing, security headers
- **Frontend Enhancements** - Dark/light theme, export, i18n, keyboard shortcuts
- **Comprehensive Testing** - pytest fixtures and test suite

---

## WebSocket Real-time Updates

### Connection

```typescript
// React component
import { useEffect, useState } from 'react';

function DashboardLiveUpdates() {
  const [launches, setLaunches] = useState([]);

  useEffect(() => {
    const ws = new WebSocket('ws://localhost:8000/ws/updates');
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      if (data.type === 'launch_event') {
        setLaunches(prev => [data.data, ...prev]);
      } else if (data.type === 'metric_update') {
        console.log(`${data.metric} = ${data.value}`);
      } else if (data.type === 'alert') {
        console.warn(`[${data.severity}] ${data.message}`);
      }
    };

    ws.onopen = () => {
      // Send heartbeat to keep connection alive
      setInterval(() => ws.send('ping'), 30000);
    };

    return () => ws.close();
  }, []);

  return <div>{launches.length} launches</div>;
}
```

### Server Broadcasting

The backend broadcasts events to all connected clients:

```python
# Send launch event
from app.websocket import broadcast_launch_event

launch_data = {
    "id": str(launch.id),
    "hwid": launch.hwid,
    "country": launch.country,
    "exe_version": launch.exe_version,
    "timestamp": launch.launched_at.isoformat()
}
await broadcast_launch_event(launch_data)

# Send alert
from app.websocket import broadcast_alert

await broadcast_alert(
    alert_type="anomaly_detected",
    message="100+ launches in 15 minutes from HWID-XXX",
    severity="warning"
)
```

### Live Stats Endpoint

```typescript
// Get live KPI updates every 10 seconds
const ws = new WebSocket('ws://localhost:8000/ws/live-stats');

ws.onmessage = (event) => {
  const { launches_today, unique_hwids_today } = JSON.parse(event.data);
  // Update UI with fresh stats
};
```

---

## Prometheus Monitoring

### Access Metrics

Metrics are exposed at `/metrics` endpoint in Prometheus format:

```bash
curl http://localhost:8000/metrics
```

### Tracked Metrics

| Metric | Type | Labels | Purpose |
|--------|------|--------|---------|
| `http_request_count` | Counter | method, endpoint, status | Request volume |
| `http_request_duration` | Histogram | method, endpoint | Request latency |
| `active_users` | Gauge | - | Current connected users |
| `launches_total` | Counter | token_id, country | Total launches |
| `unique_hwids` | Gauge | - | Unique user count |
| `banned_hwids_counter` | Counter | reason | Ban events |
| `database_query_duration` | Histogram | query_type | DB performance |
| `authentication_failures` | Counter | reason | Auth issues |

### Prometheus Configuration

```yaml
# prometheus.yml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'telemetry-dashboard'
    static_configs:
      - targets: ['localhost:8000']
    metrics_path: '/metrics'
```

### Integration with Decorators

```python
from app.monitoring import track_request, track_db_query

@router.post("/endpoint")
@track_request("POST", "/endpoint")
async def my_endpoint():
    # Automatically tracked
    pass

@track_db_query("launches_query")
async def query_launches():
    # Database query time tracked
    pass
```

---

## Redis Caching

### Configuration

```python
from app.cache import cache

# Connect on startup
await cache.connect()

# Set cache
await cache.set("key", {"data": "value"}, ttl=3600)

# Get from cache
value = await cache.get("key")

# Delete
await cache.delete("key")

# Clear pattern
await cache.clear_pattern("cohort_*")
```

### Automatic Caching in Analytics

```python
# Analytics endpoints automatically cache results
GET /api/v1/analytics/cohort-analysis  # Cached 1 hour
GET /api/v1/analytics/user-segments     # Cached 1 hour
GET /api/v1/analytics/geographic-insights  # Cached 1 hour

# Update cache manually after data changes
await cache.clear_pattern("cohort_*")
await cache.clear_pattern("analysis_*")
```

### Redis Graceful Degradation

If Redis is unavailable:
- Cache operations return `None` gracefully
- Application continues without caching
- No hard failures or exceptions

---

## Background Jobs (APScheduler)

### Configured Jobs

#### 1. Retention Metrics (Hourly)
```python
# Calculates D1, D7, D14, D30 retention
# Results cached to Redis for quick dashboard access
schedule: Every 1 hour
cache_key: retention_metrics:{date}
```

#### 2. Data Cleanup (Daily 2 AM)
```python
# Deletes launches older than 90 days
# Clears associated cache entries
schedule: Daily at 02:00 UTC
cleanup_duration: 90 days
```

#### 3. Anomaly Detection (Every 15 minutes)
```python
# Detects HWIDs with 100+ launches in 15-minute window
# Caches suspicious HWIDs for frontend filtering
schedule: Every 15 minutes
threshold: 100 launches/15 min
cache_key: suspicious:{hwid}
```

#### 4. Analytics Cache Refresh (Hourly)
```python
# Pre-caches top countries, versions, segments
# Improves dashboard responsiveness
schedule: Every 1 hour
cache_keys: top_countries, top_versions, segments
```

### Managing Jobs

```python
from app.jobs import scheduler

# Initialize on startup
scheduler.init_scheduler()

# Check job status
for job in scheduler.get_jobs():
    print(f"{job.name}: {job.next_run_time}")

# Shutdown gracefully
await scheduler.shutdown_scheduler()
```

---

## Advanced Analytics Endpoints

### 1. Cohort Analysis

```bash
GET /api/v1/analytics/cohort-analysis

Response:
{
  "2024-01-15": {
    "d0": 1000,
    "d1": 850,
    "d7": 620,
    "d14": 490,
    "d30": 380
  },
  ...30 days of cohorts...
}
```

### 2. Churn Prediction

```bash
GET /api/v1/analytics/churn-prediction?period_days=7

Response:
{
  "at_risk_count": 45,
  "sample_hwids": ["HWID-001", "HWID-002", ...],
  "period_days": 7,
  "definition": "Inactive 7 days but active before"
}
```

### 3. User Segmentation

```bash
GET /api/v1/analytics/user-segments

Response:
{
  "power_users": {
    "count": 150,
    "sample": ["HWID-001", "HWID-002", ...]
  },
  "regular_users": {
    "count": 2500,
    "sample": [...]
  },
  "inactive_users": {
    "count": 800,
    "sample": [...]
  }
}
```

### 4. Lifetime Value (LTV)

```bash
GET /api/v1/analytics/hwid/HWID-001/lifetime-value

Response:
{
  "hwid": "HWID-001",
  "total_launches": 245,
  "first_seen": "2024-01-01T10:30:00",
  "last_seen": "2024-01-15T14:22:00",
  "lifetime_days": 14.17,
  "avg_launches_per_day": 17.3,
  "distinct_tokens_used": 2,
  "distinct_versions": 4
}
```

### 5. Geographic Insights

```bash
GET /api/v1/analytics/geographic-insights

Response:
{
  "insights": [
    {
      "country": "US",
      "launches": 5000,
      "unique_hwids": 1200,
      "week_over_week_growth": 12.5
    },
    ...top 10 countries...
  ]
}
```

### 6. Country Trends

```bash
GET /api/v1/analytics/country/US/trends?period_days=30

Response:
[
  {
    "date": "2024-01-01",
    "launches": 150,
    "unique_hwids": 40
  },
  ...daily data...
]
```

---

## Security Hardening

### Rate Limiting

```python
# Configured rate limits
/api/v1/auth/login: 5 attempts/minute
/api/v1/telemetry/ping: 1000 pings/minute
/api/v1/admin/tokens: 100 requests/minute

# Response when limit exceeded
{
  "detail": "Rate limit exceeded. Try again later."
}
```

### Request Signing (Optional)

```python
# For enhanced security, clients can sign requests

import hmac
import hashlib
import time

def sign_request(body: bytes, secret_key: str) -> dict:
    timestamp = str(int(time.time()))
    signature = hmac.new(
        secret_key.encode(),
        body + timestamp.encode(),
        hashlib.sha256  
    ).hexdigest()
    
    return {
        "X-Signature": signature,
        "X-Timestamp": timestamp
    }

# Usage
headers = sign_request(request_body, "your-secret-key")
requests.post(url, data=request_body, headers=headers)
```

### Security Headers

All responses include:

```
Content-Security-Policy: Restricts script execution
X-Content-Type-Options: Prevents MIME sniffing
X-Frame-Options: Prevents clickjacking
X-XSS-Protection: XSS attack prevention
Strict-Transport-Security: HTTPS enforcement
Referrer-Policy: Referrer information control
Permissions-Policy: Restricts browser features
```

---

## Frontend Enhancements

### Dark/Light Theme Toggle

```typescript
import { useTheme, applyTheme } from '@/store/theme';
import { ThemeToggle } from '@/components/SettingsModals';

function App() {
  const { theme, toggleTheme } = useTheme();
  
  useEffect(() => {
    applyTheme(theme); // Apply on mount and theme change
  }, [theme]);

  return (
    <div>
      <ThemeToggle />
      {/* Rest of app */}
    </div>
  );
}
```

Theme is persisted to localStorage automatically.

### Chart Export

```typescript
import { exportChartAsPNG, exportDataAsCSV } from '@/utils/export';

// Export chart as PNG
<button onClick={() => exportChartAsPNG('chart-element', 'retention-chart')}>
  Export as PNG
</button>

// Export data as CSV
<button onClick={() => exportDataAsCSV([...], 'launches-data')}>
  Export as CSV
</button>

// Export data as JSON
exportDataAsJSON({...}, 'analytics-result');
```

### Keyboard Shortcuts

```typescript
import { useKeyboardShortcuts, getShortcutsList } from '@/hooks/useKeyboardShortcuts';

function DashboardPage() {
  useKeyboardShortcuts(); // Enables all shortcuts
  
  // Available shortcuts:
  // Cmd+K - Command palette (macOS) or Ctrl+K (Windows)
  // Cmd+S - Save dashboard
  // G, then D - Go to Dashboard
  // G, then T - Go to Tokens  
  // G, then B - Go to Bans
  // G, then S - Go to Settings
  // ? - Show shortcuts help
}
```

### Internationalization (i18n)

```typescript
import { useTranslation } from 'react-i18next';
import i18n from '@/i18n/config';

function Component() {
  const { t, i18n } = useTranslation();
  
  return (
    <div>
      <h1>{t('dashboard')}</h1>
      <p>{t('launchesToday')}</p>
      
      {/* Change language */}
      <button onClick={() => i18n.changeLanguage('ru')}>
        Русский
      </button>
    </div>
  );
}
```

Supported languages: English, Russian

---

## Testing

### Run Tests

```bash
cd backend
pip install pytest pytest-asyncio httpx

# Run all tests
pytest -v

# Run specific test file
pytest tests/test_auth.py -v

# Run with coverage
pytest --cov=app tests/
```

### Test Structure

```
backend/tests/
├── conftest.py          # Fixtures and test database
├── test_auth.py         # Authentication tests
├── test_telemetry.py    # Telemetry endpoint tests
└── test_analytics.py    # Analytics service tests
```

### Example Test

```python
import pytest
from app.security import hash_password, verify_password

def test_password_hashing():
    password = "testpass123"
    hash1 = hash_password(password)
    
    assert verify_password(password, hash1)
    assert not verify_password("wrong", hash1)
```

---

## Deployment

### Environment Variables

Essential for production:

```bash
SECRET_KEY=your-256-char-secret-key
DATABASE_URL=postgresql://user:pass@host/db
REDIS_URL=redis://redis-host:6379/0
ALLOWED_ORIGINS=https://yourdomain.com
ENVIRONMENT=production
DEBUG=false
LOG_LEVEL=WARNING
```

### Docker Compose Production

```bash
# Build images
docker-compose build

# Start services
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f backend
docker-compose logs -f frontend

# Monitor metrics
curl http://localhost:8000/metrics
```

### Health Checks

```bash
# API health
curl http://localhost:8000/health

# Database connected
curl http://localhost:8000/api/v1/admin/health

# Redis connected (check logs)
docker-compose logs redis
```

---

## Troubleshooting

### Redis Connection Failed
- Check Redis is running: `docker-compose logs redis`
- Verify REDIS_URL in .env
- App will continue without caching (graceful degradation)

### Background Jobs Not Running
- Check scheduler is initialized in main.py startup
- View logs: `docker-compose logs backend`
- Verify APScheduler dependencies installed

### WebSocket Connection Issues
- Check firewall allows WebSocket (port 8000)
- Browser console shows connection errors
- Fallback to HTTP polling for updates

### Rate Limit Too Strict
- Adjust RATE_LIMITS in `security_headers.py`
- Redeploy backend: `docker-compose restart backend`

---

## Performance Optimization Tips

1. **Database Queries**: Use `optimize_launch_query()` with pagination
2. **Caching**: Redis caches hot data automatically
3. **Batch Operations**: Background jobs run off-peak hours
4. **Monitoring**: Prometheus tracks bottlenecks via metrics
5. **Frontend**: Export data asynchronously to prevent UI blocking

---

## Support

For issues or questions:

1. Check logs: `docker-compose logs {service}`
2. Review ARCHITECTURE.md for system design
3. Check CONTRIBUTING.md for development setup
4. Open issue on GitHub with error details and steps to reproduce
