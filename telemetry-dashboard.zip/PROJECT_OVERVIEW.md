# Telemetry Dashboard - Complete Project Overview

## 📊 What You're Getting

A **production-ready telemetry monitoring dashboard** for .exe applications with:

- ✅ **One-time 2FA setup**: TOTP permanently locked after initial activation
- ✅ **Secure token management**: Create/revoke tokens for applications
- ✅ **HWID blacklist**: Ban devices (temporary/permanent)
- ✅ **Real-time analytics**: Launches, retention, geography, versions
- ✅ **Customizable dashboard**: Drag-and-drop widgets with persistent layout
- ✅ **Professional UI**: Dark mode, glassmorphism, smooth animations
- ✅ **Fully responsive**: Mobile/tablet/desktop support

## 🎯 25 Files Created

### Backend (Python/FastAPI)
1. `backend/main.py` - FastAPI application entry point
2. `backend/app/config.py` - Settings management
3. `backend/app/database.py` - SQLAlchemy async setup
4. `backend/app/security.py` - JWT + TOTP + password hashing
5. `backend/app/geoip.py` - GeoIP country lookup
6. `backend/app/models/admin.py` - Admin user model
7. `backend/app/models/token.py` - App tokens model
8. `backend/app/models/launch.py` - Launch records model
9. `backend/app/models/banned_hwid.py` - HWID ban model
10. `backend/app/models/dashboard.py` - Dashboard layout model
11. `backend/app/routes/auth.py` - Login, TOTP endpoints
12. `backend/app/routes/telemetry.py` - /telemetry/ping endpoint
13. `backend/app/routes/admin.py` - Token & ban management
14. `backend/app/routes/analytics.py` - Analytics/stats endpoints
15. `backend/app/routes/dashboard.py` - Dashboard layout endpoints
16. `backend/app/schemas/telemetry.py` - Telemetry request/response models
17. `backend/app/schemas/auth.py` - Auth models
18. `backend/app/schemas/token.py` - Token models
19. `backend/app/schemas/dashboard.py` - Dashboard layout models
20. `backend/scripts/init_admin.py` - Create initial admin user
21. `backend/requirements.txt` - Python dependencies
22. `backend/.env` - Environment variables (example)

### Frontend (React/TypeScript)
23. `frontend/src/App.tsx` - Root component with routing
24. `frontend/src/main.tsx` - React entry point
25. `frontend/src/pages/LoginPage.tsx` - Login form with TOTP
26. `frontend/src/pages/DashboardPage.tsx` - Main dashboard
27. `frontend/src/pages/TokenManagementPage.tsx` - Token CRUD
28. `frontend/src/pages/SettingsPage.tsx` - Admin settings
29. `frontend/src/pages/BanManagementPage.tsx` - HWID ban management
30. `frontend/src/components/KPICard.tsx` - Metrics display
31. `frontend/src/components/FilterPanel.tsx` - Global filters
32. `frontend/src/components/RetentionChart.tsx` - Retention curves
33. `frontend/src/components/ActivityHeatmap.tsx` - 24×7 heatmap
34. `frontend/src/components/TopHWIDsTable.tsx` - Device table
35. `frontend/src/components/GeographyChart.tsx` - Country stats
36. `frontend/src/components/VersionChart.tsx` - Version distribution
37. `frontend/src/components/DashboardGrid.tsx` - react-grid-layout wrapper
38. `frontend/src/components/Navbar.tsx` - Top navigation
39. `frontend/src/components/Sidebar.tsx` - Left sidebar
40. `frontend/src/api/client.ts` - Axios instance + interceptors
41. `frontend/src/api/index.ts` - API functions
42. `frontend/src/store/auth.ts` - Auth state (Zustand)
43. `frontend/src/store/filters.ts` - Dashboard filters (Zustand)
44. `frontend/src/styles/index.css` - Tailwind + custom styles
45. `frontend/package.json` - Node dependencies
46. `frontend/vite.config.ts` - Vite configuration
47. `frontend/tsconfig.json` - TypeScript config
48. `frontend/tailwind.config.js` - Tailwind configuration
49. `frontend/postcss.config.js` - PostCSS config
50. `frontend/index.html` - HTML template

### Configuration & Documentation
51. `docker-compose.yml` - Development Docker setup
52. `backend/Dockerfile` - Backend image
53. `frontend/Dockerfile` - Frontend image
54. `README.md` - Complete user documentation
55. `ARCHITECTURE.md` - Technical architecture guide
56. `EXAMPLES.md` - API usage examples
57. `CONTRIBUTING.md` - Development contribution guide
58. `package.json` - Root project metadata
59. `.vscode/settings.json` - VS Code configuration
60. `.vscode/extensions.json` - Recommended extensions
61. `run.sh` - Local development launcher
62. `build.sh` - Production build script
63. `.gitignore` - Git ignore rules (backend & frontend)
64. `.env.example` - Environment template files

## 🚀 Quick Start

### 1. Install Dependencies
```bash
cd backend
pip install -r requirements.txt

cd ../frontend
npm install
```

### 2. Configure Environment
```bash
cd backend
cp .env.example .env
# Edit .env with your PostgreSQL URL and SECRET_KEY
```

### 3. Setup Database
```bash
# Create PostgreSQL database
createdb -U postgres telemetry_db

# Initialize admin user
python scripts/init_admin.py
```

### 4. Run Services
```bash
# Terminal 1 - Backend
cd backend
python main.py

# Terminal 2 - Frontend
cd frontend
npm run dev
```

Visit: **http://localhost:5173**
Default credentials: **admin** / **admin123**

## 📱 Key Features

### Admin Functions
- ✅ JWT authentication with TOTP 2FA (one-time permanent setup)
- ✅ Create/manage application tokens
- ✅ View real-time telemetry from apps
- ✅ Ban HWIDs (temporary or permanent)
- ✅ Analyze user retention across D1/D3/D7/D14/D30
- ✅ Monitor geographical distribution
- ✅ Track version adoption

### Dashboard Widgets
1. **KPI Cards** - Unique HWIDs, launches today, retention percentages
2. **Global Filters** - Period, tokens, countries, versions, suspended/banned
3. **Retention Curves** - Multi-line chart (D1, D7, D30)
4. **Activity Heatmap** - 24h × 7 days launches pattern
5. **Top HWIDs** - Most active devices with sparklines
6. **Geography** - Choropleth map + country distribution
7. **Versions** - Pie & stacked bar charts

### Persistence
- 📦 Dashboard layout saved to PostgreSQL (JSONB)
- 🔄 Analytics filters in Zustand store
- 🔐 JWT token in localStorage

## 🛠️ Technology Stack

| Layer | Technology | Version |
|-------|-----------|---------|
| **Backend** | FastAPI | 0.104+ |
| **Database** | PostgreSQL | 13+ |
| **ORM** | SQLAlchemy | 2.0+ |
| **Auth** | JWT + TOTP | - |
| **Frontend** | React | 18.2+ |
| **Bundler** | Vite | 5.0+ |
| **State** | Zustand | 4.4+ |
| **Data Fetch** | TanStack Query | 5.25+ |
| **Charts** | Recharts + Tremor | Latest |
| **Styling** | Tailwind CSS | 3.3+ |
| **Grid Layout** | react-grid-layout | 1.4+ |

## 📚 Documentation Files

- **README.md** - User guide, API docs, deployment
- **ARCHITECTURE.md** - Technical deep dive, database schema, security
- **EXAMPLES.md** - API request/response examples, workflows
- **CONTRIBUTING.md** - Development guidelines

## 🔒 Security Features

✅ **Password Security**
- Bcrypt hashing with salt
- Minimum 12 characters recommended

✅ **2FA Protection**
- TOTP (Time-based One-Time Password)
- QR code generation for authenticator apps
- **Permanent lock** after first setup (cannot be disabled)

✅ **API Security**
- JWT tokens with 1-hour expiration
- Authorization header validation on all endpoints
- CORS protection

✅ **Device Security**
- HWID-based device tracking
- Temporary/permanent bans
- Anomaly detection placeholder

## 📊 Database Schema

5 core tables:
- `admin_user` - Single admin record
- `tokens` - Application tokens
- `launches` - Launch events (main data)
- `banned_hwids` - Device blacklist
- `dashboard_layout` - Persisted UI layout (JSONB)

## 🎨 Design Highlights

- **Dark mode** by default (glassmorphism effect)
- **Micro-animations** on all interactions
- **Fully responsive** (mobile → desktop)
- **Custom color gradients** for KPI cards
- **Smooth transitions** and hover effects

## 📈 Next Steps for Production

1. Change **SECRET_KEY** to strong random value (32+ chars)
2. Change default **admin password**
3. Configure **PostgreSQL** with strong credentials
4. Download **MaxMind GeoIP database**
5. Set **ALLOWED_ORIGINS** to production domain
6. Enable **HTTPS** with Let's Encrypt
7. Configure **automated backups**
8. Set up **monitoring/logging**
9. Load test with realistic data

## 🐛 Support & Troubleshooting

See **README.md** section "Troubleshooting" for:
- Database connection errors
- CORS issues
- TOTP problems
- Development tips

## 📝 License

Proprietary & Confidential - This project is for authorized use only.

---

**Built for professional telemetry monitoring** 🎯

Questions? See CONTRIBUTING.md or ARCHITECTURE.md for detailed technical information.
