# Telemetry Dashboard - Modern Monitoring System

> 📊 Professional telemetry dashboard for .exe applications (2025-2026 style)

## 🎯 Features

### Backend
- ✅ FastAPI async framework with SQLAlchemy ORM
- ✅ PostgreSQL database with async support
- ✅ JWT authentication + TOTP 2FA (one-time setup, permanent lock)
- ✅ Token management system for .exe applications
- ✅ HWID blacklist (temporary/permanent bans)
- ✅ GeoIP location tracking
- ✅ Comprehensive analytics API

### Frontend
- ✅ React + Vite (lightning-fast development)
- ✅ Dark mode with glassmorphism design
- ✅ Fully customizable drag-and-drop dashboard
- ✅ TanStack Query for data fetching
- ✅ Zustand for state management
- ✅ Recharts + Tremor for visualizations
- ✅ Responsive grid layout (mobile-friendly)

### Monitoring Features
- 📈 Real-time KPI cards (unique HWIDs, launches, retention)
- 📊 Retention curves (D1/D3/D7/D14/D30)
- 🔥 Activity heatmap (24h × 7 days)
- 🌍 Geography analytics (choropleth + top countries)
- 📱 Device tracking & suspicious activity detection
- 🎯 Version distribution (pie/stacked charts)
- 🎛️ Global filters with presets

## 🚀 Quick Start

### Prerequisites
- Python 3.11+
- Node.js 18+
- PostgreSQL 13+
- pip, npm/yarn

### Installation

```bash
# Clone repository
git clone <repo>
cd telemetry-dashboard

# Run setup script
bash setup.sh
```

### Manual Setup

#### Backend
```bash
cd backend

# Install dependencies
pip install -r requirements.txt

# Configure .env
cp .env.example .env
# Edit .env with your values

# Create databases
createdb -U postgres telemetry_db

# Initialize admin user
python scripts/init_admin.py

# Run server
python main.py
```

#### Frontend
```bash
cd frontend

# Install dependencies
npm install

# Create .env.local
echo "VITE_API_URL=http://localhost:8000/api/v1" > .env.local

# Development server
npm run dev

# Build for production
npm run build
```

## 📡 API Documentation

### Authentication
```bash
POST /api/v1/auth/login
{
  "username": "admin",
  "password": "your_password",
  "totp_code": "123456"  # Optional if 2FA enabled
}

Response:
{
  "access_token": "eyJ0...",
  "token_type": "bearer",
  "expires_in": 3600
}
```

### Telemetry Ping
```bash
POST /api/v1/telemetry/ping
{
  "token": "your_app_token",
  "hwid": "stable_hardware_id",
  "exe_version": "1.0.0",
  "os": "Windows 10",
  "launch_id": "optional_uuid",
  "extra": {}
}
```

### Token Management
```bash
# Create token
POST /api/v1/admin/tokens
{ "name": "App v1", "note": "Production", "expires_at": "2026-12-31T23:59:59Z" }

# List tokens
GET /api/v1/admin/tokens

# Update token
PATCH /api/v1/admin/tokens/{token_id}
{ "active": false }

# Delete token
DELETE /api/v1/admin/tokens/{token_id}
```

### HWID Ban
```bash
POST /api/v1/admin/bans/hwid
{
  "hwid": "HWID-123",
  "reason": "Suspicious activity",
  "token_id": "token-uuid",  # Optional
  "until": "2026-03-01T00:00:00Z"  # NULL = permanent
}

GET /api/v1/admin/bans/hwid
DELETE /api/v1/admin/bans/hwid/{hwid}
```

### Analytics
```bash
# Summary stats
GET /api/v1/analytics/summary?period_hours=24&token_ids=[]

# Timeline
GET /api/v1/analytics/launches/timeline?period_hours=24&interval=hour

# Countries
GET /api/v1/analytics/analytics/countries?limit=10

# HWIDs
GET /api/v1/analytics/analytics/hwids?limit=10

# Versions
GET /api/v1/analytics/analytics/versions
```

### Dashboard Layout
```bash
# Get layout
GET /api/v1/dashboard/layout

# Save layout
POST /api/v1/dashboard/layout
{ "layout": [...] }

# Reset to default
POST /api/v1/dashboard/layout/reset
```

## 🔐 Security

### 2FA Setup (One-Time Only)
1. Admin starts 2FA setup: `POST /api/v1/auth/totp/setup` + password
2. Backend returns QR code + secret
3. Admin scans QR code in authenticator app
4. Admin confirms with TOTP code: `POST /api/v1/auth/totp/confirm`
5. `totp_locked = true` in DB — setup disabled forever

### Password Requirements
- Minimum 12 characters (recommended)
- Change default password immediately
- Use strong, unique passwords

### Token Expiration
- Tokens can have optional expiration date
- Inactive tokens can be deactivated without deletion

## 🗄️ Database Schema

```sql
-- Admin User
CREATE TABLE admin_user (
  id STRING PRIMARY KEY,
  username STRING UNIQUE NOT NULL,
  password_hash STRING NOT NULL,
  totp_secret STRING,
  totp_enabled BOOLEAN,
  totp_locked BOOLEAN  -- Can't change 2FA after setup
);

-- App Tokens
CREATE TABLE tokens (
  id STRING PRIMARY KEY,
  token STRING UNIQUE NOT NULL,
  name STRING NOT NULL,
  note STRING,
  active BOOLEAN,
  current_version STRING,
  expires_at DATETIME,
  created_at DATETIME
);

-- Launch Records
CREATE TABLE launches (
  id STRING PRIMARY KEY,
  token_id STRING NOT NULL FK,
  hwid STRING NOT NULL,
  ip STRING NOT NULL,
  country STRING,
  os STRING,
  exe_version STRING,
  launched_at DATETIME,
  extra JSONB
);

-- Hardware Bans
CREATE TABLE banned_hwids (
  hwid STRING PRIMARY KEY,
  token_id STRING FK,
  reason STRING,
  banned_at DATETIME,
  banned_by STRING,
  until DATETIME  -- NULL = permanent
);

-- Dashboard Layouts
CREATE TABLE dashboard_layout (
  user_id STRING PRIMARY KEY,
  layout_json JSONB,
  created_at DATETIME,
  updated_at DATETIME
);
```

## 📦 Environment Variables

### Backend (.env)
```
DATABASE_URL=postgresql+asyncpg://user:pass@localhost/telemetry_db
SECRET_KEY=your-256-bit-secret-key-here
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=60
TOTP_ISSUER=TelemetryDashboard
GEOIP_DB_PATH=./data/GeoLite2-Country.mmdb
ALLOWED_ORIGINS=["http://localhost:5173","http://localhost:3000"]
API_PREFIX=/api/v1
```

### Frontend (.env.local)
```
VITE_API_URL=http://localhost:8000/api/v1
```

## 🎨 Dashboard Customization

### Default Widget Layout
- **Row 1:** KPI cards (Unique HWIDs, Launches, Retention D1/D7/D30)
- **Row 2:** Global filters + presets
- **Row 3:** Retention curves (full width)
- **Rows 4-5:** Activity heatmap, Top HWIDs, Geography, Versions

### Custom Layouts
1. Click "Edit Layout" button
2. Drag/resize widgets
3. Changes save automatically to database
4. Admin can reset to default layout anytime

## 🧪 Testing

```bash
# Backend tests (to be implemented)
cd backend
pytest

# Frontend tests (to be implemented)
cd frontend
npm test
```

## 📝 Deployment

### Docker (Recommended)
```bash
# Build images
docker-compose build

# Run containers
docker-compose up -d

# Check logs
docker-compose logs -f
```

### Manual Deployment
1. Use systemd/supervisor for backend service
2. Use Nginx reverse proxy
3. Configure HTTPS with Let's Encrypt
4. Set strong SECRET_KEY in production
5. Use strong admin password
6. Enable database backups

## 🐛 Troubleshooting

### Database Connection Error
```
Check PostgreSQL is running:
sudo systemctl status postgresql

Reset database:
dropdb telemetry_db
createdb telemetry_db
```

### CORS Error
- Frontend and backend URLs must be in `ALLOWED_ORIGINS`
- Clear browser cache after updating .env

### TOTP Not Working
- Check server time is synchronized (NTP)
- Use authenticator app time properly
- Regenerate secret if stuck (DB edit required)

## 📚 Additional Resources

- [FastAPI Docs](https://fastapi.tiangolo.com/)
- [React 18 Docs](https://react.dev/)
- [SQLAlchemy Async](https://docs.sqlalchemy.org/en/20/orm/extensions/asyncio.html)
- [Zustand Store](https://github.com/pmndrs/zustand)
- [Recharts](https://recharts.org/)
- [Tailwind CSS](https://tailwindcss.com/)

## 📄 License

This project is proprietary and confidential.

---

**Made with ❤️ for monitoring experts**
