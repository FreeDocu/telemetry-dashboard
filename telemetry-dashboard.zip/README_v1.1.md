# Telemetry Dashboard - Enterprise-Grade Monitoring System

> **Complete telemetry and monitoring solution for .exe applications** with JWT+TOTP authentication, real-time analytics, advanced segmentation, and production-ready DevOps tooling.

![Version](https://img.shields.io/badge/version-1.1-blue)
![Python](https://img.shields.io/badge/python-3.11+-blue)
![React](https://img.shields.io/badge/react-18.2+-blue)
![License](https://img.shields.io/badge/license-MIT-green)

## 🎯 Features

### Core Features (v1.0)
- ✅ **JWT + TOTP 2FA Authentication** - Single admin account with permanent TOTP lock
- ✅ **Token Management** - Create/revoke API tokens with expiration support
- ✅ **HWID Blacklist** - Temporary and permanent bans with reasons
- ✅ **GeoIP Integration** - Track launches by country
- ✅ **Drag-and-drop Dashboard** - 11 customizable widgets with layout persistence
- ✅ **Dark Mode** - Glassmorphism UI with Tailwind CSS
- ✅ **Real-time Analytics** - Launches, unique users, retention metrics

### Advanced Features (v1.1) - NEW ⭐
- ✅ **WebSocket Real-time Updates** - Live dashboard refresh with launch events
- ✅ **Prometheus Monitoring** - 8 metric types with `/metrics` endpoint
- ✅ **Redis Caching** - Async caching with graceful fallback
- ✅ **APScheduler Background Jobs** - 4 automated tasks (retention, cleanup, anomaly, cache)
- ✅ **Advanced Analytics** - Cohort analysis, churn prediction, segmentation, LTV, geo insights
- ✅ **Rate Limiting** - Configurable per-endpoint rate limits
- ✅ **Security Headers** - CSP, HSTS, XSS protection, clickjacking prevention
- ✅ **Comprehensive Testing** - pytest with async fixtures, 4 test modules
- ✅ **Dark/Light Theme Toggle** - Persistent theme with localStorage
- ✅ **Data Export** - PNG charts, CSV data, JSON export
- ✅ **Internationalization** - English & Russian with i18next
- ✅ **Keyboard Shortcuts** - Command palette, navigation, menu access
- ✅ **Production Docker Setup** - PostgreSQL, Redis, multi-container orchestration

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose
- OR: Python 3.11+, Node.js 18+, PostgreSQL 15+, Redis 7+

### Option 1: Docker (Recommended)

```bash
# Clone repository
git clone <repo-url>
cd telemetry-dashboard

# Copy and configure environment
cp backend/.env.example backend/.env
# Edit backend/.env with your SECRET_KEY

# Start all services
docker-compose up -d

# Check status
docker-compose ps

# Access services
# Frontend: http://localhost:5173
# Backend API: http://localhost:8000/api/v1
# Health: http://localhost:8000/health
# Metrics: http://localhost:8000/metrics
```

### Option 2: Local Development

```bash
# Backend
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
python -m uvicorn app.main:app --reload

# Frontend (in new terminal)
cd frontend
npm install
npm run dev
```

## 📊 Dashboard Capabilities

### KPI Widgets
- **Launches Today** - Real-time launch counter with trend
- **Unique Users** - Active unique HWIDs
- **Top Countries** - Geographic distribution
- **App Versions** - Version adoption tracking
- **Retention Curves** - D1, D7, D14, D30 metrics
- **Activity Heatmap** - 7×24 hour activity grid
- **Top HWIDs** - Power users with last seen time
- **Suspicious Activity** - Anomaly-flagged users
- **Filter Panel** - Time range, token, country, version filters
- **Retention Chart** - Historical retention trends
- **Geography Chart** - Country rankings

### Advanced Analytics
```bash
# Cohort Retention
GET /api/v1/analytics/cohort-analysis
# → {date: {d0, d1, d7, d14, d30}, ...}

# Churn Prediction
GET /api/v1/analytics/churn-prediction?period_days=7
# → {at_risk_count: 45, sample_hwids: [...]}

# User Segments
GET /api/v1/analytics/user-segments
# → {power_users, regular_users, inactive_users}

# Lifetime Value
GET /api/v1/analytics/hwid/{hwid}/lifetime-value
# → {total_launches, lifetime_days, avg_launches_per_day, ...}

# Geographic Insights
GET /api/v1/analytics/geographic-insights
# → [{country, launches, unique_hwids, week_over_week_growth}, ...]

# Country Trends
GET /api/v1/analytics/country/US/trends?period_days=30
# → [{date, launches, unique_hwids}, ...]
```

## 🔐 Security

### Authentication Flow
1. **Admin Login** - Username/password with JWT token (1-hour expiry)
2. **TOTP 2FA** - Time-based one-time password (permanent lock after setup)
3. **API Tokens** - For application telemetry submission
4. **Token Validation** - Active status, expiration check, HWID ban verification

### Security Features
- **JWT Tokens** - HS256 signed, configurable expiration
- **TOTP 2FA** - TOTP-standard compatible, permanent one-time setup
- **Password Hashing** - bcrypt with salt
- **HWID Bans** - Temporary (datetime) or permanent (null until)
- **Rate Limiting** - Per-endpoint: login 5/min, ping 1000/min, admin 100/min
- **Request Signing** - Optional HMAC-SHA256 signature verification
- **Security Headers** - CSP, HSTS, X-Frame-Options, X-XSS-Protection
- **CORS** - Configurable allowed origins

### Monitoring
- 8 Prometheus metrics for visualization
- JSON-formatted structured logging
- Failed authentication tracking
- Database query performance monitoring

## 📈 Real-time Features

### WebSocket Connections
```typescript
// Live launch events
const ws = new WebSocket('ws://localhost:8000/ws/updates');
ws.onmessage = (event) => {
  const {type, data} = JSON.parse(event.data);
  // type: 'launch_event', 'metric_update', 'alert'
};

// Live KPI stats (10-second updates)
const wsStats = new WebSocket('ws://localhost:8000/ws/live-stats');
```

### Background Jobs
| Job | Schedule | Purpose |
|-----|----------|---------|
| Retention Metrics | Hourly | Calculate D1/D7/D14/D30 retention |
| Data Cleanup | Daily 2 AM | Delete launches > 90 days old |
| Anomaly Detection | Every 15 min | Flag 100+ launches/15 min |
| Analytics Cache | Hourly | Pre-cache top countries, segments |

## 🛠️ Tech Stack

### Backend
- **Framework**: FastAPI 0.104+ (async)
- **Database**: PostgreSQL 15+ (async with asyncpg)
- **ORM**: SQLAlchemy 2.0 (async)
- **Auth**: JWT + TOTP (pyotp)
- **Caching**: Redis 7+ (async)
- **Jobs**: APScheduler (async-compatible)
- **Monitoring**: Prometheus client
- **Logging**: python-json-logger
- **Testing**: pytest + pytest-asyncio

### Frontend
- **Framework**: React 18.2+ (TypeScript)
- **Build**: Vite 5.0
- **State**: Zustand + TanStack Query
- **Styling**: Tailwind CSS 3.3+
- **Charts**: Recharts + Tremor
- **Layouts**: react-grid-layout
- **Export**: html2canvas + file-saver
- **i18n**: i18next + react-i18next
- **Icons**: lucide-react

### Infrastructure
- **Containerization**: Docker + Docker Compose
- **Orchestration**: docker-compose (production-ready)
- **Database**: PostgreSQL 15 Alpine
- **Cache**: Redis 7 Alpine
- **Reverse Proxy**: Not included (add nginx if needed)

## 📖 Documentation

| Document | Purpose |
|----------|---------|
| [QUICKSTART.md](QUICKSTART.md) | 5-minute setup guide |
| [ARCHITECTURE.md](ARCHITECTURE.md) | System design & database schema |
| [INTEGRATION.md](INTEGRATION.md) | Advanced features usage |
| [ADVANCED_FEATURES.md](ADVANCED_FEATURES.md) | v1.1 feature summary (THIS IS COMPREHENSIVE) |
| [EXAMPLES.md](EXAMPLES.md) | curl examples & integration patterns |
| [CONTRIBUTING.md](CONTRIBUTING.md) | Development setup & guidelines |

## 🧪 Testing

```bash
# Run all tests
pytest -v backend/tests/

# Run with coverage
pytest --cov=app backend/tests/

# Run specific test
pytest backend/tests/test_auth.py::test_password_hashing -v

# Watch mode
pytest-watch backend/tests/
```

**Test Coverage**:
- Authentication (JWT, TOTP, password hashing)
- Telemetry API (token validation, ban checking)
- Analytics service (aggregations, filtering)
- Test fixtures with async database

## 🚢 Deployment

### Environment Variables

```bash
# Database
DATABASE_URL=postgresql+asyncpg://user:pass@host/db

# API Security
SECRET_KEY=your-256-char-secret-key-minimum-32-chars
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=60

# 2FA
TOTP_ISSUER=YourCompanyName

# Redis (optional, graceful fallback)
REDIS_URL=redis://redis-host:6379/0
REDIS_ENABLED=true

# Logging
LOG_LEVEL=INFO
LOGS_DIR=logs

# Limits
ALLOWS_ORIGINS=https://yourdomain.com

# Environment
ENVIRONMENT=production
DEBUG=false
```

### Docker Production Setup

```bash
# Build images
docker-compose build

# Start services (background)
docker-compose up -d

# View logs
docker-compose logs -f backend
docker-compose logs -f frontend

# Stop services
docker-compose stop

# Remove everything
docker-compose down -v
```

### Health Checks

```bash
# API health
curl http://localhost:8000/health

# Prometheus metrics
curl http://localhost:8000/metrics | head -20

# Log files
docker-compose exec backend tail -f logs/app.json
```

## 📊 Performance

### Optimization Features
1. **Database Indexing** - 4 indexes on frequent queries
2. **Connection Pooling** - 20+10 PostgreSQL connections
3. **Query Pagination** - Default 50 rows, max 1000 per request
4. **Redis Caching** - 1-hour TTL on analytics
5. **Background Jobs** - Off-peak processing
6. **Async Throughout** - 40+ async functions in backend
7. **Lazy Loading** - Frontend pagination + virtual scrolling

### Benchmarks
- 1000 launches/minute: ✅ No issues
- 100K+ total records: ✅ Instant queries with pagination
- Multi-country filtering: ✅ Sub-second response
- Cohort calculation (30 days): ✅ 5-10 seconds (cached 1 hour)

## 🐛 Troubleshooting

### Backend Issues

**Redis Connection Failed** (Non-blocking)
```bash
# App continues without caching
ERROR: Redis connection failed
WARNING: Continuing without cache
```

**Database Connection Error**
```bash
# Check PostgreSQL is running
docker-compose logs postgres
# Check DATABASE_URL in .env
```

**Scheduler Not Starting**
```bash
# View logs
docker-compose logs backend
# Check APScheduler dependencies in requirements.txt
```

### Frontend Issues

**WebSocket Connection Refused**
- Check backend is running: `curl http://localhost:8000/health`
- Check firewall allows port 8000
- Browser dev tools → Network → WS filter

**Missing Translation**
- Check i18n config for language key
- Add translation in `frontend/src/i18n/config.ts`

## 🎓 Learning Resources

- **FastAPI**: https://fastapi.tiangolo.com/
- **React + TypeScript**: https://react-typescript-cheatsheet.netlify.app/
- **SQLAlchemy Async**: https://docs.sqlalchemy.org/en/20/orm/extensions/asyncio.html
- **Prometheus**: https://prometheus.io/docs/
- **Redis**: https://redis.io/docs/

## 📝 API Examples

### Create API Token
```bash
curl -X POST http://localhost:8000/api/v1/admin/tokens \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "My App",
    "note": "For production",
    "expires_at": "2025-12-31T23:59:59Z"
  }'
```

### Submit Telemetry
```bash
curl -X POST http://localhost:8000/api/v1/telemetry/ping \
  -H "Content-Type: application/json" \
  -d '{
    "token": "your-app-token",
    "hwid": "HWID-12345",
    "exe_version": "1.2.3",
    "os": "Windows 10",
    "extra": {"custom_field": "value"}
  }'
```

### Get Analytics
```bash
# Cohort retention
curl -X GET http://localhost:8000/api/v1/analytics/cohort-analysis \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"

# Churn prediction (7-day)
curl -X GET "http://localhost:8000/api/v1/analytics/churn-prediction?period_days=7" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

### Monitor Metrics
```bash
curl http://localhost:8000/metrics | grep http_request_count
curl http://localhost:8000/metrics | grep launches_total
```

## 🤝 Contributing

1. Fork repository
2. Create feature branch: `git checkout -b feature/amazing-feature`
3. Write tests covering your changes
4. Run test suite: `pytest backend/tests/`
5. Commit changes: `git commit -m 'Add amazing feature'`
6. Push to branch: `git push origin feature/amazing-feature`
7. Open Pull Request

See [CONTRIBUTING.md](CONTRIBUTING.md) for detailed guidelines.

## 📋 Roadmap

- [ ] GraphQL API endpoint
- [ ] Multi-tenant support
- [ ] Advanced anomaly detection (ML-based)
- [ ] Custom dashboard themes
- [ ] Mobile app for iOS/Android
- [ ] Webhook notifications
- [ ] API rate limiting per token
- [ ] Data retention policies
- [ ] Audit logging for admin actions
- [ ] Elasticsearch integration for logs

## 📄 License

MIT License - see LICENSE file

## 🙋 Support

- 📚 **Documentation**: See docs/ folder
- 🐛 **Issues**: GitHub Issues
- 💬 **Discussions**: GitHub Discussions
- 📧 **Email**: support@example.com

---

## 🎉 Quick Commands

```bash
# Development
docker-compose up -d              # Start all services
docker-compose logs -f backend    # View backend logs
docker-compose exec backend sh    # Shell into backend
npm run dev                        # Frontend dev server
pytest -v backend/tests/          # Run tests

# Production
docker-compose -f docker-compose.prod.yml up -d
docker-compose exec backend python -c "from app.jobs import scheduler; scheduler.init_scheduler()"

# Monitoring
curl http://localhost:8000/metrics      # Prometheus metrics
curl http://localhost:8000/health       # Health check
tail -f logs/app.json                   # View logs

# Database
docker-compose exec postgres psql -U telemetry -d telemetry_db
# SELECT * FROM launch ORDER BY launched_at DESC LIMIT 10;
```

---

**👤 Author**: Your Name  
**🚀 Status**: Production Ready v1.1  
**📅 Last Updated**: 2024  
**⭐ Star** this repo if you find it useful!
