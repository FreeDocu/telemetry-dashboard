from sqlalchemy import select, func, and_
from datetime import datetime, timedelta
from app.database import AsyncSessionLocal
from app.models import Launch
from app.cache import cache

class AnalyticsService:
    """Advanced analytics calculations"""
    
    @staticmethod
    async def get_cohort_analysis(start_date: str = None):
        """
        Cohort analysis: group users by signup date, track retention over time
        Returns: {
            "2026-02-01": {"d0": 500, "d1": 340, "d7": 120, "d30": 45},
            "2026-02-08": {"d0": 480, "d1": 320, "d7": 110}
        }
        """
        async with AsyncSessionLocal() as session:
            if not start_date:
                start_date = (datetime.utcnow() - timedelta(days=30)).date()
            
            # Get unique HWIDs per day (cohort)
            cohorts = {}
            
            for days_back in range(30):
                cohort_date = (datetime.utcnow() - timedelta(days=days_back)).date()
                
                # Users first seen on this date
                stmt = select(
                    func.count(func.distinct(Launch.hwid))
                ).where(
                    func.date(Launch.launched_at) == cohort_date
                )
                result = await session.execute(stmt)
                cohort_size = result.scalar() or 0
                
                if cohort_size > 0:
                    cohort_key = cohort_date.isoformat()
                    cohorts[cohort_key] = {"d0": cohort_size}
                    
                    # Calculate retention for this cohort
                    for retention_day in [1, 7, 14, 30]:
                        retention_date = cohort_date + timedelta(days=retention_day)
                        
                        stmt = select(
                            func.count(func.distinct(Launch.hwid))
                        ).where(
                            and_(
                                func.date(Launch.launched_at) == retention_date,
                                # This would need a way to identify first-seen date
                                # For now, approximate
                            )
                        )
                        result = await session.execute(stmt)
                        retained = result.scalar() or 0
                        
                        key = f"d{retention_day}"
                        if retained > 0:
                            cohorts[cohort_key][key] = retained
            
            return cohorts
    
    @staticmethod
    async def get_churn_prediction(period_days: int = 7):
        """
        Predict which HWIDs might churn in next period
        Returns users who:
        - Were active X days ago
        - Are NOT active in last Y days
        """
        async with AsyncSessionLocal() as session:
            now = datetime.utcnow()
            inactive_threshold = now - timedelta(days=period_days)
            activity_window = now - timedelta(days=period_days * 2)
            
            # Users active in earlier window
            stmt = select(func.distinct(Launch.hwid)).where(
                and_(
                    Launch.launched_at >= activity_window,
                    Launch.launched_at < inactive_threshold
                )
            )
            result = await session.execute(stmt)
            at_risk = result.scalars().all()
            
            return {
                "at_risk_count": len(at_risk),
                "sample_hwids": at_risk[:10],
                "period_days": period_days
            }
    
    @staticmethod
    async def get_user_segments():
        """
        Segment users by activity level
        Returns: power_users, regular_users, inactive_users
        """
        async with AsyncSessionLocal() as session:
            week_ago = datetime.utcnow() - timedelta(days=7)
            month_ago = datetime.utcnow() - timedelta(days=30)
            
            # Power users (>10 launches in last week)
            stmt = select(
                Launch.hwid,
                func.count(Launch.id).label('launches')
            ).where(
                Launch.launched_at > week_ago
            ).group_by(Launch.hwid).having(
                func.count(Launch.id) > 10
            )
            result = await session.execute(stmt)
            power_users = [row[0] for row in result.all()]
            
            # Regular users (1-10 launches in last week)
            stmt = select(
                Launch.hwid,
                func.count(Launch.id).label('launches')
            ).where(
                Launch.launched_at > week_ago
            ).group_by(Launch.hwid).having(
                and_(
                    func.count(Launch.id) > 1,
                    func.count(Launch.id) <= 10
                )
            )
            result = await session.execute(stmt)
            regular_users = [row[0] for row in result.all()]
            
            # Inactive users (not in last week, but in last month)
            stmt = select(func.distinct(Launch.hwid)).where(
                and_(
                    Launch.launched_at < week_ago,
                    Launch.launched_at > month_ago
                )
            )
            result = await session.execute(stmt)
            inactive_users = result.scalars().all()
            
            return {
                "power_users": {"count": len(power_users), "sample": power_users[:5]},
                "regular_users": {"count": len(regular_users), "sample": regular_users[:5]},
                "inactive_users": {"count": len(inactive_users), "sample": inactive_users[:5]}
            }
    
    @staticmethod
    async def get_lifetime_value(hwid: str):
        """Calculate total value metrics for a device"""
        async with AsyncSessionLocal() as session:
            stmt = select(
                func.count(Launch.id).label('total_launches'),
                func.min(Launch.launched_at).label('first_seen'),
                func.max(Launch.launched_at).label('last_seen'),
                func.count(func.distinct(Launch.token_id)).label('distinct_tokens'),
                func.count(func.distinct(Launch.exe_version)).label('distinct_versions')
            ).where(Launch.hwid == hwid)
            
            result = await session.execute(stmt)
            row = result.first()
            
            if not row:
                return None
            
            first_seen = row[1]
            last_seen = row[2]
            lifetime_days = (last_seen - first_seen).days if first_seen and last_seen else 0
            
            return {
                "hwid": hwid,
                "total_launches": row[0],
                "first_seen": first_seen.isoformat() if first_seen else None,
                "last_seen": last_seen.isoformat() if last_seen else None,
                "lifetime_days": lifetime_days,
                "avg_launches_per_day": row[0] / max(lifetime_days, 1),
                "distinct_tokens_used": row[3],
                "distinct_versions": row[4]
            }
    
    @staticmethod
    async def get_geographic_insights():
        """Geographic expansion trends"""
        async with AsyncSessionLocal() as session:
            # Countries trending up
            week_ago = datetime.utcnow() - timedelta(days=7)
            two_weeks_ago = datetime.utcnow() - timedelta(days=14)
            
            # This week
            stmt = select(
                Launch.country,
                func.count(Launch.id).label('launches')
            ).where(
                Launch.launched_at > week_ago
            ).group_by(Launch.country)
            
            result = await session.execute(stmt)
            this_week = {row[0]: row[1] for row in result.all()}
            
            # Last week
            stmt = select(
                Launch.country,
                func.count(Launch.id).label('launches')
            ).where(
                and_(
                    Launch.launched_at > two_weeks_ago,
                    Launch.launched_at <= week_ago
                )
            ).group_by(Launch.country)
            
            result = await session.execute(stmt)
            last_week = {row[0]: row[1] for row in result.all()}
            
            # Calculate growth
            growth = {}
            for country in set(list(this_week.keys()) + list(last_week.keys())):
                current = this_week.get(country, 0)
                previous = last_week.get(country, 0)
                growth_pct = ((current - previous) / previous * 100) if previous > 0 else 100
                
                growth[country] = {
                    "this_week": current,
                    "last_week": previous,
                    "growth_pct": growth_pct
                }
            
            # Top 10 by growth
            top_growing = sorted(
                growth.items(),
                key=lambda x: x[1]['growth_pct'],
                reverse=True
            )[:10]
            
            return dict(top_growing)
