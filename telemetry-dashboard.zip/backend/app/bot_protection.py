from fastapi import Request, HTTPException
from starlette.middleware.base import BaseHTTPMiddleware
from app.config import get_settings
import logging

logger = logging.getLogger(__name__)

settings = get_settings()

class BotProtectionMiddleware(BaseHTTPMiddleware):
    """Middleware to detect and block suspicious bot traffic"""
    
    async def dispatch(self, request: Request, call_next):
        if not settings.BOT_PROTECTION_ENABLED:
            return await call_next(request)
        
        user_agent = request.headers.get("user-agent", "").lower()
        
        # Check for known malicious bot keywords
        for keyword in settings.SUSPICIOUS_USER_AGENT_KEYWORDS:
            if keyword in user_agent:
                logger.warning(f"Suspicious bot detected: {user_agent} from {request.client.host}")
                raise HTTPException(status_code=403, detail="Access denied")
        
        # Require User-Agent header for API requests
        if request.url.path.startswith("/api/") and not user_agent:
            logger.warning(f"Request without User-Agent from {request.client.host}")
            raise HTTPException(status_code=403, detail="Access denied")
        
        # Check for too many missing headers (bot signatures)
        headers_count = len(request.headers)
        if headers_count < 5 and request.url.path.startswith("/api/"):
            logger.warning(f"Request with minimal headers from {request.client.host}: {headers_count}")
            raise HTTPException(status_code=403, detail="Access denied")
        
        response = await call_next(request)
        
        # Add security headers
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        
        return response


class CloudflareMiddleware(BaseHTTPMiddleware):
    """Middleware to handle Cloudflare proxy headers"""
    
    async def dispatch(self, request: Request, call_next):
        # Prefer Cloudflare IP header
        cf_connecting_ip = request.headers.get("cf-connecting-ip")
        if cf_connecting_ip:
            request.scope["client"] = (cf_connecting_ip, 0)
        
        response = await call_next(request)
        return response


class HTTPSEnforceMiddleware(BaseHTTPMiddleware):
    """Middleware to enforce HTTPS in production"""
    
    async def dispatch(self, request: Request, call_next):
        if settings.ENVIRONMENT == "production" and settings.REQUIRE_HTTPS:
            scheme = request.headers.get("x-forwarded-proto", request.url.scheme)
            if scheme != "https" and request.url.path != "/health":
                raise HTTPException(status_code=307, detail="HTTPS required")
        
        response = await call_next(request)
        return response
