from pydantic_settings import BaseSettings
from functools import lru_cache
from typing import Optional

class Settings(BaseSettings):
    # Database
    DATABASE_URL: str = "postgresql+asyncpg://telemetry:telemetry@localhost/telemetry_db"
    
    # JWT
    SECRET_KEY: str = "your-super-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    
    # TOTP
    TOTP_ISSUER: str = "TelemetryDashboard"
    
    # GeoIP (MaxMind)
    GEOIP_DB_PATH: str = "./data/GeoLite2-Country.mmdb"
    
    # CORS - Updated for Cloudflare production
    ALLOWED_ORIGINS: list = [
        "http://localhost:5173",
        "http://localhost:3000",
        "https://drukvculgar.live",
        "https://www.drukvculgar.live"
    ]
    
    # API
    API_PREFIX: str = "/api/v1"
    
    # Environment
    ENVIRONMENT: str = "development"
    DEBUG: bool = True
    LOG_LEVEL: str = "INFO"
    
    # Bot Protection
    BOT_PROTECTION_ENABLED: bool = True
    RATE_LIMIT_ENABLED: bool = True
    SUSPICIOUS_USER_AGENT_KEYWORDS: list = [
        "bot", "crawler", "spider", "scraper", "wget", "curl", "python",
        "nikto", "nmap", "sqlmap", "shodan", "masscan", "nessus"
    ]
    
    # Security
    REQUIRE_HTTPS: bool = True
    
    class Config:
        env_file = ".env"

@lru_cache()
def get_settings():
    return Settings()
