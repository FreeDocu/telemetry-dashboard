import geoip2.database
from app.config import get_settings
from pathlib import Path

settings = get_settings()

class GeoIPManager:
    def __init__(self):
        self.reader = None
        self._load_db()
    
    def _load_db(self):
        db_path = Path(settings.GEOIP_DB_PATH)
        if db_path.exists():
            try:
                self.reader = geoip2.database.Reader(str(db_path))
            except Exception as e:
                print(f"GeoIP DB load error: {e}")
                self.reader = None
    
    def get_country_by_ip(self, ip: str) -> str:
        if not self.reader or ip == "127.0.0.1":
            return "Local"
        
        try:
            response = self.reader.country(ip)
            return response.country.iso_code or "Unknown"
        except Exception as e:
            print(f"GeoIP lookup error for {ip}: {e}")
            return "Unknown"
    
    def close(self):
        if self.reader:
            self.reader.close()

geo_manager = GeoIPManager()
