from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from datetime import datetime, timedelta
from sqlalchemy import select, func, and_
from app.database import AsyncSessionLocal
from app.models import Launch, BannedHwid
from app.cache import cache
import logging

logger = logging.getLogger(__name__)

scheduler = AsyncIOScheduler()


async def calculate_retention_metrics():
    """Calculate retention metrics for all cohorts - hourly"""
    try:
        async with AsyncSessionLocal() as session:
            # D1 Retention
            today = datetime.utcnow().date()
            
            # Users who launched today
            stmt = select(func.count(func.distinct(Launch.hwid))).where(
                func.date(Launch.launched_at) == today
            )
            result = await session.execute(stmt)
            today_unique = result.scalar() or 0
            
            # Users who launched yesterday and today
            yesterday = today - timedelta(days=1)
            stmt = select(func.count(func.distinct(Launch.hwid))).where(
                and_(
                    func.date(Launch.launched_at).in_([yesterday, today])
                )
            )
            result = await session.execute(stmt)
            retention_d1 = result.scalar() or 0
            
            # Cache retention data
            await cache.set(
                'retention:d1',
                {
                    'd1': (retention_d1 / today_unique * 100) if today_unique > 0 else 0,
                    'calculated_at': datetime.utcnow().isoformat()
                },
                ttl=3600
            )
            
            logger.info(f"D1 Retention: {retention_d1}/{today_unique}")
    except Exception as e:
        logger.error(f"Retention calculation error: {e}")


async def cleanup_old_data():
    """Delete launches older than 90 days - daily at 2 AM"""
    try:
        async with AsyncSessionLocal() as session:
            cutoff_date = datetime.utcnow() - timedelta(days=90)
            
            stmt = select(Launch).where(Launch.launched_at < cutoff_date)
            result = await session.execute(stmt)
            old_launches = result.scalars().all()
            
            for launch in old_launches:
                await session.delete(launch)
            
            await session.commit()
            
            logger.info(f"Deleted {len(old_launches)} old launch records")
            await cache.clear_pattern("analytics:*")
    except Exception as e:
        logger.error(f"Data cleanup error: {e}")


async def detect_anomalies():
    """Detect suspicious activity patterns - every 15 minutes"""
    try:
        async with AsyncSessionLocal() as session:
            # Get recent spike in launches
            fifteen_min_ago = datetime.utcnow() - timedelta(minutes=15)
            
            stmt = select(
                Launch.token_id,
                Launch.hwid,
                func.count(Launch.id).label('count')
            ).where(
                Launch.launched_at > fifteen_min_ago
            ).group_by(
                Launch.token_id,
                Launch.hwid
            ).having(
                func.count(Launch.id) > 100  # Threshold: 100 launches in 15 min
            )
            
            result = await session.execute(stmt)
            anomalies = result.all()
            
            for token_id, hwid, count in anomalies:
                # Flag as suspicious
                await cache.set(
                    f'suspicious:{hwid}',
                    {
                        'token_id': token_id,
                        'launch_count_15m': count,
                        'detected_at': datetime.utcnow().isoformat()
                    },
                    ttl=3600
                )
                
                logger.warning(f"Anomaly detected: {hwid} - {count} launches in 15m")
    except Exception as e:
        logger.error(f"Anomaly detection error: {e}")


async def generate_analytics_cache():
    """Pre-cache popular analytics queries - every hour"""
    try:
        async with AsyncSessionLocal() as session:
            # Cache top countries
            stmt = select(
                Launch.country,
                func.count(Launch.id).label('launches'),
                func.count(func.distinct(Launch.hwid)).label('unique_hwids')
            ).group_by(Launch.country).order_by(
                func.count(Launch.id).desc()
            ).limit(10)
            
            result = await session.execute(stmt)
            countries = [
                {"country": row[0], "launches": row[1], "unique_hwids": row[2]}
                for row in result.all()
            ]
            
            await cache.set('analytics:top_countries', countries, ttl=3600)
            
            # Cache top versions
            stmt = select(
                Launch.exe_version,
                func.count(Launch.id).label('launches'),
                func.count(func.distinct(Launch.hwid)).label('unique_hwids')
            ).group_by(Launch.exe_version).order_by(
                func.count(Launch.id).desc()
            )
            
            result = await session.execute(stmt)
            versions = [
                {"version": row[0], "launches": row[1], "unique_hwids": row[2]}
                for row in result.all()
            ]
            
            await cache.set('analytics:versions', versions, ttl=3600)
            
            logger.info("Analytics cache generated")
    except Exception as e:
        logger.error(f"Analytics cache error: {e}")


def init_scheduler():
    """Initialize background job scheduler"""
    # Retention calculation - every hour
    scheduler.add_job(
        calculate_retention_metrics,
        CronTrigger(minute=0),
        id='retention_calculation',
        name='Calculate retention metrics'
    )
    
    # Data cleanup - daily at 2 AM
    scheduler.add_job(
        cleanup_old_data,
        CronTrigger(hour=2, minute=0),
        id='data_cleanup',
        name='Cleanup old data'
    )
    
    # Anomaly detection - every 15 minutes
    scheduler.add_job(
        detect_anomalies,
        CronTrigger(minute='*/15'),
        id='anomaly_detection',
        name='Detect anomalies'
    )
    
    # Analytics cache - every hour
    scheduler.add_job(
        generate_analytics_cache,
        CronTrigger(minute=0),
        id='analytics_cache',
        name='Generate analytics cache'
    )
    
    scheduler.start()
    logger.info("Background scheduler started")


async def shutdown_scheduler():
    """Shutdown scheduler gracefully"""
    if scheduler.running:
        scheduler.shutdown(wait=True)
        logger.info("Background scheduler stopped")
