from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import logging

from app.config import settings
from app.database import init_db, dispose_db, get_db
from app.logging_config import setup_logging
from app.security_headers import SecurityHeadersMiddleware, limiter, rate_limit_error_handler
from app.cache import cache
from app.jobs import scheduler
from app.bot_protection import BotProtectionMiddleware, CloudflareMiddleware, HTTPSEnforceMiddleware

# Configure logging
setup_logging(settings.LOG_LEVEL)
logger = logging.getLogger(__name__)

# Import routes
from app.routes import auth, telemetry, admin, analytics, dashboard
from app.routes.ws import router as ws_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifecycle management for startup and shutdown
    """
    # Startup
    logger.info("Starting application...")
    
    # Initialize database
    await init_db()
    logger.info("Database initialized")
    
    # Connect to Redis (graceful fallback if unavailable)
    try:
        await cache.connect()
        logger.info("Redis cache connected")
    except Exception as e:
        logger.warning(f"Redis connection failed: {e}. Continuing without cache.")
    
    # Initialize background job scheduler
    try:
        scheduler.init_scheduler()
        logger.info("Background scheduler initialized")
    except Exception as e:
        logger.error(f"Scheduler initialization failed: {e}")
    
    yield
    
    # Shutdown
    logger.info("Shutting down application...")
    
    # Shutdown scheduler
    try:
        await scheduler.shutdown_scheduler()
        logger.info("Scheduler shutdown complete")
    except Exception as e:
        logger.error(f"Scheduler shutdown error: {e}")
    
    # Disconnect Redis
    try:
        await cache.disconnect()
        logger.info("Redis cache disconnected")
    except Exception as e:
        logger.warning(f"Redis disconnect error: {e}")
    
    # Dispose database connections
    await dispose_db()
    logger.info("Database connections disposed")


# Create FastAPI app
app = FastAPI(
    title="Telemetry Dashboard API",
    description="Comprehensive telemetry and monitoring system for applications",
    version="1.0.0",
    lifespan=lifespan
)

# Add security headers middleware
app.add_middleware(SecurityHeadersMiddleware)

# Add HTTPS enforcement middleware
app.add_middleware(HTTPSEnforceMiddleware)

# Add Cloudflare proxy handling middleware
app.add_middleware(CloudflareMiddleware)

# Add bot protection middleware
app.add_middleware(BotProtectionMiddleware)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["X-Total-Count", "X-Page", "X-Page-Size"],
)

# Add rate limiting
app.state.limiter = limiter
app.add_exception_handler(429, rate_limit_error_handler)

# Health check endpoint
@app.get("/health", tags=["health"])
async def health_check():
    """Service health check"""
    return {
        "status": "healthy",
        "service": "telemetry-dashboard",
        "version": "1.0.0"
    }


# Metrics endpoint (Prometheus)
@app.get("/metrics", tags=["monitoring"])
async def metrics():
    """Prometheus metrics endpoint"""
    from app.monitoring import get_metrics
    from fastapi.responses import PlainTextResponse
    
    metrics_text = get_metrics()
    return PlainTextResponse(content=metrics_text, media_type="text/plain")


# Include route modules
app.include_router(auth.router, prefix=settings.API_PREFIX)
app.include_router(telemetry.router, prefix=settings.API_PREFIX)
app.include_router(admin.router, prefix=settings.API_PREFIX)
app.include_router(analytics.router, prefix=settings.API_PREFIX)
app.include_router(dashboard.router, prefix=settings.API_PREFIX)
app.include_router(ws_router)  # WebSocket routes (no prefix)


# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error"}
    )


if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        app,
        host=settings.HOST,
        port=settings.PORT,
        log_config={
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "default": {
                    "format": "%(message)s",
                },
            },
            "handlers": {
                "default": {
                    "formatter": "default",
                    "class": "logging.StreamHandler",
                    "stream": "ext://sys.stdout",
                },
            },
            "loggers": {
                "uvicorn": {
                    "handlers": ["default"],
                    "level": "INFO",
                },
            },
        }
    )
