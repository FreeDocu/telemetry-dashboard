from sqlalchemy import Column, String, Boolean, DateTime, func
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base

class AdminUser(Base):
    __tablename__ = "admin_user"

    id = Column(String, primary_key=True, default=lambda: "admin")
    username = Column(String, unique=True, nullable=False, index=True)
    password_hash = Column(String, nullable=False)
    
    # TOTP fields
    totp_secret = Column(String, nullable=True)
    totp_enabled = Column(Boolean, default=False)
    totp_locked = Column(Boolean, default=False)  # After first setup, can't change
    
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    def __repr__(self):
        return f"<AdminUser {self.username}>"
