from sqlalchemy import Column, String, DateTime, ForeignKey, func
from datetime import datetime
from app.database import Base

class BannedHwid(Base):
    __tablename__ = "banned_hwids"

    hwid = Column(String, primary_key=True)
    token_id = Column(String, ForeignKey("tokens.id"), nullable=True, index=True)
    
    reason = Column(String, nullable=True)
    banned_at = Column(DateTime, default=func.now())
    banned_by = Column(String, default="admin")
    
    until = Column(DateTime, nullable=True)  # NULL = permanent ban

    def __repr__(self):
        return f"<BannedHwid {self.hwid}>"
