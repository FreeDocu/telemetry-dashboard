from sqlalchemy import Column, String, DateTime, JSON, func
from datetime import datetime
from app.database import Base

class DashboardLayout(Base):
    __tablename__ = "dashboard_layout"

    user_id = Column(String, primary_key=True, default="admin")
    layout_json = Column(JSON, nullable=True)  # react-grid-layout format
    
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    def __repr__(self):
        return f"<DashboardLayout {self.user_id}>"
