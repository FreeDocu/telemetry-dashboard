from sqlalchemy import Column, String, DateTime, JSON, ForeignKey, func
from datetime import datetime
from app.database import Base
import uuid

class Launch(Base):
    __tablename__ = "launches"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    token_id = Column(String, ForeignKey("tokens.id"), nullable=False, index=True)
    
    hwid = Column(String, nullable=False, index=True)
    ip = Column(String, nullable=False)
    country = Column(String, nullable=True)
    os = Column(String, nullable=True)
    exe_version = Column(String, nullable=True)
    
    launched_at = Column(DateTime, default=func.now(), index=True)
    extra = Column(JSON, nullable=True)

    def __repr__(self):
        return f"<Launch {self.id}>"
