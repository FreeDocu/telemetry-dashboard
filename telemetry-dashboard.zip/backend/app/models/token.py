from sqlalchemy import Column, String, Boolean, DateTime, func
from datetime import datetime
from app.database import Base
import uuid

class Token(Base):
    __tablename__ = "tokens"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    token = Column(String, unique=True, nullable=False, index=True)
    name = Column(String, nullable=False)
    note = Column(String, nullable=True)
    
    active = Column(Boolean, default=True, index=True)
    current_version = Column(String, nullable=True)
    expires_at = Column(DateTime, nullable=True)
    
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())

    def __repr__(self):
        return f"<Token {self.name}>"
