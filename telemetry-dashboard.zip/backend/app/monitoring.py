from prometheus_client import Counter, Histogram, Gauge, generate_latest
import time
from functools import wraps

# Metrics
request_count = Counter(
    'telemetry_http_requests_total',
    'Total HTTP requests',
    ['method', 'endpoint', 'status']
)

request_duration = Histogram(
    'telemetry_http_request_duration_seconds',
    'HTTP request duration',
    ['method', 'endpoint']
)

active_users = Gauge(
    'telemetry_active_users',
    'Number of active users'
)

launches_total = Counter(
    'telemetry_launches_total',
    'Total application launches',
    ['token_id', 'country']
)

unique_hwids = Gauge(
    'telemetry_unique_hwids_total',
    'Total unique hardware IDs'
)

banned_hwids_counter = Counter(
    'telemetry_banned_hwids_total',
    'Total banned HWIDs',
    ['reason']
)

database_query_duration = Histogram(
    'telemetry_db_query_duration_seconds',
    'Database query duration',
    ['query_type']
)

authentication_failures = Counter(
    'telemetry_auth_failures_total',
    'Total authentication failures',
    ['reason']
)


def track_request(method: str, endpoint: str):
    """Decorator to track HTTP requests"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            start_time = time.time()
            try:
                result = await func(*args, **kwargs)
                status = 200
                return result
            except Exception as e:
                status = getattr(e, 'status_code', 500)
                raise
            finally:
                duration = time.time() - start_time
                request_count.labels(method=method, endpoint=endpoint, status=status).inc()
                request_duration.labels(method=method, endpoint=endpoint).observe(duration)
        return wrapper
    return decorator


def track_db_query(query_type: str):
    """Decorator to track database queries"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            start_time = time.time()
            try:
                return await func(*args, **kwargs)
            finally:
                duration = time.time() - start_time
                database_query_duration.labels(query_type=query_type).observe(duration)
        return wrapper
    return decorator


def get_metrics():
    """Return Prometheus metrics"""
    return generate_latest()
