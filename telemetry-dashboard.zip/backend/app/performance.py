from sqlalchemy import text
from sqlalchemy.orm import selectinload
from sqlalchemy import select, func, desc
from app.database import AsyncSessionLocal
from app.models import Launch, BannedHwid
from datetime import datetime, timedelta


async def optimize_launch_query(session, filters: dict = None):
    """
    Get launches with optimized query (with pagination, indexing)
    
    Args:
        session: AsyncSession
        filters: dict with keys: limit, offset, period_hours, token_ids, countries
    """
    filters = filters or {}
    limit = min(int(filters.get("limit", 50)), 1000)  # Max 1000 per query
    offset = int(filters.get("offset", 0))
    period_hours = int(filters.get("period_hours", 24))
    
    stmt = select(Launch).order_by(desc(Launch.launched_at))
    
    # Filter by time period
    if period_hours > 0:
        cutoff_time = datetime.utcnow() - timedelta(hours=period_hours)
        stmt = stmt.where(Launch.launched_at >= cutoff_time)
    
    # Filter by token IDs
    token_ids = filters.get("token_ids", [])
    if token_ids:
        stmt = stmt.where(Launch.token_id.in_(token_ids))
    
    # Filter by countries
    countries = filters.get("countries", [])
    if countries:
        stmt = stmt.where(Launch.country.in_(countries))
    
    # Apply pagination (leverages database-level optimization)
    stmt = stmt.limit(limit).offset(offset)
    
    result = await session.execute(stmt)
    launches = result.scalars().all()
    
    return launches


async def get_metrics_cached(session, period_hours: int = 24):
    """
    Get KPI metrics snapshot with efficient queries
    Uses aggregation at database level (not Python)
    """
    cutoff_time = datetime.utcnow() - timedelta(hours=period_hours)
    
    # Total launches
    total_launches = await session.execute(
        select(func.count(Launch.id)).where(
            Launch.launched_at >= cutoff_time
        )
    )
    total_launches = total_launches.scalar() or 0
    
    # Unique HWIDs
    unique_hwids = await session.execute(
        select(func.count(func.distinct(Launch.hwid))).where(
            Launch.launched_at >= cutoff_time
        )
    )
    unique_hwids = unique_hwids.scalar() or 0
    
    # Banned HWIDs count
    banned_count = await session.execute(
        select(func.count(BannedHwid.hwid))
    )
    banned_count = banned_count.scalar() or 0
    
    # Top country
    top_country = await session.execute(
        select(Launch.country, func.count(Launch.id).label("count"))
        .where(Launch.launched_at >= cutoff_time)
        .group_by(Launch.country)
        .order_by(desc("count"))
        .limit(1)
    )
    top_country_row = top_country.first()
    top_country = top_country_row[0] if top_country_row else "Unknown"
    
    return {
        "total_launches": total_launches,
        "unique_hwids": unique_hwids,
        "banned_hwids": banned_count,
        "top_country": top_country,
        "period_hours": period_hours
    }


async def get_top_releases(session, limit: int = 10, period_hours: int = 24):
    """
    Get top exe versions by launch count (optimized)
    """
    cutoff_time = datetime.utcnow() - timedelta(hours=period_hours)
    
    stmt = select(
        Launch.exe_version,
        func.count(Launch.id).label("count")
    ).where(
        Launch.launched_at >= cutoff_time
    ).group_by(
        Launch.exe_version
    ).order_by(
        desc("count")
    ).limit(limit)
    
    result = await session.execute(stmt)
    return [{"version": row[0], "count": row[1]} for row in result.all()]


async def get_geographic_distribution(session, period_hours: int = 24):
    """
    Get launches by country with unique HWID count (optimized aggregation)
    """
    cutoff_time = datetime.utcnow() - timedelta(hours=period_hours)
    
    stmt = select(
        Launch.country,
        func.count(Launch.id).label("launches"),
        func.count(func.distinct(Launch.hwid)).label("unique_hwids")
    ).where(
        Launch.launched_at >= cutoff_time
    ).group_by(
        Launch.country
    ).order_by(
        desc("launches")
    ).limit(50)  # Top 50 countries
    
    result = await session.execute(stmt)
    return [
        {
            "country": row[0],
            "launches": row[1],
            "unique_hwids": row[2]
        }
        for row in result.all()
    ]
