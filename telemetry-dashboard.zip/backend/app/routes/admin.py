from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from app.database import get_db
from app.models import Token, BannedHwid, Launch
from app.schemas.token import CreateTokenRequest, TokenResponse, UpdateTokenRequest
from app.security import verify_token
import uuid
import secrets

router = APIRouter(prefix="/admin", tags=["admin"])

async def get_current_admin(authorization: str = None):
    if not authorization:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing authorization header"
        )
    
    try:
        scheme, token = authorization.split()
        if scheme.lower() != "bearer":
            raise ValueError
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authorization header"
        )
    
    payload = verify_token(token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )
    
    return payload.get("sub")

# Token management
@router.post("/tokens", response_model=TokenResponse)
async def create_token(
    request: CreateTokenRequest,
    db: AsyncSession = Depends(get_db),
    current_admin: str = Depends(get_current_admin)
):
    token_value = secrets.token_urlsafe(32)
    
    token = Token(
        token=token_value,
        name=request.name,
        note=request.note,
        expires_at=request.expires_at
    )
    
    db.add(token)
    await db.commit()
    await db.refresh(token)
    
    return TokenResponse.model_validate(token)

@router.get("/tokens", response_model=list[TokenResponse])
async def list_tokens(
    db: AsyncSession = Depends(get_db),
    current_admin: str = Depends(get_current_admin)
):
    stmt = select(Token).order_by(Token.created_at.desc())
    result = await db.execute(stmt)
    tokens = result.scalars().all()
    
    return [TokenResponse.model_validate(t) for t in tokens]

@router.get("/tokens/{token_id}", response_model=TokenResponse)
async def get_token(
    token_id: str,
    db: AsyncSession = Depends(get_db),
    current_admin: str = Depends(get_current_admin)
):
    stmt = select(Token).where(Token.id == token_id)
    result = await db.execute(stmt)
    token = result.scalars().first()
    
    if not token:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Token not found"
        )
    
    return TokenResponse.model_validate(token)

@router.patch("/tokens/{token_id}", response_model=TokenResponse)
async def update_token(
    token_id: str,
    request: UpdateTokenRequest,
    db: AsyncSession = Depends(get_db),
    current_admin: str = Depends(get_current_admin)
):
    stmt = select(Token).where(Token.id == token_id)
    result = await db.execute(stmt)
    token = result.scalars().first()
    
    if not token:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Token not found"
        )
    
    if request.name is not None:
        token.name = request.name
    if request.note is not None:
        token.note = request.note
    if request.active is not None:
        token.active = request.active
    if request.current_version is not None:
        token.current_version = request.current_version
    
    await db.commit()
    await db.refresh(token)
    
    return TokenResponse.model_validate(token)

@router.delete("/tokens/{token_id}")
async def delete_token(
    token_id: str,
    db: AsyncSession = Depends(get_db),
    current_admin: str = Depends(get_current_admin)
):
    stmt = select(Token).where(Token.id == token_id)
    result = await db.execute(stmt)
    token = result.scalars().first()
    
    if not token:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Token not found"
        )
    
    await db.delete(token)
    await db.commit()
    
    return {"success": True}

# HWID Ban management
@router.post("/bans/hwid")
async def ban_hwid(
    hwid: str,
    reason: str = None,
    token_id: str = None,
    until: str = None,
    db: AsyncSession = Depends(get_db),
    current_admin: str = Depends(get_current_admin)
):
    from datetime import datetime
    
    ban = BannedHwid(
        hwid=hwid,
        reason=reason,
        token_id=token_id,
        until=datetime.fromisoformat(until) if until else None
    )
    
    db.add(ban)
    await db.commit()
    
    return {"success": True, "hwid": hwid}

@router.get("/bans/hwid")
async def list_bans(
    db: AsyncSession = Depends(get_db),
    current_admin: str = Depends(get_current_admin)
):
    stmt = select(BannedHwid).order_by(BannedHwid.banned_at.desc())
    result = await db.execute(stmt)
    bans = result.scalars().all()
    
    return [{"hwid": b.hwid, "reason": b.reason, "until": b.until} for b in bans]

@router.delete("/bans/hwid/{hwid}")
async def unban_hwid(
    hwid: str,
    db: AsyncSession = Depends(get_db),
    current_admin: str = Depends(get_current_admin)
):
    stmt = select(BannedHwid).where(BannedHwid.hwid == hwid)
    result = await db.execute(stmt)
    ban = result.scalars().first()
    
    if not ban:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ban not found"
        )
    
    await db.delete(ban)
    await db.commit()
    
    return {"success": True}
