from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_
from datetime import datetime, timedelta
from app.database import get_db
from app.models import Launch, Token
from app.security import verify_token
from app.analytics_service import AnalyticsService
from app.cache import cache

router = APIRouter(prefix="/analytics", tags=["analytics"])

async def get_current_admin(authorization: str = None):
    if not authorization:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing authorization header"
        )
    
    try:
        scheme, token = authorization.split()
        if scheme.lower() != "bearer":
            raise ValueError
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authorization header"
        )
    
    payload = verify_token(token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )
    
    return payload.get("sub")

# Summary stats
@router.get("/summary")
async def get_summary(
    token_ids: list[str] = None,
    period_hours: int = 24,
    db: AsyncSession = Depends(get_db),
    current_admin: str = Depends(get_current_admin)
):
    since = datetime.utcnow() - timedelta(hours=period_hours)
    
    filters = [Launch.launched_at >= since]
    if token_ids:
        filters.append(Launch.token_id.in_(token_ids))
    
    # Total launches
    stmt = select(func.count(Launch.id)).where(and_(*filters))
    result = await db.execute(stmt)
    total_launches = result.scalar() or 0
    
    # Unique HWIDs
    stmt = select(func.count(func.distinct(Launch.hwid))).where(and_(*filters))
    result = await db.execute(stmt)
    unique_hwids = result.scalar() or 0
    
    return {
        "total_launches": total_launches,
        "unique_hwids": unique_hwids,
        "period_hours": period_hours
    }

# Launches by time
@router.get("/launches/timeline")
async def get_launches_timeline(
    token_ids: list[str] = None,
    period_hours: int = 24,
    interval: str = "hour",
    db: AsyncSession = Depends(get_db),
    current_admin: str = Depends(get_current_admin)
):
    since = datetime.utcnow() - timedelta(hours=period_hours)
    
    filters = [Launch.launched_at >= since]
    if token_ids:
        filters.append(Launch.token_id.in_(token_ids))
    
    # Group by time
    if interval == "hour":
        time_bucket = func.date_trunc("hour", Launch.launched_at)
    else:
        time_bucket = func.date_trunc("day", Launch.launched_at)
    
    stmt = select(
        time_bucket.label("time"),
        func.count(Launch.id).label("launches"),
        func.count(func.distinct(Launch.hwid)).label("unique_hwids")
    ).where(and_(*filters)).group_by(time_bucket).order_by(time_bucket)
    
    result = await db.execute(stmt)
    rows = result.all()
    
    return [
        {
            "time": row[0],
            "launches": row[1],
            "unique_hwids": row[2]
        }
        for row in rows
    ]

# Top countries
@router.get("/analytics/countries")
async def get_top_countries(
    token_ids: list[str] = None,
    period_hours: int = 24,
    limit: int = 10,
    db: AsyncSession = Depends(get_db),
    current_admin: str = Depends(get_current_admin)
):
    since = datetime.utcnow() - timedelta(hours=period_hours)
    
    filters = [Launch.launched_at >= since]
    if token_ids:
        filters.append(Launch.token_id.in_(token_ids))
    
    stmt = select(
        Launch.country,
        func.count(Launch.id).label("launches"),
        func.count(func.distinct(Launch.hwid)).label("unique_hwids")
    ).where(and_(*filters)).group_by(Launch.country).order_by(
        func.count(Launch.id).desc()
    ).limit(limit)
    
    result = await db.execute(stmt)
    rows = result.all()
    
    return [
        {
            "country": row[0] or "Unknown",
            "launches": row[1],
            "unique_hwids": row[2]
        }
        for row in rows
    ]

# Top HWIDs
@router.get("/analytics/hwids")
async def get_top_hwids(
    token_ids: list[str] = None,
    period_hours: int = 24,
    limit: int = 10,
    db: AsyncSession = Depends(get_db),
    current_admin: str = Depends(get_current_admin)
):
    since = datetime.utcnow() - timedelta(hours=period_hours)
    
    filters = [Launch.launched_at >= since]
    if token_ids:
        filters.append(Launch.token_id.in_(token_ids))
    
    stmt = select(
        Launch.hwid,
        func.count(Launch.id).label("launches"),
        func.max(Launch.launched_at).label("last_seen")
    ).where(and_(*filters)).group_by(Launch.hwid).order_by(
        func.count(Launch.id).desc()
    ).limit(limit)
    
    result = await db.execute(stmt)
    rows = result.all()
    
    return [
        {
            "hwid": row[0],
            "launches": row[1],
            "last_seen": row[2]
        }
        for row in rows
    ]

# Version stats
@router.get("/analytics/versions")
async def get_version_stats(
    token_ids: list[str] = None,
    period_hours: int = 24,
    db: AsyncSession = Depends(get_db),
    current_admin: str = Depends(get_current_admin)
):
    since = datetime.utcnow() - timedelta(hours=period_hours)
    
    filters = [Launch.launched_at >= since]
    if token_ids:
        filters.append(Launch.token_id.in_(token_ids))
    
    stmt = select(
        Launch.exe_version,
        func.count(Launch.id).label("launches"),
        func.count(func.distinct(Launch.hwid)).label("unique_hwids")
    ).where(and_(*filters)).group_by(Launch.exe_version).order_by(
        func.count(Launch.id).desc()
    )
    
    result = await db.execute(stmt)
    rows = result.all()
    
    return [
        {
            "version": row[0] or "Unknown",
            "launches": row[1],
            "unique_hwids": row[2]
        }
        for row in rows
    ]


# Advanced Analytics Endpoints
# =============================

@router.get("/cohort-analysis")
async def get_cohort_analysis(
    current_admin: str = Depends(get_current_admin),
):
    """
    Get cohort retention analysis
    Returns cohorts with D0, D1, D7, D14, D30 retention rates
    """
    try:
        # Try to get from cache first
        cached = await cache.get("cohort_analysis")
        if cached:
            return cached
        
        # Calculate if not cached
        cohorts = await AnalyticsService.get_cohort_analysis()
        
        # Cache for 1 hour
        await cache.set("cohort_analysis", cohorts, ttl=3600)
        
        return cohorts
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Cohort analysis error: {str(e)}")


@router.get("/churn-prediction")
async def get_churn_prediction(
    period_days: int = Query(7, ge=1, le=90),
    current_admin: str = Depends(get_current_admin),
):
    """
    Predict and identify at-risk users (churn prediction)
    Returns users inactive for the specified period but active before
    """
    try:
        churn = await AnalyticsService.get_churn_prediction(period_days=period_days)
        return churn
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Churn prediction error: {str(e)}")


@router.get("/user-segments")
async def get_user_segments(
    current_admin: str = Depends(get_current_admin),
):
    """
    Segment users into power users, regular users, and inactive users
    Based on launch frequency and recency
    """
    try:
        # Try cache
        cached = await cache.get("user_segments")
        if cached:
            return cached
        
        segments = await AnalyticsService.get_user_segments()
        
        # Cache for 1 hour
        await cache.set("user_segments", segments, ttl=3600)
        
        return segments
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Segmentation error: {str(e)}")


@router.get("/hwid/{hwid}/lifetime-value")
async def get_hwid_lifetime_value(
    hwid: str,
    current_admin: str = Depends(get_current_admin),
):
    """
    Calculate lifetime value (LTV) metrics for a specific HWID
    Includes total launches, duration, engagement metrics
    """
    try:
        ltv = await AnalyticsService.get_lifetime_value(hwid)
        if not ltv:
            raise HTTPException(status_code=404, detail="HWID not found")
        return ltv
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"LTV calculation error: {str(e)}")


@router.get("/geographic-insights")
async def get_geographic_insights(
    current_admin: str = Depends(get_current_admin),
):
    """
    Get geographic insights including week-over-week growth
    Returns top 10 countries by growth percentage
    """
    try:
        # Try cache
        cached = await cache.get("geo_insights")
        if cached:
            return cached
        
        insights = await AnalyticsService.get_geographic_insights()
        
        # Cache for 1 hour
        await cache.set("geo_insights", insights, ttl=3600)
        
        return insights
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Geographic analysis error: {str(e)}")


@router.get("/country/{country}/trends")
async def get_country_trends(
    country: str,
    period_days: int = Query(30, ge=1, le=365),
    db: AsyncSession = Depends(get_db),
    current_admin: str = Depends(get_current_admin),
):
    """
    Get detailed trends for a specific country
    Shows daily launches and unique users
    """
    since = datetime.utcnow() - timedelta(days=period_days)
    
    stmt = select(
        func.date(Launch.launched_at).label("date"),
        func.count(Launch.id).label("launches"),
        func.count(func.distinct(Launch.hwid)).label("unique_hwids")
    ).where(
        and_(
            Launch.country == country,
            Launch.launched_at >= since
        )
    ).group_by(
        func.date(Launch.launched_at)
    ).order_by(
        func.date(Launch.launched_at)
    )
    
    result = await db.execute(stmt)
    rows = result.all()
    
    return [
        {
            "date": row[0].isoformat(),
            "launches": row[1],
            "unique_hwids": row[2]
        }
        for row in rows
    ]
