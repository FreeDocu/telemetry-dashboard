from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database import get_db
from app.models import AdminUser
from app.schemas.auth import (
    LoginRequest, LoginResponse, 
    SetupTOTPRequest, SetupTOTPResponse,
    ConfirmTOTPRequest, ConfirmTOTPResponse
)
from app.security import (
    hash_password, verify_password, 
    create_access_token, verify_token,
    generate_totp_secret, verify_totp, get_totp_qrcode
)
from datetime import timedelta

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post("/login", response_model=LoginResponse)
async def login(request: LoginRequest, db: AsyncSession = Depends(get_db)):
    # Get admin user
    stmt = select(AdminUser).where(AdminUser.username == request.username)
    result = await db.execute(stmt)
    user = result.scalars().first()
    
    if not user or not verify_password(request.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials"
        )
    
    # Check TOTP if enabled
    if user.totp_enabled:
        if not request.totp_code:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="TOTP code required"
            )
        if not verify_totp(user.totp_secret, request.totp_code):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid TOTP code"
            )
    
    # Create access token
    access_token = create_access_token(data={"sub": user.username})
    return LoginResponse(
        access_token=access_token,
        token_type="bearer",
        expires_in=3600
    )

@router.post("/totp/setup", response_model=SetupTOTPResponse)
async def setup_totp(request: SetupTOTPRequest, db: AsyncSession = Depends(get_db)):
    # Get admin user
    stmt = select(AdminUser)
    result = await db.execute(stmt)
    user = result.scalars().first()
    
    if not user or not verify_password(request.current_password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid password"
        )
    
    if user.totp_locked:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="TOTP is already locked and cannot be changed"
        )
    
    # Generate new secret
    secret = generate_totp_secret()
    qr_code = get_totp_qrcode(secret, user.username)
    
    return SetupTOTPResponse(secret=secret, qr_code=qr_code)

@router.post("/totp/confirm", response_model=ConfirmTOTPResponse)
async def confirm_totp(request: ConfirmTOTPRequest, db: AsyncSession = Depends(get_db)):
    # Get admin user
    stmt = select(AdminUser)
    result = await db.execute(stmt)
    user = result.scalars().first()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Admin user not found"
        )
    
    if user.totp_locked:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="TOTP is already configured"
        )
    
    # Verify TOTP code
    if not verify_totp(request.secret, request.totp_code):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid TOTP code"
        )
    
    # Save secret and lock
    user.totp_secret = request.secret
    user.totp_enabled = True
    user.totp_locked = True
    
    await db.commit()
    
    return ConfirmTOTPResponse(success=True)
