from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database import get_db
from app.models import DashboardLayout
from app.schemas.dashboard import DashboardLayoutRequest, DashboardLayoutResponse
from app.security import verify_token

router = APIRouter(prefix="/dashboard", tags=["dashboard"])

async def get_current_admin(authorization: str = None):
    if not authorization:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing authorization header"
        )
    
    try:
        scheme, token = authorization.split()
        if scheme.lower() != "bearer":
            raise ValueError
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authorization header"
        )
    
    payload = verify_token(token)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )
    
    return payload.get("sub")

DEFAULT_LAYOUT = [
    {"i": "kpi-unique-hwid", "x": 0, "y": 0, "w": 3, "h": 1, "static": True},
    {"i": "kpi-launches-today", "x": 3, "y": 0, "w": 3, "h": 1, "static": True},
    {"i": "kpi-retention-d1", "x": 6, "y": 0, "w": 2, "h": 1, "static": True},
    {"i": "kpi-retention-d7", "x": 8, "y": 0, "w": 2, "h": 1, "static": True},
    {"i": "kpi-retention-d30", "x": 10, "y": 0, "w": 2, "h": 1, "static": True},
    {"i": "filters", "x": 0, "y": 1, "w": 12, "h": 2, "static": False},
    {"i": "retention-curves", "x": 0, "y": 3, "w": 12, "h": 4, "static": False},
    {"i": "heatmap-activity", "x": 0, "y": 7, "w": 6, "h": 4, "static": False},
    {"i": "top-hwids", "x": 6, "y": 7, "w": 6, "h": 4, "static": False},
    {"i": "geography", "x": 0, "y": 11, "w": 6, "h": 4, "static": False},
    {"i": "versions", "x": 6, "y": 11, "w": 6, "h": 4, "static": False},
]

@router.get("/layout")
async def get_layout(
    db: AsyncSession = Depends(get_db),
    current_admin: str = Depends(get_current_admin)
):
    stmt = select(DashboardLayout).where(DashboardLayout.user_id == "admin")
    result = await db.execute(stmt)
    layout = result.scalars().first()
    
    if not layout or not layout.layout_json:
        return {"user_id": "admin", "layout": DEFAULT_LAYOUT}
    
    return {"user_id": "admin", "layout": layout.layout_json}

@router.post("/layout")
async def save_layout(
    request: DashboardLayoutRequest,
    db: AsyncSession = Depends(get_db),
    current_admin: str = Depends(get_current_admin)
):
    stmt = select(DashboardLayout).where(DashboardLayout.user_id == "admin")
    result = await db.execute(stmt)
    layout = result.scalars().first()
    
    if not layout:
        layout = DashboardLayout(user_id="admin")
        db.add(layout)
    
    layout.layout_json = [w.dict() for w in request.layout]
    
    await db.commit()
    await db.refresh(layout)
    
    return {"user_id": "admin", "layout": layout.layout_json}

@router.post("/layout/reset")
async def reset_layout(
    db: AsyncSession = Depends(get_db),
    current_admin: str = Depends(get_current_admin)
):
    stmt = select(DashboardLayout).where(DashboardLayout.user_id == "admin")
    result = await db.execute(stmt)
    layout = result.scalars().first()
    
    if layout:
        layout.layout_json = DEFAULT_LAYOUT
        await db.commit()
    
    return {"user_id": "admin", "layout": DEFAULT_LAYOUT}
