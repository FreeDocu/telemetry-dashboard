from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from datetime import datetime
from app.database import get_db
from app.models import Token, Launch, BannedHwid
from app.schemas.telemetry import TelemetryPingRequest, LaunchResponse
from app.geoip import geo_manager
from app.websocket import broadcast_launch_event, broadcast_alert
from app.monitoring import track_request, track_db_query
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/telemetry", tags=["telemetry"])

@router.post("/ping", response_model=LaunchResponse)
@track_request("POST", "/telemetry/ping")
async def telemetry_ping(
    request: TelemetryPingRequest,
    http_request: Request,
    db: AsyncSession = Depends(get_db)
):
    # Get client IP
    client_ip = http_request.client.host
    
    # Validate token
    stmt = select(Token).where(
        (Token.token == request.token) & 
        (Token.active == True)
    )
    result = await db.execute(stmt)
    token = result.scalars().first()
    
    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or inactive token"
        )
    
    # Check token expiration
    if token.expires_at and token.expires_at < datetime.utcnow():
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token expired"
        )
    
    # Check if HWID is banned
    stmt = select(BannedHwid).where(BannedHwid.hwid == request.hwid)
    result = await db.execute(stmt)
    banned_hwid = result.scalars().first()
    
    if banned_hwid:
        if banned_hwid.until is None or banned_hwid.until > datetime.utcnow():
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"HWID banned: {banned_hwid.reason}"
            )
    
    # Get country from GeoIP
    country = geo_manager.get_country_by_ip(client_ip)
    
    # Create launch record
    launch = Launch(
        token_id=token.id,
        hwid=request.hwid,
        ip=client_ip,
        country=country,
        os=request.os,
        exe_version=request.exe_version,
        extra=request.extra
    )
    
    db.add(launch)
    await db.commit()
    await db.refresh(launch)
    
    # Broadcast launch event to WebSocket clients (non-blocking)
    try:
        launch_data = {
            "id": str(launch.id),
            "hwid": launch.hwid,
            "country": launch.country,
            "exe_version": launch.exe_version,
            "timestamp": launch.launched_at.isoformat(),
        }
        await broadcast_launch_event(launch_data)
    except Exception as e:
        logger.warning(f"WebSocket broadcast error: {e}")
    
    return LaunchResponse.model_validate(launch)
