from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends
from app.websocket import manager, broadcast_metric_update, broadcast_launch_event
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/ws", tags=["websocket"])


@router.websocket("/ws/updates")
async def websocket_endpoint(websocket: WebSocket):
    """
    WebSocket endpoint for real-time dashboard updates
    
    Messages from server:
    - metric_update: KPI metrics changed
    - launch_event: New telemetry launch
    - alert: Alert notification
    """
    await manager.connect(websocket)
    try:
        while True:
            # Keep connection alive, receive pings
            data = await websocket.receive_text()
            
            # Handle client messages (heartbeat, subscription filters, etc)
            if data == "ping":
                await manager.send_personal(websocket, {"type": "pong"})
            
    except WebSocketDisconnect:
        manager.disconnect(websocket)
        logger.info("Client disconnected from WebSocket")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        manager.disconnect(websocket)


@router.websocket("/ws/live-stats")
async def live_stats_endpoint(websocket: WebSocket):
    """
    WebSocket for live KPI stats (updates every 10 seconds)
    Sends: total_launches, unique_hwids, retention metrics
    """
    await manager.connect(websocket)
    try:
        while True:
            # Send stats every 10 seconds
            import asyncio
            await asyncio.sleep(10)
            
            from sqlalchemy import select, func
            from app.database import AsyncSessionLocal
            from app.models import Launch
            from datetime import datetime, timedelta
            
            async with AsyncSessionLocal() as session:
                # Get today's stats
                today = datetime.utcnow().date()
                
                stmt = select(func.count(Launch.id)).where(
                    func.date(Launch.launched_at) == today
                )
                result = await session.execute(stmt)
                launches_today = result.scalar() or 0
                
                stmt = select(func.count(func.distinct(Launch.hwid))).where(
                    func.date(Launch.launched_at) == today
                )
                result = await session.execute(stmt)
                unique_today = result.scalar() or 0
                
                await manager.send_personal(websocket, {
                    "type": "live_stats",
                    "launches_today": launches_today,
                    "unique_hwids_today": unique_today,
                    "timestamp": datetime.utcnow().isoformat()
                })
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        logger.error(f"Live stats error: {e}")
        manager.disconnect(websocket)
