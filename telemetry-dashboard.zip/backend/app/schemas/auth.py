from pydantic import BaseModel
from typing import Optional

class LoginRequest(BaseModel):
    username: str
    password: str
    totp_code: Optional[str] = None

class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int

class SetupTOTPRequest(BaseModel):
    current_password: str

class SetupTOTPResponse(BaseModel):
    secret: str
    qr_code: str  # Base64 encoded QR code

class ConfirmTOTPRequest(BaseModel):
    secret: str
    totp_code: str

class ConfirmTOTPResponse(BaseModel):
    success: bool
    backup_codes: Optional[list] = None
