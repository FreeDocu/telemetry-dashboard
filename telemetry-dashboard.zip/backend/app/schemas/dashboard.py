from pydantic import BaseModel
from typing import Optional, List, Dict, Any

class WidgetConfig(BaseModel):
    i: str  # Widget ID
    x: int
    y: int
    w: int
    h: int
    static: bool = False

class DashboardLayoutRequest(BaseModel):
    layout: List[WidgetConfig]

class DashboardLayoutResponse(BaseModel):
    user_id: str
    layout: List[WidgetConfig]

    class Config:
        from_attributes = True
