from pydantic import BaseModel
from typing import Optional, Dict, Any
from datetime import datetime

class TelemetryPingRequest(BaseModel):
    token: str
    hwid: str
    exe_version: Optional[str] = None
    os: Optional[str] = None
    launch_id: Optional[str] = None
    extra: Optional[Dict[str, Any]] = None

class LaunchResponse(BaseModel):
    id: str
    token_id: str
    hwid: str
    ip: str
    country: Optional[str]
    os: Optional[str]
    exe_version: Optional[str]
    launched_at: datetime
    extra: Optional[Dict[str, Any]]

    class Config:
        from_attributes = True
