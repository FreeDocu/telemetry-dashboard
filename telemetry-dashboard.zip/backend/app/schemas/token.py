from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class CreateTokenRequest(BaseModel):
    name: str
    note: Optional[str] = None
    expires_at: Optional[datetime] = None

class TokenResponse(BaseModel):
    id: str
    token: str
    name: str
    note: Optional[str]
    active: bool
    current_version: Optional[str]
    expires_at: Optional[datetime]
    created_at: datetime

    class Config:
        from_attributes = True

class UpdateTokenRequest(BaseModel):
    name: Optional[str] = None
    note: Optional[str] = None
    active: Optional[bool] = None
    current_version: Optional[str] = None
