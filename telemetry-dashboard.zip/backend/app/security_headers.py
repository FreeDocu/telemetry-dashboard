from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
from slowapi import Limiter
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
import hmac
import hashlib
from functools import wraps
import logging

logger = logging.getLogger(__name__)

# Rate limiter
limiter = Limiter(key_func=get_remote_address)

# Rate limit configurations
RATE_LIMITS = {
    "/api/v1/auth/login": "5/minute",  # 5 attempts per minute
    "/api/v1/telemetry/ping": "1000/minute",  # 1000 pings per minute
    "/api/v1/admin/tokens": "100/minute",  # API calls
}


def verify_request_signature(secret_key: str):
    """
    Decorator to verify HMAC-SHA256 signature on requests
    
    Client must include:
    - X-Signature header: HMAC-SHA256(body, secret_key)
    - X-Timestamp header: Unix timestamp
    
    Optional for admin endpoints, mandatory for public telemetry API
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(request: Request, *args, **kwargs):
            signature = request.headers.get("X-Signature")
            timestamp = request.headers.get("X-Timestamp")
            
            if not signature or not timestamp:
                # Only required for telemetry endpoint
                if "/telemetry" in request.url.path:
                    raise HTTPException(status_code=401, detail="Missing signature headers")
            else:
                try:
                    # Verify timestamp (within 5 minutes)
                    import time
                    current_time = int(time.time())
                    req_time = int(timestamp)
                    
                    if abs(current_time - req_time) > 300:
                        raise HTTPException(status_code=401, detail="Request timestamp expired")
                    
                    # Verify signature
                    body = await request.body()
                    expected_signature = hmac.new(
                        secret_key.encode(),
                        body + timestamp.encode(),
                        hashlib.sha256
                    ).hexdigest()
                    
                    if not hmac.compare_digest(signature, expected_signature):
                        raise HTTPException(status_code=401, detail="Invalid signature")
                
                except ValueError:
                    raise HTTPException(status_code=400, detail="Invalid timestamp")
            
            return await func(request, *args, **kwargs)
        
        return wrapper
    return decorator


class SecurityHeadersMiddleware:
    """Add security headers to all responses"""
    
    def __init__(self, app):
        self.app = app
    
    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        
        async def send_with_headers(message):
            if message["type"] == "http.response.start":
                headers = list(message.get("headers", []))
                
                # Content Security Policy
                headers.append((
                    b"content-security-policy",
                    b"default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self'"
                ))
                
                # X-Content-Type-Options - prevent MIME sniffing
                headers.append((b"x-content-type-options", b"nosniff"))
                
                # X-Frame-Options - prevent clickjacking
                headers.append((b"x-frame-options", b"DENY"))
                
                # X-XSS-Protection
                headers.append((b"x-xss-protection", b"1; mode=block"))
                
                # Strict-Transport-Security
                headers.append((
                    b"strict-transport-security",
                    b"max-age=31536000; includeSubDomains"
                ))
                
                # Referrer-Policy
                headers.append((b"referrer-policy", b"strict-origin-when-cross-origin"))
                
                # Permissions-Policy (formerly Feature-Policy)
                headers.append((
                    b"permissions-policy",
                    b"geolocation=(), microphone=(), camera=()"
                ))
                
                message["headers"] = headers
            
            await send(message)
        
        await self.app(scope, receive, send_with_headers)


rate_limit_error_handler = lambda request, exc: JSONResponse(
    status_code=429,
    content={"detail": "Rate limit exceeded. Try again later."}
)
