from fastapi import WebSocket
from typing import Set
import json
import asyncio
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class ConnectionManager:
    """Manage WebSocket connections for real-time updates"""
    
    def __init__(self):
        self.active_connections: Set[WebSocket] = set()
    
    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.add(websocket)
        logger.info(f"WebSocket connected. Active: {len(self.active_connections)}")
    
    def disconnect(self, websocket: WebSocket):
        self.active_connections.discard(websocket)
        logger.info(f"WebSocket disconnected. Active: {len(self.active_connections)}")
    
    async def broadcast(self, message: dict):
        """Send message to all connected clients"""
        disconnected = set()
        
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Broadcast error: {e}")
                disconnected.add(connection)
        
        # Clean up disconnected clients
        for connection in disconnected:
            self.disconnect(connection)
    
    async def send_personal(self, websocket: WebSocket, message: dict):
        """Send message to specific client"""
        try:
            await websocket.send_json(message)
        except Exception as e:
            logger.error(f"Send error: {e}")
            self.disconnect(websocket)


manager = ConnectionManager()


async def broadcast_metric_update(metric_name: str, value: any, timestamp: datetime = None):
    """Broadcast metric update to all connected clients"""
    message = {
        "type": "metric_update",
        "metric": metric_name,
        "value": value,
        "timestamp": (timestamp or datetime.utcnow()).isoformat()
    }
    await manager.broadcast(message)


async def broadcast_launch_event(launch_data: dict):
    """Broadcast new launch to dashboard"""
    message = {
        "type": "launch_event",
        "data": launch_data,
        "timestamp": datetime.utcnow().isoformat()
    }
    await manager.broadcast(message)


async def broadcast_alert(alert_type: str, message: str, severity: str = "info"):
    """Broadcast alert to all admins"""
    data = {
        "type": "alert",
        "alert_type": alert_type,
        "message": message,
        "severity": severity,
        "timestamp": datetime.utcnow().isoformat()
    }
    await manager.broadcast(data)
