"""Create initial admin user and tables"""
from sqlalchemy import select
from app.database import AsyncSessionLocal
from app.models import AdminUser
from app.security import hash_password
import asyncio

async def init_admin():
    async with AsyncSessionLocal() as session:
        # Check if admin exists
        stmt = select(AdminUser)
        result = await session.execute(stmt)
        admin = result.scalars().first()

        if not admin:
            admin = AdminUser(
                username="admin",
                password_hash=hash_password("admin123"),  # Change in production!
                totp_secret=None,
                totp_enabled=False,
                totp_locked=False,
            )
            session.add(admin)
            await session.commit()
            print("✓ Admin user created")
        else:
            print("✓ Admin user already exists")

if __name__ == "__main__":
    asyncio.run(init_admin())
