import pytest
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from app.main import app
from app.database import get_db, Base
from app.models import AdminUser, Token
from app.security import hash_password, create_access_token
import asyncio


# Test database
TEST_DATABASE_URL = "sqlite+aiosqlite:///:memory:"


@pytest.fixture(scope="session")
def event_loop():
    """Create event loop for tests"""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture(scope="session")
async def test_db():
    """Create test database"""
    engine = create_async_engine(TEST_DATABASE_URL, echo=False)
    
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    SessionLocal = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
    
    yield SessionLocal
    
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    
    await engine.dispose()


@pytest.fixture
async def client(test_db):
    """Test client"""
    
    async def override_get_db():
        async with test_db() as session:
            yield session
    
    app.dependency_overrides[get_db] = override_get_db
    
    with TestClient(app) as test_client:
        yield test_client
    
    app.dependency_overrides.clear()


@pytest.fixture
async def admin_user(test_db):
    """Create test admin user"""
    async with test_db() as session:
        admin = AdminUser(
            username="testadmin",
            password_hash=hash_password("testpass123"),
        )
        session.add(admin)
        await session.commit()
        await session.refresh(admin)
        return admin


@pytest.fixture
async def auth_token(admin_user):
    """Create test JWT token"""
    return create_access_token(data={"sub": admin_user.username})


@pytest.fixture
async def test_token(test_db):
    """Create test app token"""
    async with test_db() as session:
        token = Token(
            token="test_token_12345",
            name="Test App",
            note="For testing",
            active=True
        )
        session.add(token)
        await session.commit()
        await session.refresh(token)
        return token
