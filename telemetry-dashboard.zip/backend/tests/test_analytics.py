import pytest
from app.analytics_service import AnalyticsService


@pytest.mark.asyncio
async def test_user_segments():
    """Test user segmentation"""
    segments = await AnalyticsService.get_user_segments()
    
    assert "power_users" in segments
    assert "regular_users" in segments
    assert "inactive_users" in segments
    
    assert "count" in segments["power_users"]
    assert "sample" in segments["power_users"]


@pytest.mark.asyncio
async def test_churn_prediction():
    """Test churn prediction"""
    churn = await AnalyticsService.get_churn_prediction(period_days=7)
    
    assert "at_risk_count" in churn
    assert "sample_hwids" in churn
    assert "period_days" in churn


@pytest.mark.asyncio
async def test_cohort_analysis():
    """Test cohort analysis"""
    cohorts = await AnalyticsService.get_cohort_analysis()
    
    assert isinstance(cohorts, dict)
    # Each cohort should have at least d0 (day 0)
    for cohort_key, cohort_data in cohorts.items():
        assert "d0" in cohort_data
