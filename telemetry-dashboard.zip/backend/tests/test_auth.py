import pytest
from app.security import hash_password, verify_password, create_access_token, verify_token
from app.security import generate_totp_secret, verify_totp


def test_password_hashing():
    """Test password hashing"""
    password = "testpassword123"
    hash1 = hash_password(password)
    hash2 = hash_password(password)
    
    # Different hashes due to salt
    assert hash1 != hash2
    
    # But both verify against original password
    assert verify_password(password, hash1)
    assert verify_password(password, hash2)
    
    # Wrong password fails
    assert not verify_password("wrongpassword", hash1)


def test_jwt_token():
    """Test JWT token creation and verification"""
    data = {"sub": "testuser"}
    token = create_access_token(data)
    
    assert token is not None
    
    payload = verify_token(token)
    assert payload is not None
    assert payload["sub"] == "testuser"


def test_invalid_token():
    """Test invalid token verification"""
    payload = verify_token("invalid_token_xyz")
    assert payload is None


def test_totp_generation():
    """Test TOTP secret generation"""
    secret = generate_totp_secret()
    
    assert secret is not None
    assert len(secret) > 0


def test_totp_verification():
    """Test TOTP code verification"""
    secret = generate_totp_secret()
    
    # Get current TOTP code
    import pyotp
    totp = pyotp.TOTP(secret)
    code = totp.now()
    
    # Verify it works
    assert verify_totp(secret, code)
    
    # Invalid code fails
    assert not verify_totp(secret, "000000")
