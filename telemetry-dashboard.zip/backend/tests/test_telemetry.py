import pytest
from httpx import AsyncClient
from app.main import app


@pytest.mark.asyncio
async def test_telemetry_ping_missing_token():
    """Test telemetry ping with missing token"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post(
            "/api/v1/telemetry/ping",
            json={
                "hwid": "HWID-123",
                "exe_version": "1.0.0"
            }
        )
        assert response.status_code == 401


@pytest.mark.asyncio
async def test_telemetry_ping_invalid_token(test_token):
    """Test telemetry ping with invalid token"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post(
            "/api/v1/telemetry/ping",
            json={
                "token": "invalid_token",
                "hwid": "HWID-123",
                "exe_version": "1.0.0"
            }
        )
        assert response.status_code == 401


@pytest.mark.asyncio
async def test_telemetry_ping_success(test_token):
    """Test successful telemetry ping"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post(
            "/api/v1/telemetry/ping",
            json={
                "token": test_token.token,
                "hwid": "HWID-123",
                "exe_version": "1.0.0",
                "os": "Windows 10"
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert data["hwid"] == "HWID-123"
        assert data["exe_version"] == "1.0.0"
