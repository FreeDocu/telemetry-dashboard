#!/bin/bash

# Telemetry Dashboard - Production Build Script

set -e

echo "🔨 Building Telemetry Dashboard for Production"
echo "=============================================="
echo ""

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$PROJECT_ROOT/backend"
FRONTEND_DIR="$PROJECT_ROOT/frontend"
BUILD_DIR="$PROJECT_ROOT/build"

mkdir -p "$BUILD_DIR"

echo "📦 Building frontend..."
cd "$FRONTEND_DIR"
npm run build
cp -r dist "$BUILD_DIR/frontend"

echo "📦 Backend files..."
cd "$BACKEND_DIR"
mkdir -p "$BUILD_DIR/backend"
cp -r . "$BUILD_DIR/backend"

echo "📦 Root files..."
cp docker-compose.yml "$BUILD_DIR/"
cp README.md "$BUILD_DIR/"

echo ""
echo "✅ Build complete!"
echo ""
echo "Build output: $BUILD_DIR"
echo ""
echo "Next steps for deployment:"
echo "1. Update .env files with production settings"
echo "2. Use docker-compose to deploy:"
echo "   docker-compose up -d"
echo ""
