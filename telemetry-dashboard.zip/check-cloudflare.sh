#!/bin/bash

# Cloudflare Configuration Verification

echo "=========================================="
echo "Cloudflare Configuration Checker"
echo "Domain: drukvculgar.live"
echo "=========================================="
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Check DNS resolution
echo "1. Checking DNS Resolution..."
echo "=============================="
echo ""

for ip in $(dig +short drukvculgar.live A @8.8.8.8); do
    echo -e "  IPv4: $ip"
done

for ip in $(dig +short drukvculgar.live AAAA @8.8.8.8); do
    echo -e "  IPv6: $ip"
done

if dig +short drukvculgar.live @8.8.8.8 | grep -q .; then
    echo -e "  ${GREEN}DNS resolved successfully${NC}"
else
    echo -e "  ${RED}DNS not resolving - check Cloudflare DNS settings${NC}"
fi

echo ""
echo "2. Checking Cloudflare Nameservers..."
echo "======================================"
echo ""

# Check if using Cloudflare nameservers
ns_check=$(dig +short drukvculgar.live NS | grep cloudflare)
if [ ! -z "$ns_check" ]; then
    echo -e "  ${GREEN}Using Cloudflare nameservers${NC}"
    dig +short drukvculgar.live NS | head -5
else
    echo -e "  ${YELLOW}Not using Cloudflare nameservers - check your domain registrar${NC}"
    echo "  Expected nameservers:"
    echo "    - ns1.cloudflare.com"
    echo "    - ns2.cloudflare.com"
fi

echo ""
echo "3. SSL/TLS Configuration Checklist..."
echo "====================================="
echo ""

echo "Required Cloudflare Settings:"
echo ""
echo "SSL/TLS:"
echo "  ☐ Go to: https://dash.cloudflare.com/drukvculgar.live/ssl-tls"
echo "  ☐ Set 'SSL/TLS encryption mode' to 'Full (strict)'"
echo ""

echo "SSL/TLS > Origin Server:"
echo "  ☐ Create 'Origin Server Certificate'"
echo "  ☐ Download certificate and key"
echo "  ☐ Place cert.pem and key.pem in ./ssl/ folder"
echo ""

echo "Firewall > Bot Management:"
echo "  ☐ Enable 'Bot Fight Mode' (free)"
echo "  ☐ Or enable 'Super Bot Fight Mode' (paid)"
echo "  ☐ Challenge/Block suspicious traffic"
echo ""

echo "Rules:"
echo "  ☐ Consider adding WAF rules to block:"
echo "    - SQL injection patterns"
echo "    - XSS payloads"
echo "    - Path traversal attempts"
echo ""

echo "DNS Records:"
echo "  ☐ A record: drukvculgar.live → your-server-ip"
echo "  ☐ CNAME or A record: www.drukvculgar.live → drukvculgar.live"
echo "  ☐ Cloud status: Orange (Proxied through Cloudflare)"
echo ""

echo "4. Advanced Cloudflare Settings..."
echo "===================================="
echo ""

echo "Recommended:"
echo ""
echo "Caching:"
echo "  ☐ Cache Everything: Use custom cache control headers"
echo "  ☐ Cache Level: 'Cache Everything' for static assets"
echo "  ☐ Browser Cache TTL: 4 hours"
echo ""

echo "Performance:"
echo "  ☐ Minify: Enable JS, CSS, HTML minification"
echo "  ☐ Brotli compression: Enable"
echo "  ☐ Early Hints: Enable (if available)"
echo ""

echo "Page Rules (Optional):"
echo "  ☐ drukvculgar.live/metrics/* → Cannot access"
echo "  ☐ drukvculgar.live/api/* → Cache on even if up-to-date"
echo ""

echo "5. Testing Connectivity..."
echo "=========================="
echo ""

echo -n "Testing HTTPS..."
if timeout 5 openssl s_client -connect drukvculgar.live:443 < /dev/null 2>/dev/null | grep -q "Verify return code"; then
    echo -e " ${GREEN}OK${NC}"
else
    if timeout 5 curl -s https://drukvculgar.live/health > /dev/null 2>&1; then
        echo -e " ${GREEN}OK${NC}"
    else
        echo -e " ${RED}FAILED${NC} (Server may not be running yet)"
    fi
fi

echo ""
echo "6. Next Steps..."
echo "==============="
echo ""

echo "Production Deployment:"
echo "  1. Ensure SSL certificates are in ./ssl/ directory"
echo "  2. Configure .env.prod with credentials"
echo "  3. Run: bash deploy-prod.sh"
echo "  4. Run: docker-compose -f docker-compose.prod.yml up -d"
echo ""

echo "Testing:"
echo "  1. Local test: bash test-local.sh"
echo "  2. After deployment: bash test-deployment.sh"
echo ""

echo "Monitoring:"
echo "  1. Check Cloudflare Analytics: https://dash.cloudflare.com/drukvculgar.live"
echo "  2. Monitor backend logs: docker-compose -f docker-compose.prod.yml logs -f backend"
echo "  3. Check metrics: https://drukvculgar.live/metrics"
echo ""

echo "=========================================="
echo "Configuration Check Complete"
echo "=========================================="
echo ""
