#!/bin/bash

# Complete Production Deployment and Testing

set -e

echo "=========================================="
echo "Telemetry Dashboard v1.1"
echo "Production Deployment Suite"
echo "=========================================="
echo ""

cd "$(dirname "$0")"

# Step 1: Check Prerequisites
echo "Step 1: Checking Prerequisites..."
echo "=================================="
echo ""

if ! command -v docker &> /dev/null; then
    echo "ERROR: Docker not installed"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "ERROR: Docker Compose not installed"
    exit 1
fi

echo "OK: Docker and Docker Compose installed"
echo ""

# Step 2: Check Cloudflare Configuration
echo "Step 2: Checking Cloudflare Configuration..."
echo "============================================"
echo ""

bash check-cloudflare.sh
echo ""

# Step 3: Prepare Environment
echo "Step 3: Preparing Environment..."
echo "================================"
echo ""

# Create necessary directories
mkdir -p ssl logs

if [ ! -f backend/.env ]; then
    echo "Creating backend/.env..."
    cp .env.prod backend/.env
    echo "WARNING: Please edit backend/.env with actual credentials"
fi

echo "OK: Environment prepared"
echo ""

# Step 4: Build and Start Services
echo "Step 4: Building and Starting Services..."
echo "=========================================="
echo ""

# Stop existing containers
docker-compose -f docker-compose.prod.yml down 2>/dev/null || true

# Build fresh
docker-compose -f docker-compose.prod.yml build --no-cache

# Start services
docker-compose -f docker-compose.prod.yml up -d

echo ""
echo "Waiting for services to be ready..."
sleep 30

echo ""
echo "Service Status:"
docker-compose -f docker-compose.prod.yml ps

echo ""

# Step 5: Run Tests
echo "Step 5: Running Tests..."
echo "======================="
echo ""

bash test-deployment.sh

echo ""

# Step 6: Summary
echo "Step 6: Deployment Summary..."
echo "============================="
echo ""

echo "Production URLs:"
echo "  Frontend:  https://drukvculgar.live"
echo "  API:       https://drukvculgar.live/api/v1"
echo "  Health:    https://drukvculgar.live/health"
echo "  Metrics:   https://drukvculgar.live/metrics (restricted)"
echo ""

echo "Local URLs (for testing only):"
echo "  Frontend:  http://localhost"
echo "  API:       http://localhost/api/v1"
echo "  Backend:   http://localhost:8000"
echo "  Frontend:  http://localhost:5173"
echo ""

echo "Database Access:"
echo "  psql -h localhost -U telemetry -d telemetry_db"
echo ""

echo "Redis Access:"
echo "  redis-cli -h localhost -p 6379"
echo ""

echo "View Logs:"
echo "  docker-compose -f docker-compose.prod.yml logs -f backend"
echo "  docker-compose -f docker-compose.prod.yml logs -f frontend"
echo "  docker-compose -f docker-compose.prod.yml logs -f nginx"
echo ""

echo "Stop Services:"
echo "  docker-compose -f docker-compose.prod.yml down"
echo ""

echo "=========================================="
echo "Deployment Complete!"
echo "=========================================="
echo ""
