#!/bin/bash

# Telemetry Dashboard - Production Deployment for Cloudflare
# This script sets up the production environment with Cloudflare support

set -e

echo "=========================================="
echo "Telemetry Dashboard v1.1"
echo "Production Deployment Setup"
echo "Domain: drukvculgar.live"
echo "=========================================="
echo ""

# Check prerequisites
echo "Checking prerequisites..."

if ! command -v docker &> /dev/null; then
    echo "ERROR: Docker is not installed"
    exit 1
fi

if ! command -v openssl &> /dev/null; then
    echo "ERROR: OpenSSL is not installed"
    exit 1
fi

echo "OK: Docker and OpenSSL found"
echo ""

# Create SSL directory
mkdir -p ssl

# SSL Certificate Setup Instructions
echo "IMPORTANT: SSL Certificate Setup"
echo "================================="
echo ""
echo "You have two options:"
echo ""
echo "Option 1: Use Cloudflare Origin Certificate (Recommended)"
echo "  1. Go to: https://dash.cloudflare.com/your-account/drukvculgar.live/ssl-tls/origin"
echo "  2. Create 'Origin Server Certificate'"
echo "  3. Download certificate and key"
echo "  4. Place in: ssl/cert.pem and ssl/key.pem"
echo ""
echo "Option 2: Use Self-signed Certificate (Development)"
echo "  Run: openssl req -x509 -newkey rsa:4096 -nodes -out ssl/cert.pem -keyout ssl/key.pem -days 365"
echo ""

# Check if certificates exist
if [ ! -f ssl/cert.pem ] || [ ! -f ssl/key.pem ]; then
    echo "WARNING: SSL certificates not found in ssl/ directory"
    echo ""
    
    # Offer to create self-signed certificate
    read -p "Create self-signed certificate for testing? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "Generating self-signed certificate..."
        openssl req -x509 -newkey rsa:4096 -nodes \
            -out ssl/cert.pem -keyout ssl/key.pem -days 365 \
            -subj "/CN=drukvculgar.live"
        echo "OK: Self-signed certificate generated"
        echo "WARNING: Replace with Cloudflare Origin Certificate in production!"
    else
        echo "ERROR: SSL certificates required to continue"
        exit 1
    fi
fi

echo ""
echo "Configuring environment..."

# Setup backend .env
if [ ! -f backend/.env ]; then
    echo "Creating backend/.env from .env.prod..."
    cp .env.prod backend/.env
    echo "IMPORTANT: Edit backend/.env and set:"
    echo "  - DATABASE_URL with actual credentials"
    echo "  - SECRET_KEY with a strong random string (min 32 chars)"
    echo "  - REDIS_PASSWORD with a secure password"
    echo "  - POSTGRES_PASSWORD with a secure password"
    read -p "Press Enter after configuring backend/.env..."
fi

# Setup frontend
if [ ! -d frontend/node_modules ]; then
    echo "Installing frontend dependencies..."
    cd frontend
    npm ci
    cd ..
fi

# Create docker network
echo ""
echo "Setting up Docker network..."
docker network create telemetry-net 2>/dev/null || echo "Network already exists"

# Build production images
echo ""
echo "Building Docker images..."
docker-compose -f docker-compose.prod.yml build --no-cache

echo ""
echo "=========================================="
echo "Production Setup Complete!"
echo "=========================================="
echo ""
echo "Next steps:"
echo ""
echo "1. Verify SSL certificates are in place:"
echo "   ls -la ssl/"
echo ""
echo "2. Start production services:"
echo "   docker-compose -f docker-compose.prod.yml up -d"
echo ""
echo "3. Verify services are running:"
echo "   docker-compose -f docker-compose.prod.yml ps"
echo ""
echo "4. Check logs:"
echo "   docker-compose -f docker-compose.prod.yml logs -f backend"
echo ""
echo "5. Configure Cloudflare:"
echo "   - Go to: https://dash.cloudflare.com"
echo "   - Zone: drukvculgar.live"
echo "   - DNS: Add A record pointing to your server IP"
echo "   - SSL/TLS: Set to 'Full (strict)'"
echo "   - Firewall: Configure Bot Management"
echo ""
echo "Access:"
echo "  Frontend:  https://drukvculgar.live"
echo "  Backend:   https://drukvculgar.live/api/v1"
echo "  Health:    https://drukvculgar.live/health"
echo "  Metrics:   https://drukvculgar.live/metrics (restricted)"
echo ""
