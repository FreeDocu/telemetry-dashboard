import React from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { useAuthStore } from '@/store/auth'
import { LoginPage } from '@/pages/LoginPage'
import { DashboardPage } from '@/pages/DashboardPage'
import { TokenManagementPage } from '@/pages/TokenManagementPage'
import { SettingsPage } from '@/pages/SettingsPage'
import { BanManagementPage } from '@/pages/BanManagementPage'
import { DesktopSidebar } from '@/components/Sidebar'
import '@/styles/index.css'

const queryClient = new QueryClient()

interface ProtectedRouteProps {
  children: React.ReactNode
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const { token } = useAuthStore()

  if (!token) {
    return <Navigate to="/login" replace />
  }

  return <div className="flex">{children}</div>
}

function App() {
  const { token } = useAuthStore()

  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          
          <Route
            path="/dashboard"
            element={
              <ProtectedRoute>
                <DesktopSidebar />
                <div className="flex-1">
                  <DashboardPage />
                </div>
              </ProtectedRoute>
            }
          />
          
          <Route
            path="/tokens"
            element={
              <ProtectedRoute>
                <DesktopSidebar />
                <div className="flex-1">
                  <TokenManagementPage />
                </div>
              </ProtectedRoute>
            }
          />
          
          <Route
            path="/bans"
            element={
              <ProtectedRoute>
                <DesktopSidebar />
                <div className="flex-1">
                  <BanManagementPage />
                </div>
              </ProtectedRoute>
            }
          />
          
          <Route
            path="/settings"
            element={
              <ProtectedRoute>
                <DesktopSidebar />
                <div className="flex-1">
                  <SettingsPage />
                </div>
              </ProtectedRoute>
            }
          />
          
          <Route path="/" element={<Navigate to={token ? '/dashboard' : '/login'} replace />} />
        </Routes>
      </Router>
    </QueryClientProvider>
  )
}

export default App
