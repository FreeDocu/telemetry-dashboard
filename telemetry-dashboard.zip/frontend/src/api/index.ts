import api from './client'

export const authAPI = {
  login: (username: string, password: string, totp_code?: string) =>
    api.post('/auth/login', { username, password, totp_code }),
  
  setupTOTP: (current_password: string) =>
    api.post('/auth/totp/setup', { current_password }),
  
  confirmTOTP: (secret: string, totp_code: string) =>
    api.post('/auth/totp/confirm', { secret, totp_code }),
}

export const tokenAPI = {
  create: (name: string, note?: string, expires_at?: string) =>
    api.post('/admin/tokens', { name, note, expires_at }),
  
  list: () => api.get('/admin/tokens'),
  
  get: (tokenId: string) => api.get(`/admin/tokens/${tokenId}`),
  
  update: (tokenId: string, data: any) =>
    api.patch(`/admin/tokens/${tokenId}`, data),
  
  delete: (tokenId: string) => api.delete(`/admin/tokens/${tokenId}`),
}

export const telemetryAPI = {
  ping: (data: any) => api.post('/telemetry/ping', data),
}

export const adminAPI = {
  banHWID: (hwid: string, reason?: string, token_id?: string, until?: string) =>
    api.post('/admin/bans/hwid', { hwid, reason, token_id, until }),
  
  listBans: () => api.get('/admin/bans/hwid'),
  
  unban: (hwid: string) => api.delete(`/admin/bans/hwid/${hwid}`),
}

export const analyticsAPI = {
  getSummary: (token_ids?: string[], period_hours?: number) =>
    api.get('/analytics/summary', {
      params: { token_ids, period_hours },
    }),
  
  getTimeline: (token_ids?: string[], period_hours?: number, interval?: string) =>
    api.get('/analytics/launches/timeline', {
      params: { token_ids, period_hours, interval },
    }),
  
  getCountries: (token_ids?: string[], period_hours?: number, limit?: number) =>
    api.get('/analytics/analytics/countries', {
      params: { token_ids, period_hours, limit },
    }),
  
  getHWIDs: (token_ids?: string[], period_hours?: number, limit?: number) =>
    api.get('/analytics/analytics/hwids', {
      params: { token_ids, period_hours, limit },
    }),
  
  getVersions: (token_ids?: string[], period_hours?: number) =>
    api.get('/analytics/analytics/versions', {
      params: { token_ids, period_hours },
    }),
}

export const dashboardAPI = {
  getLayout: () => api.get('/dashboard/layout'),
  
  saveLayout: (layout: any) => api.post('/dashboard/layout', { layout }),
  
  resetLayout: () => api.post('/dashboard/layout/reset'),
}
