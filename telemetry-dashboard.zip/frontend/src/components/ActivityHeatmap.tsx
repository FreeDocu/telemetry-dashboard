import React from 'react'

interface HeatmapCellProps {
  value: number
  maxValue: number
  hour: number
  day: string
}

const getColor = (value: number, max: number): string => {
  const ratio = value / max
  if (ratio < 0.2) return 'bg-slate-700'
  if (ratio < 0.4) return 'bg-blue-900'
  if (ratio < 0.6) return 'bg-blue-700'
  if (ratio < 0.8) return 'bg-blue-500'
  return 'bg-blue-300'
}

export const HeatmapCell: React.FC<HeatmapCellProps> = ({ value, maxValue, hour, day }) => {
  return (
    <div
      className={`w-8 h-8 rounded flex items-center justify-center text-xs cursor-pointer hover:ring-2 ring-white transition ${getColor(
        value,
        maxValue
      )}`}
      title={`${day} ${hour}:00 - ${value} launches`}
    >
      {value > 0 && <span className="text-white/70 font-semibold">{value}</span>}
    </div>
  )
}

export const ActivityHeatmap: React.FC<{ data?: any }> = ({ data }) => {
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
  const hours = Array.from({ length: 24 }, (_, i) => i)

  // Mock data
  const mockData = Array.from({ length: 7 }, () =>
    Array.from({ length: 24 }, () => Math.floor(Math.random() * 100))
  )

  const maxValue = Math.max(...mockData.flat())

  return (
    <div className="widget-container">
      <h3 className="text-lg font-semibold text-white mb-4">Activity Heatmap (24h × 7d)</h3>
      <div className="overflow-x-auto">
        <div className="flex gap-2">
          <div className="flex flex-col justify-end gap-1">
            {days.map((day) => (
              <div key={day} className="w-16 text-xs text-white/70 h-8 flex items-center">
                {day.slice(0, 3)}
              </div>
            ))}
          </div>

          <div className="flex gap-1">
            {hours.map((hour) => (
              <div key={`col-${hour}`} className="flex flex-col gap-1">
                <div className="w-8 text-xs text-white/70 text-center">{hour}</div>
                {days.map((day, dayIdx) => (
                  <HeatmapCell
                    key={`${dayIdx}-${hour}`}
                    value={mockData[dayIdx][hour]}
                    maxValue={maxValue}
                    hour={hour}
                    day={day}
                  />
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
