import React, { useState } from 'react'
import { Responsive as ResponsiveGridLayout, WidthProvider, Layouts } from 'react-grid-layout'
import 'react-grid-layout/css/styles.css'
import 'react-resizable/css/styles.css'

const ResponsiveGridLayoutComponent = WidthProvider(ResponsiveGridLayout)

interface DashboardGridProps {
  children: React.ReactNode[]
  onLayoutChange?: (layout: Layouts) => void
  layouts?: Layouts
  isEditing?: boolean
}

export const DashboardGrid: React.FC<DashboardGridProps> = ({
  children,
  onLayoutChange,
  layouts,
  isEditing = false,
}) => {
  const defaultLayouts: Layouts = {
    lg: [
      { i: 'kpi-unique-hwid', x: 0, y: 0, w: 3, h: 1, static: !isEditing },
      { i: 'kpi-launches-today', x: 3, y: 0, w: 3, h: 1, static: !isEditing },
      { i: 'kpi-retention-d1', x: 6, y: 0, w: 2, h: 1, static: !isEditing },
      { i: 'kpi-retention-d7', x: 8, y: 0, w: 2, h: 1, static: !isEditing },
      { i: 'kpi-retention-d30', x: 10, y: 0, w: 2, h: 1, static: !isEditing },
      { i: 'filters', x: 0, y: 1, w: 12, h: 2, static: false },
      { i: 'retention-curves', x: 0, y: 3, w: 12, h: 4, static: false },
      { i: 'heatmap-activity', x: 0, y: 7, w: 6, h: 4, static: false },
      { i: 'top-hwids', x: 6, y: 7, w: 6, h: 4, static: false },
      { i: 'geography', x: 0, y: 11, w: 6, h: 4, static: false },
      { i: 'versions', x: 6, y: 11, w: 6, h: 4, static: false },
    ],
    md: [
      { i: 'kpi-unique-hwid', x: 0, y: 0, w: 2, h: 1, static: !isEditing },
      { i: 'kpi-launches-today', x: 2, y: 0, w: 2, h: 1, static: !isEditing },
      { i: 'kpi-retention-d1', x: 4, y: 0, w: 2, h: 1, static: !isEditing },
      { i: 'kpi-retention-d7', x: 6, y: 0, w: 2, h: 1, static: !isEditing },
      { i: 'kpi-retention-d30', x: 8, y: 0, w: 2, h: 1, static: !isEditing },
      { i: 'filters', x: 0, y: 1, w: 10, h: 2, static: false },
      { i: 'retention-curves', x: 0, y: 3, w: 10, h: 4, static: false },
      { i: 'heatmap-activity', x: 0, y: 7, w: 5, h: 4, static: false },
      { i: 'top-hwids', x: 5, y: 7, w: 5, h: 4, static: false },
      { i: 'geography', x: 0, y: 11, w: 5, h: 4, static: false },
      { i: 'versions', x: 5, y: 11, w: 5, h: 4, static: false },
    ],
    sm: [
      { i: 'kpi-unique-hwid', x: 0, y: 0, w: 6, h: 1, static: !isEditing },
      { i: 'kpi-launches-today', x: 0, y: 1, w: 6, h: 1, static: !isEditing },
      { i: 'kpi-retention-d1', x: 0, y: 2, w: 6, h: 1, static: !isEditing },
      { i: 'kpi-retention-d7', x: 0, y: 3, w: 6, h: 1, static: !isEditing },
      { i: 'kpi-retention-d30', x: 0, y: 4, w: 6, h: 1, static: !isEditing },
      { i: 'filters', x: 0, y: 5, w: 6, h: 2, static: false },
      { i: 'retention-curves', x: 0, y: 7, w: 6, h: 4, static: false },
      { i: 'heatmap-activity', x: 0, y: 11, w: 6, h: 4, static: false },
      { i: 'top-hwids', x: 0, y: 15, w: 6, h: 4, static: false },
      { i: 'geography', x: 0, y: 19, w: 6, h: 4, static: false },
      { i: 'versions', x: 0, y: 23, w: 6, h: 4, static: false },
    ],
  }

  return (
    <ResponsiveGridLayoutComponent
      className="grid-layout"
      layouts={layouts || defaultLayouts}
      onLayoutChange={onLayoutChange}
      isDraggable={isEditing}
      isResizable={isEditing}
      compactType="vertical"
      preventCollision={false}
      containerPadding={[16, 16]}
      margin={[16, 16]}
      breakpoints={{ lg: 1200, md: 996, sm: 480 }}
      cols={{ lg: 12, md: 10, sm: 6 }}
      rowHeight={100}
    >
      {children}
    </ResponsiveGridLayoutComponent>
  )
}

export default DashboardGrid
