import React, { useState } from 'react'
import { useDashboardFilters } from '@/store/filters'

export const FilterPanel: React.FC = () => {
  const { filters, setFilters } = useDashboardFilters()
  const [isExpanded, setIsExpanded] = useState(true)

  const periodOptions = [
    { hours: 1, label: '1h' },
    { hours: 2, label: '2h' },
    { hours: 6, label: '6h' },
    { hours: 12, label: '12h' },
    { hours: 24, label: '24h' },
    { hours: 48, label: '2d' },
    { hours: 168, label: '7d' },
    { hours: 720, label: '30d' },
  ]

  return (
    <div className="widget-container">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white">Filters</h3>
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="text-xs px-3 py-1 bg-white/10 rounded hover:bg-white/20 transition"
        >
          {isExpanded ? 'Collapse' : 'Expand'}
        </button>
      </div>

      {isExpanded && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="text-xs font-semibold text-white/70 uppercase">Period</label>
            <div className="flex flex-wrap gap-2 mt-2">
              {periodOptions.map((opt) => (
                <button
                  key={opt.hours}
                  onClick={() => setFilters({ periodHours: opt.hours })}
                  className={`px-3 py-1 rounded text-xs font-medium transition ${
                    filters.periodHours === opt.hours
                      ? 'bg-blue-500 text-white'
                      : 'bg-white/10 text-white/70 hover:bg-white/20'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-white/70 uppercase">Options</label>
            <div className="space-y-2 mt-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={filters.suspiciousOnly}
                  onChange={(e) => setFilters({ suspiciousOnly: e.target.checked })}
                  className="w-4 h-4 rounded"
                />
                <span className="text-sm text-white/70">Suspicious only</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={filters.bannedOnly}
                  onChange={(e) => setFilters({ bannedOnly: e.target.checked })}
                  className="w-4 h-4 rounded"
                />
                <span className="text-sm text-white/70">Banned only</span>
              </label>
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-white/70 uppercase">Presets</label>
            <div className="flex flex-col gap-2 mt-2">
              <button className="px-3 py-1 bg-white/10 text-white/70 hover:bg-white/20 text-xs rounded transition">
                Daily Check
              </button>
              <button className="px-3 py-1 bg-white/10 text-white/70 hover:bg-white/20 text-xs rounded transition">
                Retention Deep
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
