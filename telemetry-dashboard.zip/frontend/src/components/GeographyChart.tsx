import React from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

export const GeographyChart: React.FC<{ data?: any[] }> = ({ data = [] }) => {
  const chartData =
    data.length > 0
      ? data
      : [
          { country: 'US', launches: 2400, unique_hwids: 600 },
          { country: 'RU', launches: 2210, unique_hwids: 550 },
          { country: 'DE', launches: 2290, unique_hwids: 500 },
          { country: 'FR', launches: 2000, unique_hwids: 450 },
          { country: 'GB', launches: 1890, unique_hwids: 420 },
        ]

  return (
    <div className="widget-container">
      <h3 className="text-lg font-semibold text-white mb-4">Top Countries</h3>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
          <XAxis dataKey="country" stroke="rgba(255,255,255,0.5)" />
          <YAxis stroke="rgba(255,255,255,0.5)" />
          <Tooltip
            contentStyle={{
              backgroundColor: 'rgba(15,23,42,0.8)',
              border: '1px solid rgba(255,255,255,0.1)',
              borderRadius: '8px',
            }}
          />
          <Legend />
          <Bar dataKey="launches" fill="#3b82f6" name="Launches" radius={[8, 8, 0, 0]} />
          <Bar dataKey="unique_hwids" fill="#10b981" name="Unique HWIDs" radius={[8, 8, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
