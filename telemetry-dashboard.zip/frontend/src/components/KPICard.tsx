import React from 'react'

interface KPICardProps {
  label: string
  value: string | number
  icon?: React.ReactNode
  trend?: number
  color?: string
}

export const KPICard: React.FC<KPICardProps> = ({
  label,
  value,
  icon,
  trend,
  color = 'from-blue-500 to-cyan-500',
}) => {
  return (
    <div className={`widget-container bg-gradient-to-br ${color} p-6`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-semibold text-white/70 uppercase tracking-wider">
            {label}
          </p>
          <p className="text-3xl font-bold text-white mt-2 count-up">{value}</p>
          {trend !== undefined && (
            <p className={`text-xs mt-1 ${trend >= 0 ? 'text-green-300' : 'text-red-300'}`}>
              {trend >= 0 ? '+' : ''}{trend}% vs yesterday
            </p>
          )}
        </div>
        {icon && <div className="text-4xl opacity-20">{icon}</div>}
      </div>
    </div>
  )
}
