import React, { useState } from 'react'
import { useAuthStore } from '@/store/auth'
import { useNavigate } from 'react-router-dom'

export const Navbar: React.FC = () => {
  const { logout, username } = useAuthStore()
  const navigate = useNavigate()
  const [showMenu, setShowMenu] = useState(false)

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  return (
    <nav className="glass-effect border-b border-white/10 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold">📊</span>
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">Telemetry Dashboard</h1>
            <p className="text-xs text-white/50">Monitoring System</p>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="text-right">
            <p className="text-sm text-white">{username || 'Admin'}</p>
            <p className="text-xs text-white/50">Administrator</p>
          </div>
          <div className="relative">
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-white font-semibold hover:shadow-lg transition"
            >
              {(username || 'A')[0].toUpperCase()}
            </button>

            {showMenu && (
              <div className="absolute right-0 mt-2 w-48 glass-effect rounded-lg shadow-lg py-2 z-50">
                <button className="w-full text-left px-4 py-2 text-sm text-white/70 hover:bg-white/10 transition">
                  ⚙️ Settings
                </button>
                <button className="w-full text-left px-4 py-2 text-sm text-white/70 hover:bg-white/10 transition">
                  🔐 Two-Factor Auth
                </button>
                <hr className="border-white/10 my-2" />
                <button
                  onClick={handleLogout}
                  className="w-full text-left px-4 py-2 text-sm text-red-400 hover:bg-red-500/10 transition"
                >
                  🚪 Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  )
}
