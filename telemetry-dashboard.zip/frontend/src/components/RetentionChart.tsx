import React from 'react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

interface RetentionChartProps {
  data: Array<any>
}

export const RetentionChart: React.FC<RetentionChartProps> = ({ data }) => {
  return (
    <div className="widget-container">
      <h3 className="text-lg font-semibold text-white mb-4">Retention Curves</h3>
      <ResponsiveContainer width="100%" height={400}>
        <LineChart data={data || []}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
          <XAxis dataKey="day" stroke="rgba(255,255,255,0.5)" />
          <YAxis stroke="rgba(255,255,255,0.5)" />
          <Tooltip
            contentStyle={{
              backgroundColor: 'rgba(15,23,42,0.8)',
              border: '1px solid rgba(255,255,255,0.1)',
              borderRadius: '8px',
            }}
            formatter={(value: any) => `${(value as number).toFixed(1)}%`}
          />
          <Legend />
          <Line
            type="monotone"
            dataKey="d1"
            stroke="#22c55e"
            name="D1 Retention"
            dot={false}
            strokeWidth={2}
            isAnimationActive={true}
          />
          <Line
            type="monotone"
            dataKey="d7"
            stroke="#3b82f6"
            name="D7 Retention"
            dot={false}
            strokeWidth={2}
            isAnimationActive={true}
          />
          <Line
            type="monotone"
            dataKey="d30"
            stroke="#f59e0b"
            name="D30 Retention"
            dot={false}
            strokeWidth={2}
            isAnimationActive={true}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
