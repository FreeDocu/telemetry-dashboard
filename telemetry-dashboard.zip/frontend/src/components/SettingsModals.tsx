import React, { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useTheme, applyTheme } from '../store/theme';
import { getShortcutsList } from '../hooks/useKeyboardShortcuts';
import { X, Moon, Sun, Globe } from 'lucide-react';

interface Modal {
  type: 'shortcuts' | 'theme' | 'language' | null;
}

export function useSettingsModals() {
  const [modal, setModal] = useState<Modal['type']>(null);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const toggleShortcuts = () => setModal('shortcuts');
    const toggleCommandPalette = () => setModal('language');
    const toggleTheme = () => setModal('theme');

    window.addEventListener('toggle-shortcuts-help', toggleShortcuts);
    window.addEventListener('toggle-command-palette', toggleCommandPalette);

    return () => {
      window.removeEventListener('toggle-shortcuts-help', toggleShortcuts);
      window.removeEventListener('toggle-command-palette', toggleCommandPalette);
    };
  }, []);

  return { modal, setModal, isOpen, setIsOpen };
}

export function ShortcutsModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const { t } = useTranslation();
  const shortcuts = getShortcutsList();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-gray-900 border border-gray-700 rounded-lg shadow-xl p-6 max-w-md w-full">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-white">Keyboard Shortcuts</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X size={20} />
          </button>
        </div>

        <div className="space-y-3">
          {shortcuts.map((shortcut) => (
            <div key={shortcut.keys} className="flex justify-between items-center py-2 border-b border-gray-700">
              <span className="text-gray-300">{shortcut.title}</span>
              <kbd className="px-2 py-1 bg-gray-800 border border-gray-600 rounded text-sm text-white font-mono">
                {shortcut.keys}
              </kbd>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();

  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  return (
    <button
      onClick={toggleTheme}
      className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-white transition-colors"
      title="Toggle theme"
    >
      {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
    </button>
  );
}

export function LanguageSelector() {
  const { i18n } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="p-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-white transition-colors flex items-center gap-2"
      >
        <Globe size={20} />
        <span className="text-sm font-medium">{i18n.language.toUpperCase()}</span>
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 bg-gray-800 border border-gray-700 rounded-lg shadow-lg overflow-hidden z-50">
          <button
            onClick={() => {
              i18n.changeLanguage('en');
              setIsOpen(false);
            }}
            className="w-full px-4 py-2 text-left text-white hover:bg-gray-700 transition-colors"
          >
            English
          </button>
          <button
            onClick={() => {
              i18n.changeLanguage('ru');
              setIsOpen(false);
            }}
            className="w-full px-4 py-2 text-left text-white hover:bg-gray-700 transition-colors border-t border-gray-700"
          >
            Русский
          </button>
        </div>
      )}
    </div>
  );
}
