import React from 'react'
import { useNavigate, useLocation } from 'react-router-dom'

interface SidebarProps {
  isOpen: boolean
  onClose?: () => void
}

interface NavItem {
  path: string
  label: string
  icon: string
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose = () => {} }) => {
  const navigate = useNavigate()
  const location = useLocation()

  const navItems: NavItem[] = [
    { path: '/dashboard', label: 'Dashboard', icon: '📊' },
    { path: '/tokens', label: 'Tokens', icon: '🔑' },
    { path: '/bans', label: 'HWID Bans', icon: '🚫' },
    { path: '/settings', label: 'Settings', icon: '⚙️' },
  ]

  const handleNavClick = (path: string) => {
    navigate(path)
    onClose()
  }

  return (
    <div
      className={`fixed inset-0 z-40 transition-opacity ${
        isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
      }`}
      onClick={onClose}
    >
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
    </div>
  )
}

export const DesktopSidebar: React.FC = () => {
  const location = useLocation()

  const navItems: NavItem[] = [
    { path: '/dashboard', label: 'Dashboard', icon: '📊' },
    { path: '/tokens', label: 'Tokens', icon: '🔑' },
    { path: '/bans', label: 'HWID Bans', icon: '🚫' },
    { path: '/settings', label: 'Settings', icon: '⚙️' },
  ]

  return (
    <div className="w-64 glass-effect border-r border-white/10 min-h-screen p-6">
      <div className="mb-8">
        <h2 className="text-lg font-bold text-white">Admin Panel</h2>
      </div>

      <nav className="space-y-2">
        {navItems.map((item) => {
          const isActive = location.pathname.startsWith(item.path)
          return (
            <a
              key={item.path}
              href={item.path}
              className={`block px-4 py-3 rounded-lg transition ${
                isActive
                  ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                  : 'text-white/70 hover:bg-white/10 hover:text-white'
              }`}
            >
              <span className="mr-3">{item.icon}</span>
              {item.label}
            </a>
          )
        })}
      </nav>
    </div>
  )
}
