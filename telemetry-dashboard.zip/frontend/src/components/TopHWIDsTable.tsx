import React from 'react'

export const TopHWIDsTable: React.FC<{ data?: any[] }> = ({ data = [] }) => {
  const tableData =
    data.length > 0
      ? data
      : [
          { hwid: 'HWID-12345ABC', launches: 145, last_seen: '2s ago', suspicious: false },
          { hwid: 'HWID-67890DEF', launches: 98, last_seen: '5m ago', suspicious: true },
          { hwid: 'HWID-11111111', launches: 76, last_seen: '15m ago', suspicious: false },
          { hwid: 'HWID-22222222', launches: 54, last_seen: '1h ago', suspicious: false },
          { hwid: 'HWID-33333333', launches: 42, last_seen: '3h ago', suspicious: false },
        ]

  return (
    <div className="widget-container">
      <h3 className="text-lg font-semibold text-white mb-4">Top Active HWIDs</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-white/10">
              <th className="text-left py-3 px-2 text-white/70 font-semibold">HWID</th>
              <th className="text-right py-3 px-2 text-white/70 font-semibold">Launches</th>
              <th className="text-left py-3 px-2 text-white/70 font-semibold">Last Seen</th>
              <th className="text-center py-3 px-2 text-white/70 font-semibold">Status</th>
            </tr>
          </thead>
          <tbody>
            {tableData.map((row) => (
              <tr key={row.hwid} className="border-b border-white/5 hover:bg-white/5 transition">
                <td className="py-3 px-2 text-white font-mono text-xs">{row.hwid}</td>
                <td className="py-3 px-2 text-right text-white font-semibold bar-fill">
                  {row.launches}
                </td>
                <td className="py-3 px-2 text-white/60 text-xs">{row.last_seen}</td>
                <td className="py-3 px-2 text-center">
                  <span
                    className={`text-xs font-semibold px-2 py-1 rounded ${
                      row.suspicious
                        ? 'bg-red-500/20 text-red-300'
                        : 'bg-green-500/20 text-green-300'
                    }`}
                  >
                    {row.suspicious ? '⚠ Suspicious' : '✓ Normal'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
