import React from 'react'
import { PieChart, Pie, Cell, Legend, Tooltip, ResponsiveContainer } from 'recharts'

const COLORS = ['#3b82f6', '#ec4899', '#f59e0b', '#10b981', '#8b5cf6', '#06b6d4']

export const VersionChart: React.FC<{ data?: any[] }> = ({ data = [] }) => {
  const chartData =
    data.length > 0
      ? data
      : [
          { version: 'v1.0.0', launches: 450, unique_hwids: 120 },
          { version: 'v1.0.1', launches: 350, unique_hwids: 95 },
          { version: 'v0.9.9', launches: 200, unique_hwids: 50 },
          { version: 'Other', launches: 100, unique_hwids: 30 },
        ]

  return (
    <div className="widget-container">
      <h3 className="text-lg font-semibold text-white mb-4">EXE Versions</h3>
      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie
            data={chartData}
            cx="50%"
            cy="50%"
            labelLine={true}
            label={({ version, launches }) => `${version}: ${launches}`}
            outerRadius={80}
            fill="#8884d8"
            dataKey="launches"
            animationBegin={0}
            animationDuration={800}
            animationEasing="ease-out"
          >
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip
            formatter={(value: any) => `${value} launches`}
            contentStyle={{
              backgroundColor: 'rgba(15,23,42,0.8)',
              border: '1px solid rgba(255,255,255,0.1)',
              borderRadius: '8px',
            }}
          />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  )
}
