import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const KEYBOARD_SHORTCUTS = {
  'Cmd-k': { title: 'Command Palette', action: () => {} }, // Placeholder
  'Cmd-s': { title: 'Save Dashboard', action: () => {} },
  '?': { title: 'Show Shortcuts', action: () => {} },
  'g-d': { title: 'Go to Dashboard', path: '/dashboard' },
  'g-t': { title: 'Go to Tokens', path: '/tokens' },
  'g-b': { title: 'Go to Bans', path: '/bans' },
  'g-s': { title: 'Go to Settings', path: '/settings' },
};

export function useKeyboardShortcuts() {
  const navigate = useNavigate();
  let lastKey = '';
  let shortcutTimeout: NodeJS.Timeout;

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isMac = /Mac|iPhone|iPad|iPod/.test(navigator.platform);
      const modKey = isMac ? e.metaKey : e.ctrlKey;

      // Cmd/Ctrl + K for command palette
      if (modKey && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        // Dispatch custom event for command palette
        window.dispatchEvent(new CustomEvent('toggle-command-palette'));
        return;
      }

      // 'g' prefix for navigation shortcuts
      if (e.key === 'g') {
        lastKey = 'g';
        clearTimeout(shortcutTimeout);
        shortcutTimeout = setTimeout(() => {
          lastKey = '';
        }, 2000);
        return;
      }

      // Two-key shortcuts (g-d, g-t, etc)
      if (lastKey === 'g') {
        const combo = `g-${e.key.toLowerCase()}`;
        const shortcut = KEYBOARD_SHORTCUTS[combo as keyof typeof KEYBOARD_SHORTCUTS];
        if (shortcut && 'path' in shortcut) {
          e.preventDefault();
          navigate(shortcut.path);
          lastKey = '';
          clearTimeout(shortcutTimeout);
        }
        return;
      }

      // Single key shortcuts
      if (e.key === '?') {
        e.preventDefault();
        window.dispatchEvent(new CustomEvent('toggle-shortcuts-help'));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      clearTimeout(shortcutTimeout);
    };
  }, [navigate]);

  return KEYBOARD_SHORTCUTS;
}

interface ShortcutItem {
  title: string;
  keys: string;
}

export function getShortcutsList(): ShortcutItem[] {
  return [
    { title: 'Command Palette', keys: 'Cmd+K' },
    { title: 'Save Dashboard', keys: 'Cmd+S' },
    { title: 'Go to Dashboard', keys: 'G then D' },
    { title: 'Go to Tokens', keys: 'G then T' },
    { title: 'Go to Bans', keys: 'G then B' },
    { title: 'Go to Settings', keys: 'G then S' },
    { title: 'Show this Menu', keys: '?' },
  ];
}
