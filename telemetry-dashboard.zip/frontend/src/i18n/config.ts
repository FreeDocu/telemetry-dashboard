import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

const resources = {
  en: {
    translation: {
      // Navigation
      dashboard: 'Dashboard',
      tokens: 'API Tokens',
      bans: 'Ban Management',
      settings: 'Settings',
      logout: 'Logout',

      // Common
      loading: 'Loading...',
      error: 'Error',
      success: 'Success',
      save: 'Save',
      delete: 'Delete',
      cancel: 'Cancel',
      create: 'Create',
      edit: 'Edit',

      // Dashboard
      overview: 'Overview',
      launchesToday: 'Launches Today',
      uniqueUsers: 'Unique Users',
      retention: 'Retention',
      topCountries: 'Top Countries',
      versions: 'App Versions',
      suspiciousActivity: 'Suspicious Activity',

      // Filters
      period: 'Time Period',
      last1Hour: 'Last 1 Hour',
      last24Hours: 'Last 24 Hours',
      last7Days: 'Last 7 Days',
      last30Days: 'Last 30 Days',

      // Messages
      noData: 'No data available',
      unknownError: 'An unknown error occurred',
      confirmDelete: 'Are you sure?',
    },
  },
  ru: {
    translation: {
      // Навигация
      dashboard: 'Панель',
      tokens: 'API Токены',
      bans: 'Блокировки',
      settings: 'Настройки',
      logout: 'Выход',

      // Общые
      loading: 'Загрузка...',
      error: 'Ошибка',
      success: 'Успешно',
      save: 'Сохранить',
      delete: 'Удалить',
      cancel: 'Отмена',
      create: 'Создать',
      edit: 'Редактировать',

      // Панель
      overview: 'Обзор',
      launchesToday: 'Запусков сегодня',
      uniqueUsers: 'Уникальных пользователей',
      retention: 'Удержание',
      topCountries: 'Топ стран',
      versions: 'Версии приложения',
      suspiciousActivity: 'Подозрительная активность',

      // Фильтры
      period: 'Период времени',
      last1Hour: 'Последний час',
      last24Hours: 'Последние 24 часа',
      last7Days: 'Последние 7 дней',
      last30Days: 'Последние 30 дней',

      // Сообщения
      noData: 'Нет данных',
      unknownError: 'Неизвестная ошибка',
      confirmDelete: 'Вы уверены?',
    },
  },
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false,
    },
  });

export default i18n;
