import React, { useState } from 'react'
import { Navbar } from '@/components/Navbar'
import { adminAPI } from '@/api'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'

export const BanManagementPage: React.FC = () => {
  const [showCreate, setShowCreate] = useState(false)
  const [formData, setFormData] = useState({
    hwid: '',
    reason: '',
    until: '',
  })

  const queryClient = useQueryClient()

  const { data: bans = [], isLoading } = useQuery({
    queryKey: ['bans'],
    queryFn: () => adminAPI.listBans().then((res) => res.data),
  })

  const createMutation = useMutation({
    mutationFn: () =>
      adminAPI.banHWID(formData.hwid, formData.reason, undefined, formData.until || undefined),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bans'] })
      setFormData({ hwid: '', reason: '', until: '' })
      setShowCreate(false)
    },
  })

  const deleteMutation = useMutation({
    mutationFn: (hwid: string) => adminAPI.unban(hwid),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bans'] })
    },
  })

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (formData.hwid.trim()) {
      createMutation.mutate()
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900">
      <Navbar />

      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">HWID Ban Management</h1>
            <p className="text-white/60 text-sm mt-1">Block suspicious or malicious devices</p>
          </div>
          <button
            onClick={() => setShowCreate(!showCreate)}
            className="px-4 py-2 bg-gradient-to-r from-red-500 to-pink-500 text-white rounded-lg hover:shadow-lg transition font-medium"
          >
            + Ban HWID
          </button>
        </div>

        {showCreate && (
          <form onSubmit={handleCreateSubmit} className="glass-effect p-6 mb-8 rounded-lg">
            <div className="space-y-4 mb-4">
              <input
                type="text"
                placeholder="HWID (e.g., HWID-123ABC)"
                value={formData.hwid}
                onChange={(e) => setFormData({ ...formData, hwid: e.target.value })}
                className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-red-500"
                required
              />
              <textarea
                placeholder="Reason for ban"
                value={formData.reason}
                onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-red-500 resize-none h-20"
              />
              <div>
                <label className="text-xs text-white/70 block mb-2">Until (leave empty for permanent)</label>
                <input
                  type="datetime-local"
                  value={formData.until}
                  onChange={(e) => setFormData({ ...formData, until: e.target.value })}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded text-white focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                disabled={createMutation.isPending}
                className="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition disabled:opacity-50"
              >
                Ban HWID
              </button>
              <button
                type="button"
                onClick={() => setShowCreate(false)}
                className="px-4 py-2 bg-white/10 text-white/70 rounded hover:bg-white/20 transition"
              >
                Cancel
              </button>
            </div>
          </form>
        )}

        {isLoading ? (
          <div className="text-white/50 text-center py-12">Loading bans...</div>
        ) : (
          <div className="glass-effect rounded-lg overflow-hidden">
            <table className="w-full">
              <thead className="border-b border-white/10">
                <tr>
                  <th className="text-left py-3 px-6 text-white/70 font-semibold">HWID</th>
                  <th className="text-left py-3 px-6 text-white/70 font-semibold">Reason</th>
                  <th className="text-left py-3 px-6 text-white/70 font-semibold">Banned At</th>
                  <th className="text-left py-3 px-6 text-white/70 font-semibold">Until</th>
                  <th className="text-center py-3 px-6 text-white/70 font-semibold">Type</th>
                  <th className="text-center py-3 px-6 text-white/70 font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {bans.map((ban: any) => (
                  <tr key={ban.hwid} className="border-b border-white/5 hover:bg-white/5 transition">
                    <td className="py-3 px-6 text-white font-mono text-sm">{ban.hwid}</td>
                    <td className="py-3 px-6 text-white/60 text-sm">{ban.reason || '—'}</td>
                    <td className="py-3 px-6 text-white/60 text-sm">
                      {new Date(ban.banned_at).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-6 text-white/60 text-sm">
                      {ban.until ? new Date(ban.until).toLocaleDateString() : '∞ Permanent'}
                    </td>
                    <td className="py-3 px-6 text-center">
                      <span
                        className={`text-xs font-semibold px-3 py-1 rounded-full ${
                          ban.until ? 'bg-yellow-500/20 text-yellow-300' : 'bg-red-500/20 text-red-300'
                        }`}
                      >
                        {ban.until ? 'Temporary' : 'Permanent'}
                      </span>
                    </td>
                    <td className="py-3 px-6 text-center">
                      <button
                        onClick={() => deleteMutation.mutate(ban.hwid)}
                        className="text-xs px-3 py-1 bg-green-500/20 text-green-300 rounded hover:bg-green-500/30 transition"
                        disabled={deleteMutation.isPending}
                      >
                        Unban
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {bans.length === 0 && (
              <div className="text-center py-8 text-white/50">No banned HWIDs yet</div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
