import React, { useState, useEffect } from 'react'
import { Navbar } from '@/components/Navbar'
import { KPICard } from '@/components/KPICard'
import { FilterPanel } from '@/components/FilterPanel'
import { RetentionChart } from '@/components/RetentionChart'
import { ActivityHeatmap } from '@/components/ActivityHeatmap'
import { TopHWIDsTable } from '@/components/TopHWIDsTable'
import { GeographyChart } from '@/components/GeographyChart'
import { VersionChart } from '@/components/VersionChart'
import { DashboardGrid } from '@/components/DashboardGrid'
import { useDashboardFilters } from '@/store/filters'
import { dashboardAPI, analyticsAPI } from '@/api'
import { useQuery } from '@tanstack/react-query'

interface GridItem {
  key: string
  component: React.ReactNode
}

export const DashboardPage: React.FC = () => {
  const [isEditing, setIsEditing] = useState(false)
  const [layouts, setLayouts] = useState<any>(null)
  const { filters } = useDashboardFilters()

  // Fetch dashboard layout
  useEffect(() => {
    dashboardAPI.getLayout().then((res) => setLayouts(res.data.layout))
  }, [])

  // Fetch analytics data
  const { data: summary } = useQuery({
    queryKey: ['summary', filters],
    queryFn: () => analyticsAPI.getSummary(
      filters.tokenIds.length > 0 ? filters.tokenIds : undefined,
      filters.periodHours
    ),
  })

  const handleLayoutSave = async (newLayout: any) => {
    try {
      await dashboardAPI.saveLayout(newLayout)
    } catch (err) {
      console.error('Failed to save layout:', err)
    }
  }

  const gridItems: GridItem[] = [
    {
      key: 'kpi-unique-hwid',
      component: (
        <div key="kpi-unique-hwid">
          <KPICard
            label="Unique HWIDs"
            value={summary?.data?.unique_hwids ?? 0}
            trend={5}
            color="from-blue-500 to-cyan-500"
          />
        </div>
      ),
    },
    {
      key: 'kpi-launches-today',
      component: (
        <div key="kpi-launches-today">
          <KPICard
            label="Launches Today"
            value={summary?.data?.total_launches ?? 0}
            trend={-2}
            color="from-green-500 to-emerald-500"
          />
        </div>
      ),
    },
    {
      key: 'kpi-retention-d1',
      component: (
        <div key="kpi-retention-d1">
          <KPICard label="D1 Retention" value="68.5%" color="from-purple-500 to-pink-500" />
        </div>
      ),
    },
    {
      key: 'kpi-retention-d7',
      component: (
        <div key="kpi-retention-d7">
          <KPICard label="D7 Retention" value="42.3%" color="from-orange-500 to-red-500" />
        </div>
      ),
    },
    {
      key: 'kpi-retention-d30',
      component: (
        <div key="kpi-retention-d30">
          <KPICard label="D30 Retention" value="18.7%" color="from-indigo-500 to-blue-500" />
        </div>
      ),
    },
    {
      key: 'filters',
      component: (
        <div key="filters">
          <FilterPanel />
        </div>
      ),
    },
    {
      key: 'retention-curves',
      component: (
        <div key="retention-curves">
          <RetentionChart data={[]} />
        </div>
      ),
    },
    {
      key: 'heatmap-activity',
      component: (
        <div key="heatmap-activity">
          <ActivityHeatmap />
        </div>
      ),
    },
    {
      key: 'top-hwids',
      component: (
        <div key="top-hwids">
          <TopHWIDsTable />
        </div>
      ),
    },
    {
      key: 'geography',
      component: (
        <div key="geography">
          <GeographyChart />
        </div>
      ),
    },
    {
      key: 'versions',
      component: (
        <div key="versions">
          <VersionChart />
        </div>
      ),
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900">
      <Navbar />

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Control Panel */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold text-white">Dashboard</h2>
            <p className="text-white/60 text-sm mt-1">Real-time monitoring & analytics</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setIsEditing(!isEditing)}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                isEditing
                  ? 'bg-blue-500 text-white'
                  : 'bg-white/10 text-white/70 hover:bg-white/20'
              }`}
            >
              {isEditing ? '✓ Done Editing' : '✏️ Edit Layout'}
            </button>
            {isEditing && (
              <button className="px-4 py-2 bg-white/10 text-white/70 rounded-lg hover:bg-white/20 transition font-medium">
                ↻ Reset Default
              </button>
            )}
          </div>
        </div>

        {/* Grid */}
        {layouts ? (
          <DashboardGrid
            layouts={layouts}
            onLayoutChange={handleLayoutSave}
            isEditing={isEditing}
          >
            {gridItems.map((item) => item.component)}
          </DashboardGrid>
        ) : (
          <div className="text-white/50 text-center py-12">Loading dashboard...</div>
        )}
      </div>
    </div>
  )
}
