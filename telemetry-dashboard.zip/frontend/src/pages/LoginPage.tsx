import React, { useState } from 'react'
import { authAPI } from '@/api'
import { useAuthStore } from '@/store/auth'
import { useNavigate } from 'react-router-dom'

interface LoginPageProps {}

export const LoginPage: React.FC<LoginPageProps> = () => {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [totpCode, setTotpCode] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [needsTOTP, setNeedsTOTP] = useState(false)
  
  const { login } = useAuthStore()
  const navigate = useNavigate()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const response = await authAPI.login(username, password, needsTOTP ? totpCode : undefined)
      const { access_token } = response.data

      login(access_token, username)
      navigate('/dashboard')
    } catch (err: any) {
      if (err.response?.status === 401 && err.response?.data?.detail.includes('TOTP')) {
        setNeedsTOTP(true)
        setError('TOTP code required')
      } else {
        setError(err.response?.data?.detail || 'Login failed')
      }
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl mb-4 shadow-lg">
            <span className="text-3xl">📊</span>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Telemetry Dashboard</h1>
          <p className="text-white/60 text-sm">Administrator Panel</p>
        </div>

        {/* Form */}
        <form onSubmit={handleLogin} className="glass-effect p-8 space-y-6">
          {error && (
            <div className="p-3 bg-red-500/20 border border-red-500/50 rounded text-red-300 text-sm">
              {error}
            </div>
          )}

          {!needsTOTP ? (
            <>
              <div>
                <label className="text-sm font-semibold text-white/70 block mb-2">Username</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="your-username"
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
                />
              </div>

              <div>
                <label className="text-sm font-semibold text-white/70 block mb-2">Password</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
                />
              </div>
            </>
          ) : (
            <div>
              <label className="text-sm font-semibold text-white/70 block mb-2">TOTP Code</label>
              <input
                type="text"
                value={totpCode}
                onChange={(e) => setTotpCode(e.target.value)}
                placeholder="000000"
                maxLength={6}
                className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-blue-500 transition text-center text-xl tracking-widest"
              />
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full px-4 py-2 bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-semibold rounded-lg hover:shadow-lg transition disabled:opacity-50"
          >
            {loading ? 'Logging in...' : needsTOTP ? 'Verify TOTP' : 'Sign In'}
          </button>
        </form>

        {/* Footer */}
        <div className="text-center mt-6">
          <p className="text-white/50 text-xs">
            © 2026 Telemetry Dashboard. Some rights reserved.
          </p>
        </div>
      </div>
    </div>
  )
}
