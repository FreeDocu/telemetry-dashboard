import React, { useState } from 'react'
import { Navbar } from '@/components/Navbar'
import { authAPI } from '@/api'

export const SettingsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'security' | 'totp'>('security')
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [totpStep, setTotpStep] = useState<'setup' | 'verify' | 'done'>('setup')
  const [totpSecret, setTotpSecret] = useState('')
  const [totpQR, setTotpQR] = useState('')
  const [totpCode, setTotpCode] = useState('')
  const [message, setMessage] = useState('')
  const [loading, setLoading] = useState(false)

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      if (newPassword !== confirmPassword) {
        setMessage('Passwords do not match!')
        return
      }
      // TODO: Implement password change endpoint
      setMessage('✓ Password changed successfully')
    } catch (err: any) {
      setMessage('✗ ' + (err.response?.data?.detail || 'Failed'))
    } finally {
      setLoading(false)
    }
  }

  const handleSetupTOTP = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const response = await authAPI.setupTOTP(currentPassword)
      setTotpSecret(response.data.secret)
      setTotpQR(response.data.qr_code)
      setTotpStep('verify')
    } catch (err: any) {
      setMessage('✗ ' + (err.response?.data?.detail || 'Failed'))
    } finally {
      setLoading(false)
    }
  }

  const handleConfirmTOTP = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      await authAPI.confirmTOTP(totpSecret, totpCode)
      setTotpStep('done')
      setMessage('✓ 2FA enabled permanently!')
      setTimeout(() => {
        setTotpStep('setup')
        setTotpSecret('')
        setTotpCode('')
      }, 3000)
    } catch (err: any) {
      setMessage('✗ ' + (err.response?.data?.detail || 'Failed'))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900">
      <Navbar />

      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white">Settings</h1>
          <p className="text-white/60 text-sm mt-1">Manage your account security</p>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 mb-8 border-b border-white/10">
          <button
            onClick={() => setActiveTab('security')}
            className={`px-4 py-3 font-medium border-b-2 transition ${
              activeTab === 'security'
                ? 'text-blue-400 border-blue-400'
                : 'text-white/60 border-transparent hover:text-white/80'
            }`}
          >
            Password
          </button>
          <button
            onClick={() => setActiveTab('totp')}
            className={`px-4 py-3 font-medium border-b-2 transition ${
              activeTab === 'totp'
                ? 'text-blue-400 border-blue-400'
                : 'text-white/60 border-transparent hover:text-white/80'
            }`}
          >
            Two-Factor Authentication
          </button>
        </div>

        {message && (
          <div
            className={`p-4 rounded-lg mb-8 text-sm ${
              message.startsWith('✓')
                ? 'bg-green-500/20 text-green-300 border border-green-500/50'
                : 'bg-red-500/20 text-red-300 border border-red-500/50'
            }`}
          >
            {message}
          </div>
        )}

        {/* Password Tab */}
        {activeTab === 'security' && (
          <form onSubmit={handleChangePassword} className="glass-effect p-8 rounded-lg max-w-md">
            <h2 className="text-xl font-semibold text-white mb-6">Change Password</h2>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-white/70 block mb-2">
                  Current Password
                </label>
                <input
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium text-white/70 block mb-2">
                  New Password
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="text-sm font-medium text-white/70 block mb-2">
                  Confirm Password
                </label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full px-4 py-2 bg-blue-500 text-white font-medium rounded hover:bg-blue-600 transition disabled:opacity-50"
              >
                Update Password
              </button>
            </div>
          </form>
        )}

        {/* TOTP Tab */}
        {activeTab === 'totp' && (
          <div className="glass-effect p-8 rounded-lg max-w-lg">
            <h2 className="text-xl font-semibold text-white mb-6">Two-Factor Authentication</h2>

            {totpStep === 'setup' && (
              <form onSubmit={handleSetupTOTP} className="space-y-4">
                <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded text-blue-300 text-sm">
                  ℹ️ 2FA can be set up <strong>only once</strong>. After activation, it cannot be changed without
                  database intervention.
                </div>
                <div>
                  <label className="text-sm font-medium text-white/70 block mb-2">
                    Enter current password to proceed
                  </label>
                  <input
                    type="password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full px-4 py-2 bg-green-500 text-white font-medium rounded hover:bg-green-600 transition disabled:opacity-50"
                >
                  Begin TOTP Setup
                </button>
              </form>
            )}

            {totpStep === 'verify' && totpQR && (
              <form onSubmit={handleConfirmTOTP} className="space-y-4">
                <div className="text-center">
                  <p className="text-white/70 text-sm mb-4">
                    Scan this QR code with your authenticator app
                  </p>
                  <img src={totpQR} alt="TOTP QR Code" className="w-48 h-48 mx-auto border border-white/20 p-4" />
                  <p className="text-white/50 text-xs mt-4">Or enter manually: {totpSecret}</p>
                </div>

                <div>
                  <label className="text-sm font-medium text-white/70 block mb-2">
                    Enter 6-digit code from app
                  </label>
                  <input
                    type="text"
                    value={totpCode}
                    onChange={(e) => setTotpCode(e.target.value)}
                    maxLength={6}
                    placeholder="000000"
                    className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded text-white text-center text-xl tracking-widest placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading || totpCode.length !== 6}
                  className="w-full px-4 py-2 bg-green-500 text-white font-medium rounded hover:bg-green-600 transition disabled:opacity-50"
                >
                  Confirm & Enable 2FA
                </button>
              </form>
            )}

            {totpStep === 'done' && (
              <div className="text-center">
                <div className="text-5xl mb-4">✅</div>
                <p className="text-green-300 font-semibold">2FA Successfully Enabled!</p>
                <p className="text-white/60 text-sm mt-2">
                  Your account is now protected. 2FA is permanently locked.
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
