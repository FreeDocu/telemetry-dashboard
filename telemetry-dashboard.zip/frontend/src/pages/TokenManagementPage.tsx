import React, { useState } from 'react'
import { Navbar } from '@/components/Navbar'
import { tokenAPI } from '@/api'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'

export const TokenManagementPage: React.FC = () => {
  const [showCreate, setShowCreate] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    note: '',
    expires_at: '',
  })
  
  const queryClient = useQueryClient()
  
  const { data: tokens = [], isLoading } = useQuery({
    queryKey: ['tokens'],
    queryFn: () => tokenAPI.list().then((res) => res.data),
  })

  const createMutation = useMutation({
    mutationFn: () =>
      tokenAPI.create(
        formData.name,
        formData.note,
        formData.expires_at || undefined
      ),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tokens'] })
      setFormData({ name: '', note: '', expires_at: '' })
      setShowCreate(false)
    },
  })

  const deleteMutation = useMutation({
    mutationFn: (tokenId: string) => tokenAPI.delete(tokenId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tokens'] })
    },
  })

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (formData.name.trim()) {
      createMutation.mutate()
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900">
      <Navbar />

      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">Token Management</h1>
            <p className="text-white/60 text-sm mt-1">Create and manage application tokens</p>
          </div>
          <button
            onClick={() => setShowCreate(!showCreate)}
            className="px-4 py-2 bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-lg hover:shadow-lg transition font-medium"
          >
            + Create Token
          </button>
        </div>

        {showCreate && (
          <form onSubmit={handleCreateSubmit} className="glass-effect p-6 mb-8 rounded-lg">
            <div className="grid grid-cols-3 gap-4 mb-4">
              <input
                type="text"
                placeholder="Token name (e.g., App v1.0)"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="px-4 py-2 bg-white/10 border border-white/20 rounded text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="text"
                placeholder="Note (optional)"
                value={formData.note}
                onChange={(e) => setFormData({ ...formData, note: e.target.value })}
                className="px-4 py-2 bg-white/10 border border-white/20 rounded text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="datetime-local"
                value={formData.expires_at}
                onChange={(e) => setFormData({ ...formData, expires_at: e.target.value })}
                className="px-4 py-2 bg-white/10 border border-white/20 rounded text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                disabled={createMutation.isPending}
                className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition disabled:opacity-50"
              >
                Create
              </button>
              <button
                type="button"
                onClick={() => setShowCreate(false)}
                className="px-4 py-2 bg-white/10 text-white/70 rounded hover:bg-white/20 transition"
              >
                Cancel
              </button>
            </div>
          </form>
        )}

        {isLoading ? (
          <div className="text-white/50 text-center py-12">Loading tokens...</div>
        ) : (
          <div className="glass-effect rounded-lg overflow-hidden">
            <table className="w-full">
              <thead className="border-b border-white/10">
                <tr>
                  <th className="text-left py-3 px-6 text-white/70 font-semibold">Name</th>
                  <th className="text-left py-3 px-6 text-white/70 font-semibold">Token</th>
                  <th className="text-left py-3 px-6 text-white/70 font-semibold">Note</th>
                  <th className="text-left py-3 px-6 text-white/70 font-semibold">Status</th>
                  <th className="text-left py-3 px-6 text-white/70 font-semibold">Expires</th>
                  <th className="text-center py-3 px-6 text-white/70 font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {tokens.map((token: any) => (
                  <tr key={token.id} className="border-b border-white/5 hover:bg-white/5 transition">
                    <td className="py-3 px-6 text-white font-medium">{token.name}</td>
                    <td className="py-3 px-6 text-white/60 font-mono text-xs">
                      {token.token.slice(0, 20)}...
                    </td>
                    <td className="py-3 px-6 text-white/60 text-sm">{token.note || '—'}</td>
                    <td className="py-3 px-6">
                      <span
                        className={`text-xs font-semibold px-3 py-1 rounded-full ${
                          token.active
                            ? 'bg-green-500/20 text-green-300'
                            : 'bg-red-500/20 text-red-300'
                        }`}
                      >
                        {token.active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="py-3 px-6 text-white/60 text-sm">
                      {token.expires_at ? new Date(token.expires_at).toLocaleDateString() : '—'}
                    </td>
                    <td className="py-3 px-6 text-center">
                      <button
                        onClick={() => deleteMutation.mutate(token.id)}
                        className="text-xs px-3 py-1 bg-red-500/20 text-red-300 rounded hover:bg-red-500/30 transition"
                        disabled={deleteMutation.isPending}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
