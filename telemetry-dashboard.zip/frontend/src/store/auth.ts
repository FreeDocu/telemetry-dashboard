import { create } from 'zustand'

interface AuthState {
  token: string | null
  username: string | null
  totpSetup: boolean
  login: (token: string, username: string) => void
  logout: () => void
  setTotpSetup: (setup: boolean) => void
}

export const useAuthStore = create<AuthState>((set) => ({
  token: localStorage.getItem('access_token'),
  username: localStorage.getItem('username'),
  totpSetup: localStorage.getItem('totp_setup') === 'true',
  
  login: (token: string, username: string) => {
    localStorage.setItem('access_token', token)
    localStorage.setItem('username', username)
    set({ token, username })
  },
  
  logout: () => {
    localStorage.removeItem('access_token')
    localStorage.removeItem('username')
    set({ token: null, username: null })
  },
  
  setTotpSetup: (setup: boolean) => {
    localStorage.setItem('totp_setup', String(setup))
    set({ totpSetup: setup })
  },
}))
