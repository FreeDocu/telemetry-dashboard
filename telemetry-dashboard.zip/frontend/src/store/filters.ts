import { create } from 'zustand'

export interface FilterState {
  periodHours: number
  tokenIds: string[]
  countries: string[]
  versions: string[]
  suspiciousOnly: boolean
  bannedOnly: boolean
}

interface DashboardFilterStore {
  filters: FilterState
  setFilters: (filters: Partial<FilterState>) => void
}

export const useDashboardFilters = create<DashboardFilterStore>((set) => ({
  filters: {
    periodHours: 24,
    tokenIds: [],
    countries: [],
    versions: [],
    suspiciousOnly: false,
    bannedOnly: false,
  },
  
  setFilters: (newFilters) =>
    set((state) => ({
      filters: { ...state.filters, ...newFilters },
    })),
}))
