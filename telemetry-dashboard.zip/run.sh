#!/bin/bash

# Telemetry Dashboard - Quick Start Script
# This script helps you run the dashboard locally

set -e

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$PROJECT_ROOT/backend"
FRONTEND_DIR="$PROJECT_ROOT/frontend"

echo "🚀 Telemetry Dashboard - Local Development"
echo "==========================================="
echo ""

# Check dependencies
echo "📋 Checking dependencies..."
command -v python3 >/dev/null 2>&1 || { echo "❌ Python 3 required"; exit 1; }
command -v node >/dev/null 2>&1 || { echo "❌ Node.js required"; exit 1; }

echo "✓ Python and Node.js found"
echo ""

# Menu
echo "What would you like to do?"
echo "1) Setup new installation"
echo "2) Run backend only"
echo "3) Run frontend only"
echo "4) Run both (requires tmux)"
echo "5) Install backend dependencies"
echo "6) Install frontend dependencies"
echo ""
read -p "Choose (1-6): " choice

case $choice in
  1)
    echo "Installing dependencies..."
    cd "$BACKEND_DIR"
    pip install -r requirements.txt
    cd "$FRONTEND_DIR"
    npm install
    echo "✓ Setup complete!"
    echo "Next: Copy backend/.env.example to backend/.env and configure"
    ;;
  2)
    echo "Starting backend on http://localhost:8000"
    cd "$BACKEND_DIR"
    python main.py
    ;;
  3)
    echo "Starting frontend on http://localhost:5173"
    cd "$FRONTEND_DIR"
    npm run dev
    ;;
  4)
    if ! command -v tmux &> /dev/null; then
      echo "❌ tmux required for this option"
      exit 1
    fi
    echo "Starting both services..."
    tmux new-session -d -s telemetry -x 120 -y 40
    tmux send-keys -t telemetry "cd $BACKEND_DIR && python main.py" Enter
    tmux split-window -t telemetry -h
    tmux send-keys -t telemetry "cd $FRONTEND_DIR && npm run dev" Enter
    tmux attach -t telemetry
    ;;
  5)
    cd "$BACKEND_DIR"
    pip install -r requirements.txt
    echo "✓ Backend dependencies installed"
    ;;
  6)
    cd "$FRONTEND_DIR"
    npm install
    echo "✓ Frontend dependencies installed"
    ;;
  *)
    echo "Invalid choice"
    exit 1
    ;;
esac
