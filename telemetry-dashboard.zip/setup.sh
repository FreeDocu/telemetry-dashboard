#!/bin/bash

# Backend Setup
cd backend

echo "📦 Installing backend dependencies..."
pip install -r requirements.txt

echo "🗄️  Setting up database..."
# You should have PostgreSQL running
# psql -U postgres -c "CREATE DATABASE telemetry_db;"

echo "👤 Creating admin user..."
python scripts/init_admin.py

echo ""
echo "✅ Backend setup complete!"
echo "Run backend: python main.py"
echo ""

# Frontend Setup
cd ../frontend

echo "📦 Installing frontend dependencies..."
npm install

echo "✅ Frontend setup complete!"
echo "Run frontend: npm run dev"
