#!/bin/bash

# Test Suite - Verify Cloudflare Production Deployment

echo "=========================================="
echo "Telemetry Dashboard - Test Suite"
echo "=========================================="
echo ""

API_URL="https://drukvculgar.live"
API_INTERNAL="http://localhost:8000"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

test_count=0
pass_count=0
fail_count=0

function test_endpoint() {
    local name=$1
    local url=$2
    local method=${3:-GET}
    local expected_code=${4:-200}
    
    test_count=$((test_count + 1))
    
    echo -n "Test $test_count: $name ... "
    
    response=$(curl -s -w "\n%{http_code}" -X $method "$url" -H "User-Agent: TestSuite/1.0")
    http_code=$(echo "$response" | tail -n 1)
    body=$(echo "$response" | sed '$d')
    
    if [[ "$http_code" == "$expected_code" ]]; then
        echo -e "${GREEN}PASS${NC} (HTTP $http_code)"
        pass_count=$((pass_count + 1))
    else
        echo -e "${RED}FAIL${NC} (Expected $expected_code, got $http_code)"
        fail_count=$((fail_count + 1))
    fi
}

function test_endpoint_via_internal() {
    local name=$1
    local path=$2
    local method=${3:-GET}
    local expected_code=${4:-200}
    
    test_count=$((test_count + 1))
    
    echo -n "Test $test_count: $name ... "
    
    response=$(curl -s -w "\n%{http_code}" -X $method "$API_INTERNAL$path" \
        -H "User-Agent: TestSuite/1.0" \
        -H "Content-Type: application/json")
    http_code=$(echo "$response" | tail -n 1)
    body=$(echo "$response" | sed '$d')
    
    if [[ "$http_code" == "$expected_code" ]]; then
        echo -e "${GREEN}PASS${NC} (HTTP $http_code)"
        pass_count=$((pass_count + 1))
    else
        echo -e "${RED}FAIL${NC} (Expected $expected_code, got $http_code)"
        echo "Response: $body"
        fail_count=$((fail_count + 1))
    fi
}

echo "Testing Local Services (Internal)..."
echo "===================================="
echo ""

test_endpoint_via_internal "Health Check" "/health" "GET" "200"
test_endpoint_via_internal "Metrics Endpoint" "/metrics" "GET" "200"
test_endpoint_via_internal "API Info" "/api/v1" "GET" "404"  # No root endpoint
test_endpoint_via_internal "Login Missing Credentials" "/api/v1/auth/login" "POST" "422"
test_endpoint_via_internal "Telemetry Missing Token" "/api/v1/telemetry/ping" "POST" "422"

echo ""
echo "Checking Docker Services..."
echo "============================"
echo ""

echo -n "PostgreSQL Service ... "
if docker-compose -f docker-compose.prod.yml ps postgres | grep -q "Up"; then
    echo -e "${GREEN}RUNNING${NC}"
    pass_count=$((pass_count + 1))
else
    echo -e "${RED}NOT RUNNING${NC}"
    fail_count=$((fail_count + 1))
fi

echo -n "Redis Service ... "
if docker-compose -f docker-compose.prod.yml ps redis | grep -q "Up"; then
    echo -e "${GREEN}RUNNING${NC}"
    pass_count=$((pass_count + 1))
else
    echo -e "${RED}NOT RUNNING${NC}"
    fail_count=$((fail_count + 1))
fi

echo -n "Backend Service ... "
if docker-compose -f docker-compose.prod.yml ps backend | grep -q "Up"; then
    echo -e "${GREEN}RUNNING${NC}"
    pass_count=$((pass_count + 1))
else
    echo -e "${RED}NOT RUNNING${NC}"
    fail_count=$((fail_count + 1))
fi

echo -n "Frontend Service ... "
if docker-compose -f docker-compose.prod.yml ps frontend | grep -q "Up"; then
    echo -e "${GREEN}RUNNING${NC}"
    pass_count=$((pass_count + 1))
else
    echo -e "${RED}NOT RUNNING${NC}"
    fail_count=$((fail_count + 1))
fi

echo -n "Nginx Service ... "
if docker-compose -f docker-compose.prod.yml ps nginx | grep -q "Up"; then
    echo -e "${GREEN}RUNNING${NC}"
    pass_count=$((pass_count + 1))
else
    echo -e "${RED}NOT RUNNING${NC}"
    fail_count=$((fail_count + 1))
fi

echo ""
echo "Testing Security Headers..."
echo "============================"
echo ""

echo -n "Test HSTS Header ... "
hsts=$(curl -s -I $API_INTERNAL/health | grep -i "Strict-Transport-Security" | wc -l)
if [ $hsts -gt 0 ]; then
    echo -e "${GREEN}PRESENT${NC}"
    pass_count=$((pass_count + 1))
else
    echo -e "${YELLOW}MISSING${NC}"
fi

echo -n "Test CSP Header ... "
csp=$(curl -s -I $API_INTERNAL/health | grep -i "Content-Security-Policy" | wc -l)
if [ $csp -gt 0 ]; then
    echo -e "${GREEN}PRESENT${NC}"
    pass_count=$((pass_count + 1))
else
    echo -e "${YELLOW}MISSING${NC}"
fi

echo -n "Test X-Frame-Options Header ... "
xfo=$(curl -s -I $API_INTERNAL/health | grep -i "X-Frame-Options" | wc -l)
if [ $xfo -gt 0 ]; then
    echo -e "${GREEN}PRESENT${NC}"
    pass_count=$((pass_count + 1))
else
    echo -e "${YELLOW}MISSING${NC}"
fi

echo ""
echo "Testing Bot Protection..."
echo "========================="
echo ""

echo -n "Test SQLMap Bot Rejection ... "
response=$(curl -s -w "\n%{http_code}" "$API_INTERNAL/api/v1/telemetry/ping" \
    -H "User-Agent: sqlmap/1.0")
http_code=$(echo "$response" | tail -n 1)
if [[ "$http_code" == "403" ]]; then
    echo -e "${GREEN}BLOCKED${NC}"
    pass_count=$((pass_count + 1))
else
    echo -e "${YELLOW}ALLOWED (Code: $http_code)${NC}"
fi

echo -n "Test Nmap Bot Rejection ... "
response=$(curl -s -w "\n%{http_code}" "$API_INTERNAL/api/v1/telemetry/ping" \
    -H "User-Agent: nmap scanner")
http_code=$(echo "$response" | tail -n 1)
if [[ "$http_code" == "403" ]]; then
    echo -e "${GREEN}BLOCKED${NC}"
    pass_count=$((pass_count + 1))
else
    echo -e "${YELLOW}ALLOWED (Code: $http_code)${NC}"
fi

echo -n "Test Valid User-Agent ... "
response=$(curl -s -w "\n%{http_code}" "$API_INTERNAL/health" \
    -H "User-Agent: Mozilla/5.0")
http_code=$(echo "$response" | tail -n 1)
if [[ "$http_code" == "200" ]]; then
    echo -e "${GREEN}ALLOWED${NC}"
    pass_count=$((pass_count + 1))
else
    echo -e "${RED}BLOCKED${NC}"
    fail_count=$((fail_count + 1))
fi

echo ""
echo "Testing Database Connection..."
echo "==============================="
echo ""

echo -n "PostgreSQL Connectivity ... "
if docker-compose -f docker-compose.prod.yml exec -T postgres pg_isready -U telemetry > /dev/null 2>&1; then
    echo -e "${GREEN}OK${NC}"
    pass_count=$((pass_count + 1))
else
    echo -e "${RED}FAILED${NC}"
    fail_count=$((fail_count + 1))
fi

echo -n "Redis Connectivity ... "
if docker-compose -f docker-compose.prod.yml exec -T redis redis-cli ping > /dev/null 2>&1; then
    echo -e "${GREEN}OK${NC}"
    pass_count=$((pass_count + 1))
else
    echo -e "${RED}FAILED${NC}"
    fail_count=$((fail_count + 1))
fi

echo ""
echo "Testing Sample Telemetry Data..."
echo "================================="
echo ""

# Create test token in database
echo -n "Creating test token ... "
token_result=$(docker-compose -f docker-compose.prod.yml exec -T postgres psql -U telemetry -d telemetry_db -c \
    "INSERT INTO public.token (token, name, note, active, created_at, expires_at) VALUES ('test-token-123', 'Test', 'Test token', true, NOW(), NULL) RETURNING id;" 2>/dev/null)

if [[ $? -eq 0 ]]; then
    echo -e "${GREEN}OK${NC}"
    
    # Send test telemetry
    echo -n "Sending test telemetry ... "
    response=$(curl -s -w "\n%{http_code}" -X POST "$API_INTERNAL/api/v1/telemetry/ping" \
        -H "Content-Type: application/json" \
        -H "User-Agent: TestClient/1.0" \
        -d '{
            "token": "test-token-123",
            "hwid": "TEST-HWID-001",
            "exe_version": "1.0.0",
            "os": "Windows 10"
        }')
    
    http_code=$(echo "$response" | tail -n 1)
    if [[ "$http_code" == "200" ]]; then
        echo -e "${GREEN}SUCCESS${NC}"
        pass_count=$((pass_count + 1))
    else
        echo -e "${RED}FAILED (HTTP $http_code)${NC}"
        fail_count=$((fail_count + 1))
    fi
else
    echo -e "${RED}SETUP FAILED${NC}"
fi

echo ""
echo "=========================================="
echo "Test Results"
echo "=========================================="
echo ""
echo -e "Total Tests: $test_count"
echo -e "${GREEN}Passed: $pass_count${NC}"
echo -e "${RED}Failed: $fail_count${NC}"
echo ""

if [ $fail_count -eq 0 ]; then
    echo -e "${GREEN}ALL TESTS PASSED!${NC}"
    exit 0
else
    echo -e "${RED}SOME TESTS FAILED!${NC}"
    exit 1
fi
