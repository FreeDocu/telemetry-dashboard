#!/bin/bash

# Quick Local Test Run

echo "Starting production services locally..."
echo ""

# Stop any running containers
docker-compose -f docker-compose.prod.yml down 2>/dev/null || true

# Start services
echo "Starting services..."
docker-compose -f docker-compose.prod.yml up -d

# Wait for services to be ready
echo ""
echo "Waiting for services to be ready (30 seconds)..."
sleep 30

# Show logs summary
echo ""
echo "Service Status:"
docker-compose -f docker-compose.prod.yml ps

echo ""
echo "Running tests..."
bash test-deployment.sh

echo ""
echo "Access the app at:"
echo "  http://localhost:80 (via Nginx reverse proxy)"
echo "  http://localhost:5173 (direct frontend)"
echo "  http://localhost:8000 (direct backend)"
echo ""
echo "Database:"
echo "  Host: localhost:5432"
echo "  User: telemetry"
echo "  DB: telemetry_db"
echo ""
echo "Redis:"
echo "  Host: localhost:6379"
echo ""
echo "Logs:"
echo "  docker-compose -f docker-compose.prod.yml logs -f backend"
echo "  docker-compose -f docker-compose.prod.yml logs -f frontend"
echo "  docker-compose -f docker-compose.prod.yml logs -f nginx"
echo ""
echo "Stop services:"
echo "  docker-compose -f docker-compose.prod.yml down"
echo ""
